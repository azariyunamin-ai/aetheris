---
name: nature-reviewer
description: >-
  Simulate a Nature-style reviewer assessment from the referee perspective rather than
  an author rebuttal. Use when the user wants a pre-submission review, reviewer report,
  peer-review style critique, novelty/significance/technical soundness assessment,
  reviewer-style manuscript evaluation, 审稿人视角评估, 预审稿意见, or Nature reviewer
  report. Return 3 reviewer reports plus a cross-review synthesis, grounded only in the
  local Nature reviewer source basis.
  Also trigger on general pre-submission review requests during academic writing even without the
  word "Nature", such as getting a mock peer review for any journal, critiquing a draft as a
  reviewer would, assessing novelty/rigor before submission, and Chinese phrasings like
  审稿人视角、模拟审稿、预审、帮我审一下论文、投稿前自审、审稿意见模拟、找论文问题.
type: component
intent: review_response
best_for:
  - Pre-submission self-review to find blind spots before journal submission
  - Mock peer review for any journal (not just Nature), assessing novelty and technical rigor
  - Getting 3 independent reviewer perspectives with different emphasis weights
  - Cross-review synthesis that identifies consensus strengths and unresolved risks
  - 投稿前的模拟审稿，从审稿人视角发现论文问题
version: 0.1.0
status: Draft
---

# Nature Reviewer Assessment Skill

Use this skill to simulate a `Nature`-style reviewer assessment package from the referee
side.

This skill is for reviewer-style manuscript evaluation, not for drafting the authors'
response. If the user wants rebuttal writing, route to `nature-response`.

## Default stance

- Ground the review only in the local source basis plus manuscript facts supplied by the user.
- Evaluate the manuscript against source-grounded axes: `originality`, `scientific importance`, `interdisciplinary readership`, `technical soundness`, and `readability for nonspecialists`.
- Return exactly `3 reviewer reports + 1 cross-review synthesis` unless the user explicitly asks for another structure.
- The three reviewers may differ only in `emphasis`; do not invent reviewer identities, specialties, institutions, or biographies.
- Identify who would be interested in the results and why.
- Identify technical failings that must be addressed before the authors' case is established.
- Distinguish clearly between what is supported, what is weak, and what is not assessable from the provided material.
- Do not claim the editor's final decision or certainty about fit to `Nature`.

## Input

What the skill can accept, and what happens when you come empty-handed.

Accepted inputs may include:

- Full manuscript draft
- Abstract, summary paragraph, or cover-summary style text
- Introduction, results, discussion, or methods excerpts
- Figure legends, selected figures, or result notes
- Author notes in Chinese or English describing the claimed contribution
- Pre-submission positioning notes

**Empty hands?** If no manuscript is provided, ask 2-3 scoping questions first:
1. What is the paper's main claim or contribution?
2. What journal / field are you targeting?
3. Do you have any sections drafted, even in early form?

If the provided material is partial, perform a bounded review and mark the
assessment boundary explicitly — do not invent missing contents.

Inline input (provided with the request) is treated as answered and is NOT
repeated back as a question.

## Workflow

1. Identify the input scope and whether the job is a reviewer-style assessment rather than rebuttal drafting.
2. Extract a shared manuscript fact base: main claim, visible evidence, claimed significance, likely readership, and visible limitations.
3. Check readiness and label missing evidence or missing sections instead of inventing them.
4. Assess the manuscript using the source-grounded axes.
5. Generate `Reviewer 1`, `Reviewer 2`, and `Reviewer 3` using shared facts but different emphasis.
6. Generate a `Cross-review synthesis` that captures consensus and weighting differences.
7. Run QA for groundedness, coverage, role boundaries, and non-invention.

## Output format

Unless the user asks for another format, return:

```text
Review setup
- Input scope:
- Assessment boundary:
- Shared manuscript claim summary:
- Visible evidence base:
- Missing materials affecting confidence:

Reviewer 1
- Overall assessment:
- Who would be interested in the results, and why:
- Major strengths:
- Major concerns:
- Technical failings that need to be addressed before the case is established:
- Assessment against Nature-style criteria:
- Recommendation posture:

Reviewer 2
[Same structure]

Reviewer 3
[Same structure]

Cross-review synthesis
- Consensus strengths:
- Consensus technical risks:
- Where emphasis differs across reviewers:
- Broad-interest / significance readout:
- Most important issues to resolve before a strong Nature-style case is established:

Risk / unsupported claims
- [specific unsupported or not-assessable items]
```

## Red lines

- Do not invent reviewer identities, specialty roles, or selection history.
- Do not invent experiments, validations, controls, citations, figure details, line numbers, or prior-work distinctions not present in the input.
- Do not silently turn reviewer assessment into author rebuttal drafting.
- Do not present the review as an editorial decision letter.
- Do not state that the manuscript belongs in `Nature` as a settled fact.
- Do not omit technical failings when the provided evidence does not establish the authors' case.

## Related files

| File | Open when |
|---|---|
| [references/source-basis.md](references/source-basis.md) | You need source provenance, local rule summaries, or source-vs-implementation boundaries |
| [references/reviewer-workflow.md](references/reviewer-workflow.md) | You need the invocation order, fact-base extraction flow, or synthesis rules |
| [references/review-axes.md](references/review-axes.md) | You need the evaluation axes or reviewer weighting logic |
| [references/report-structure.md](references/report-structure.md) | You need the default output contract or section anatomy |
| [references/role-boundaries.md](references/role-boundaries.md) | You need constraints on reviewer differences and editor-versus-reviewer boundaries |
| [references/qa-checklist.md](references/qa-checklist.md) | You are finalizing an output and need groundedness / non-invention checks |
| [references/editorial criteria and processes.md](references/editorial criteria and processes.md) | You need the primary local Nature source text |

## Examples

### Example 1: Complete manuscript pre-submission review

**Context:** A researcher has a full draft targeting a high-impact journal. They
want to identify weaknesses before submission.

**Input:** Full IMRaD manuscript (Introduction through Discussion), 8 figures,
supplementary methods.

**Process:**
1. Scope → full review, all 5 evaluation axes active.
2. Extract fact base: main claim is "novel mechanism X explains phenotype Y",
   evidence is genetic knockout + biochemical assay + structural model.
3. Generate Reviewer 1 (emphasis: mechanistic depth), Reviewer 2 (emphasis:
   statistical rigor and controls), Reviewer 3 (emphasis: broad significance
   and readability for non-specialists).
4. Cross-review synthesis flags consensus: "mechanism is promising but the in
   vivo evidence is correlational; a rescue experiment would strengthen the
   case substantially."

**Output:** 3 reviewer reports + synthesis, each grounded in specific manuscript
evidence with clear boundary on what was not assessable.

**Why this is good:** The review is grounded, the 3 reviewers differ only in
emphasis (not identity), technical failings are surfaced without invention, and
the synthesis gives the author a clear prioritization of what to fix.

---

### Example 2: Partial input (abstract only) — bounded review

**Context:** A researcher only has an abstract and wants to know if the idea is
worth developing into a full paper.

**Input:** 250-word abstract describing a computational method for predicting
protein-ligand binding, no experimental validation.

**Process:**
1. Scope → bounded review. Assessment boundary: "evaluating only the claimed
   contribution as described in the abstract; no methods/ results/ figures
   available."
2. All 5 axes assessed but explicitly marked with confidence level.
3. Reviewers note: "The computational approach is well-motivated, but without
   benchmark comparisons, ablation studies, or experimental validation, the
   current evidence is insufficient to establish the claimed advantage."

**Why this is good:** The review does NOT invent missing experiments or pretend
to have seen methods that weren't provided. The assessment boundary is clearly
stated at the top, so the author knows exactly what confidence to place in the
feedback. This is a bounded review, not a fake full review.

---

### Example 3: Anti-pattern — inventing reviewer identities

**What went wrong:** The agent wrote "Reviewer 1 is a structural biologist from
MIT with 15 years of experience in cryo-EM..." None of this was in the input.

**Consequence:** The user might believe the review carries institutional weight
that doesn't exist. The credibility of the whole assessment package is damaged.

**Corrected approach:** Reviewers differ only in emphasis (e.g. "Reviewer 1
focuses on mechanistic depth; Reviewer 2 focuses on statistical rigor"). No
names, institutions, biographies, or specialties are invented.

---

## Source hierarchy

Use sources in this order:

1. `references/editorial criteria and processes.md`
2. manuscript facts supplied by the user
3. conservative local implementation rules documented in `references/source-basis.md`

If a user asks for policy-level certainty beyond this local source, state the limit instead of improvising broader journal policy.
