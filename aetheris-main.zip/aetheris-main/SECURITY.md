# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 4.0.x   | ✅ |
| < 4.0   | ❌ |

## Reporting a Vulnerability

���请勿在公开 Issue 中报告安全漏洞。请通过邮件或私信联系维护者，包含：

- 漏洞描述与影响范围
- 复现步骤（最小示例）
- 受影响的版本

我们会在确认后尽快修复并发布安全公告。

## Security Notes

- **API Key 存储**：Provider 的 API Key 保存在用户主目录的 `~/.vibebase/providers.json`，**不会**写入项目目录或提交到仓库
- **沙箱执行**：`runShell` 工具仅允许白名单命令（见 `bin/lib/tools.js` 的 `SHELL_WHITELIST`）
- **文件访问**：`readFile`/`writeFile` 等工具经 `resolveSafe` 限制在项目根目录内
- **制品读取**：`/api/projects/artifact-content` 使用 `path.basename` 防目录穿越
