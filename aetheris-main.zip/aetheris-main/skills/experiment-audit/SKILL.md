# /experiment-audit
> Action: experiment-audit
> Category: Core Pipeline
> Triggers: "audit experiments,check results"

## Overview
Audit experiment logs for inconsistencies, cherry-picking, unreported failures.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/experiment-audit/SKILL.md` by the Aetheris skill loader.
