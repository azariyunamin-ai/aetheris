# /qzcli
> Action: qzcli
> Category: Tools
> Triggers: "GPU management,qizhi"

## Overview
Qizhi GPU cluster job management.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/qzcli/SKILL.md` by the Aetheris skill loader.
