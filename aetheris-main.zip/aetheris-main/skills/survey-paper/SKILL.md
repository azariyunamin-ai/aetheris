# /survey-paper
> Action: survey-paper
> Category: Research
> Triggers: "survey paper,literature review"

## Overview
Systematic survey paper writing.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/survey-paper/SKILL.md` by the Aetheris skill loader.
