# /citation-audit
> Action: citation-audit
> Category: Review Audit
> Triggers: "audit citations,check references"

## Overview
Fourth-layer citation audit. Verify every reference exists.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/citation-audit/SKILL.md` by the Aetheris skill loader.
