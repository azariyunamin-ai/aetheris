# /experiment-queue
> Action: experiment-queue
> Category: Core Pipeline
> Triggers: "queue experiments,batch runs"

## Overview
SSH multi-seed experiment queue with OOM retry and priority scheduling.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/experiment-queue/SKILL.md` by the Aetheris skill loader.
