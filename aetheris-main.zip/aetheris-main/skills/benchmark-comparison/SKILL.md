# /benchmark-comparison
> Action: benchmark-comparison
> Category: ML Data
> Triggers: "benchmark,compare SOTA"

## Overview
Benchmark comparison framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/benchmark-comparison/SKILL.md` by the Aetheris skill loader.
