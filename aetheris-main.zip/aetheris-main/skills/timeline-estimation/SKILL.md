# /timeline-estimation
> Action: timeline-estimation
> Category: PM
> Triggers: "timeline,estimate duration"

## Overview
Timeline estimation.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/timeline-estimation/SKILL.md` by the Aetheris skill loader.
