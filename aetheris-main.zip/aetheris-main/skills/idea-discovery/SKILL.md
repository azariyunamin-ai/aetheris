# /idea-discovery — Complete Idea Discovery Pipeline
> Action: idea-discovery
> Category: Core Pipeline
> Position: Literature survey → Idea generation
> Triggers: "find research gap", "new idea", "what to research"

## Pipeline
1. **Literature Scan** — find recent papers in the target area (last 2 years)
2. **Gap Analysis** — identify unaddressed questions, methodological weaknesses, unexplored combinations
3. **Idea Generation** — propose 3-5 concrete research directions
4. **Novelty Check** (`/novelty-check`) — for each idea, verify it hasn't been done before
5. **Feasibility Assessment** — check if the idea is executable with available resources
6. **Ranking** — score ideas on: novelty (1-10), feasibility (1-10), impact (1-10)
7. **Recommendation** — output top 1-2 ideas with justification

## Novelty Check Protocol
- Search arXiv, Semantic Scholar, Google Scholar
- Build a claim map of existing work
- For each proposed idea, check if any paper already claims it
- Flag "partial overlap" vs "direct conflict"

## Output Format
```markdown
## Gap Analysis
[Area]: [Specific gap identified]

## Candidate Ideas
### Idea 1: [Title]
- Novelty: X/10 — [justification]
- Feasibility: X/10 — [justification]
- Impact: X/10 — [justification]
- Related work: [papers to distinguish from]

## Recommended Direction
[Top idea with execution plan]
```
