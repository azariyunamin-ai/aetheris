# /dataset-creation
> Action: dataset-creation
> Category: ML Data
> Triggers: "create dataset,annotate"

## Overview
Dataset creation pipeline.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/dataset-creation/SKILL.md` by the Aetheris skill loader.
