# /meta-optimize
> Action: meta-optimize
> Category: Tools
> Triggers: "self improve,meta optimize"

## Overview
Self-evolution: analyze logs, propose SKILL.md patches.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/meta-optimize/SKILL.md` by the Aetheris skill loader.
