# /api-design
> Action: api-design
> Category: Code
> Triggers: "design API,REST,GraphQL"

## Overview
API design review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/api-design/SKILL.md` by the Aetheris skill loader.
