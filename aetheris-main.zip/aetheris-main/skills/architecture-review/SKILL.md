# /architecture-review
> Action: architecture-review
> Category: Code
> Triggers: "architecture review,system design"

## Overview
System architecture review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/architecture-review/SKILL.md` by the Aetheris skill loader.
