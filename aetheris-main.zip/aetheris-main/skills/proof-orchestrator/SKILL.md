# /proof-orchestrator
> Action: proof-orchestrator
> Category: Review Audit
> Triggers: "orchestrate proofs"

## Overview
Proof orchestrator: stateful proof campaign with memory.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/proof-orchestrator/SKILL.md` by the Aetheris skill loader.
