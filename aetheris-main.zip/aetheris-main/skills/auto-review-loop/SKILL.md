# /auto-review-loop
> Action: auto-review-loop
> Category: Review Audit
> Triggers: "auto review,self review"

## Overview
Automated review loop: reviewer finds issues, author fixes, re-review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/auto-review-loop/SKILL.md` by the Aetheris skill loader.
