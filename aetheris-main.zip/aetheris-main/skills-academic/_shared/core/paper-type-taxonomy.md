# Paper Type Taxonomy

A classification schema shared by `nature-writing`, `nature-polishing`, and `nature-reader` to select the correct structural template before drafting.

## Primary types

### Research Article (IMRaD)
The standard empirical-science paper.
- **Structure**: Introduction → Methods → Results → Discussion (IMRaD)
- **Goal**: present a novel empirical finding with reproducible evidence.
- **Key signals**: original data, experimental design, statistical tests, effect sizes.
- **Abstract**: 150 words structured (Background / Methods / Results / Conclusions).
- **Figure limit**: journal-dependent (Nature: ~6 display items; Nature Comms: 8-10).

### Review / Perspective
Synthesis of existing literature.
- **Structure**: flexible — thematic or chronological, with a clear narrative arc.
- **Goal**: identify trends, gaps, and future directions in a field.
- **Key signals**: no new data, systematic literature coverage, forward-looking conclusions.
- **Abstract**: 100-150 words unstructured.

### Brief Communication / Letter
Short-form empirical report.
- **Structure**: condensed IMRaD, often with methods in supplementary.
- **Goal**: rapid dissemination of striking or time-sensitive results.
- **Key signals**: 1-2 main figures, < 2000 words, no subheadings in some journals.

### Methods / Protocol
Step-by-step description of a technique.
- **Structure**: Introduction → Procedure → Anticipated Results → Troubleshooting.
- **Goal**: enable reproducible execution by other labs.
- **Key signals**: numbered steps, expected timelines, reagent tables.

### Chinese Empirical Article (CSSCI, empirical_cn)
The standard empirical paper in Chinese CSSCI journals (economics, management, finance, etc.).
- **Structure**: 摘要 → 引言 → 文献综述 → 模型构建（理论分析与研究假说）→ 结果分析（仿真分析/回归分析）→ 稳健性分析 → 异质性分析 → 敏感度分析 → 结论（含政策建议）→ 参考文献
- **Goal**: establish a causal/empirical claim with rigorous econometric identification.
- **Key signals**: 面板/截面数据、计量模型（固定效应、工具变量、DID、PSM）、内生性处理、稳健性/异质性/敏感度检验。
- **Abstract**: 结构化中文摘要（目的 / 方法 / 结果 / 结论），约 300–500 字。
- **Reference style**: GB/T 7714-2015 顺序编码制（正文 `[1][2]` 上标，文末按序列出）。
- **Data note**: 中文"数据来源与样本说明"（替代 Nature 的 Data Availability Statement）。
- Full section template: `readSkillFragment("_shared", "journal-formats/cssci.md")`.

## Selection rules
1. If you have **new, original data** with an experimental design → **Research Article**.
2. If the core contribution is **synthesis of published work** → **Review**.
3. If the result is striking but the story fits in 1-2 figures → **Brief Communication**.
4. If the contribution is a **reproducible technique** → **Methods/Protocol**.
5. If the paper is a **Chinese empirical study for CSSCI** (计量/实证, 因果识别) → **Chinese Empirical Article (empirical_cn)**.

When uncertain, default to Research Article with journal-specific IMRaD conventions.
