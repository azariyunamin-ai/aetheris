# /paper-illustration-image2
> Action: paper-illustration-image2
> Category: Rendering
> Triggers: "paper illustration,figure"

## Overview
Paper illustration generation.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-illustration-image2/SKILL.md` by the Aetheris skill loader.
