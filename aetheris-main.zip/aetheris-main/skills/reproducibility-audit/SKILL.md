# /reproducibility-audit
> Action: reproducibility-audit
> Category: Research
> Triggers: "reproducibility,replicate"

## Overview
Reproducibility audit.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/reproducibility-audit/SKILL.md` by the Aetheris skill loader.
