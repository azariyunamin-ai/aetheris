# /paper-claim-audit
> Action: paper-claim-audit
> Category: Paper Writing
> Triggers: "audit claims,verify paper"

## Overview
Audit every claim in a paper against its evidence sources.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-claim-audit/SKILL.md` by the Aetheris skill loader.
