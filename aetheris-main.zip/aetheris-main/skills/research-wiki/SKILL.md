# /research-wiki
> Action: research-wiki
> Category: Knowledge
> Triggers: "research wiki,knowledge base"

## Overview
Persistent research knowledge base across projects.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/research-wiki/SKILL.md` by the Aetheris skill loader.
