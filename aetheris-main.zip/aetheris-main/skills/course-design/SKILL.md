# /course-design
> Action: course-design
> Category: Education
> Triggers: "design course,syllabus"

## Overview
Course design framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/course-design/SKILL.md` by the Aetheris skill loader.
