# /grant-writing
> Action: grant-writing
> Category: Research
> Triggers: "grant proposal,funding"

## Overview
Grant proposal writing.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/grant-writing/SKILL.md` by the Aetheris skill loader.
