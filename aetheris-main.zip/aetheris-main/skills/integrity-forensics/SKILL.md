# /integrity-forensics
> Action: integrity-forensics
> Category: Review Audit
> Triggers: "integrity check,anti-autoresearch"

## Overview
Integrity forensics: detect 46+ cheating patterns.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/integrity-forensics/SKILL.md` by the Aetheris skill loader.
