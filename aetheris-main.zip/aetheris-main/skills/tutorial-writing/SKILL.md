# /tutorial-writing
> Action: tutorial-writing
> Category: Research
> Triggers: "tutorial,how-to guide"

## Overview
Tutorial writing.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/tutorial-writing/SKILL.md` by the Aetheris skill loader.
