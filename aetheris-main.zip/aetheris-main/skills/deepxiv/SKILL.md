# /deepxiv
> Action: deepxiv
> Category: Search
> Triggers: "DeepXiv,deep search"

## Overview
DeepXiv literature deep search.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/deepxiv/SKILL.md` by the Aetheris skill loader.
