# /novelty-check
> Action: novelty-check
> Category: Core Pipeline
> Triggers: "check novelty,has this been done"

## Overview
Verify research novelty. Cross-reference against arXiv, Semantic Scholar, Google Scholar.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/novelty-check/SKILL.md` by the Aetheris skill loader.
