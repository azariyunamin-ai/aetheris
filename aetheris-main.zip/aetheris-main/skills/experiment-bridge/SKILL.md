# /experiment-bridge
> Action: experiment-bridge
> Category: Core Pipeline
> Triggers: "connect idea to experiment"

## Overview
Bridge from research idea to concrete experiment design.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/experiment-bridge/SKILL.md` by the Aetheris skill loader.
