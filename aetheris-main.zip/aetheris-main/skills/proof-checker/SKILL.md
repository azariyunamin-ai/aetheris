# /proof-checker
> Action: proof-checker
> Category: Review Audit
> Triggers: "check proof,verify theorem"

## Overview
Proof checker with submission gate.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/proof-checker/SKILL.md` by the Aetheris skill loader.
