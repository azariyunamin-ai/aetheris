---
name: skill-name
description: >-
  One-line summary of what this skill does and when to trigger it.
  Include both English and Chinese trigger keywords.
  Example: "Polish academic prose to Nature-family publication quality..."
  Also trigger on: 论文润色, 润色, 改写, academic polishing, language editing...
type: component
intent: revise_section
best_for:
  - Scenario 1 where this skill shines (e.g. "Pre-submission language editing of a complete draft")
  - Scenario 2 (e.g. "Converting Chinese academic prose to publication-ready English")
  - Scenario 3 (e.g. "Checking paragraph-level coherence and flow")
version: 0.1.0
---

# Skill Title — Router / Entry Point

Brief purpose statement. What problem does this skill solve, and in what context should
an agent (or human) reach for it?

If this skill is a **router** (static/dynamic layered architecture), explain that here:
the dynamic layer detects request axes and loads only the needed fragments from
`static/` and `references/`.

If this skill delegates to a sibling skill for certain cases, state that clearly
(e.g. "For rebuttal drafting, route to `nature-response` instead").

---

## Input

What the skill can accept, and what happens when you come empty-handed.

This section follows the **invitation, not gate** principle: the user can walk in
with nothing and still get useful help. The skill will guide them through discovery.

Accepted inputs may include:

- Full manuscript / draft text
- Excerpts (abstract, introduction, results, discussion, methods)
- Figure legends, data notes, or preliminary observations
- Author notes in Chinese or English
- Pre-submission positioning notes

**Empty hands?** If the user provides nothing, the skill should ask 2-3 targeted
questions to scope the request before proceeding (see Key Concepts for the
diagnostic axes).

Inline input (provided by the user in the call) is treated as answered and is NOT
repeated back as a question.

---

## Key Concepts

The frameworks, mental models, definitions, and anti-patterns that this skill
embodies. This section should be self-contained enough that an agent reading it
can make judgment calls, not just follow a script.

### Diagnostic axes

What dimensions does this skill vary along? (e.g. paper_type, section, language, journal)

### Core principles

The irreducible rules. "Always X." "Never Y unless Z."

### Decision rules

"When you see A, choose B. When you see C, choose D."

### Terminology

Define any domain-specific terms used in this skill.

---

## Application

Step-by-step operational guide. Both an agent and a human should be able to follow
this to produce the skill's deliverable.

### Step 1 — Scope the request
...

### Step 2 — Gather context
...

### Step 3 — Execute
...

### Step 4 — Validate
...

### Step 5 — Deliver
...

If this skill has a **routing protocol** (static/dynamic), describe the routing
steps here: detect axes → load fragments → execute → validate.

---

## Common Pitfalls

Named failure modes, their consequences, and how to correct them.

### Pitfall 1: (Name)
- **What it looks like:** ...
- **Consequence:** ...
- **Fix:** ...

### Pitfall 2: (Name)
- **What it looks like:** ...
- **Consequence:** ...
- **Fix:** ...

---

## Examples

Concrete before/after demonstrations. Use fictional but realistic scenarios.

### Example 1: Good usage

**Context:** ...
**Input:** ...
**Process:** The skill does X, then Y, then Z.
**Output:** (snippet of the expected output)
**Why this is good:** ...

### Example 2: Bad usage / anti-pattern

**Context:** ...
**What went wrong:** ...
**Corrected approach:** ...

---

## References

Related skills and external frameworks, in a scannable table.

| File / Skill | Open when |
|---|---|
| [references/source-basis.md](references/source-basis.md) | ... |
| `nature-related-skill` | When the user asks for ... |
| External framework (e.g. IMRaD, Mom Test) | Link or citation |

### Source hierarchy

If this skill uses multiple authoritative sources, declare their priority order:

1. ...
2. ...
3. ...
