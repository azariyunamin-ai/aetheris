/**
 * Aetheris — features.html → PDF converter (headless Electron)
 * Usage: electron print-features.js <input.html> <output.pdf>
 */
const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');

const inputHtml = process.argv[2] || path.join(__dirname, '..', 'ui', 'features.html');
const outputPdf = process.argv[3] || path.join(__dirname, '..', 'dist', 'Aetheris-功能字典.pdf');

app.whenReady().then(async () => {
  const win = new BrowserWindow({
    width: 1280,
    height: 900,
    show: false,
    webPreferences: { offscreen: true },
  });

  try {
    await win.loadFile(inputHtml);
    // Wait for fonts/layout to settle
    await new Promise(r => setTimeout(r, 1200));

    const pdf = await win.webContents.printToPDF({
      pageSize: 'A4',
      printBackground: true,
      margins: { top: 0.6, bottom: 0.6, left: 0.5, right: 0.5 },
    });

    fs.mkdirSync(path.dirname(outputPdf), { recursive: true });
    fs.writeFileSync(outputPdf, pdf);
    console.log('PDF saved:', outputPdf, '(' + pdf.length + ' bytes)');
  } catch (err) {
    console.error('PDF conversion failed:', err.message);
    process.exitCode = 1;
  } finally {
    app.quit();
  }
});
