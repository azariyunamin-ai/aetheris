'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const llm = require('../bin/lib/llm');
const { createApproval } = require('../bin/lib/approve');
const data = require('../bin/lib/tools-data');
const { launchUI } = require('../bin/lib/server');

// ---- Intent routing + planner ----
test('mockRoute classifies empirical data goals', () => {
  assert.strictEqual(llm.mockRoute('请做实证回归分析'), 'empirical_analysis');
  assert.strictEqual(llm.mockRoute('描述性统计与数据清洗'), 'empirical_analysis');
  assert.strictEqual(llm.mockRoute('run a regression on the panel'), 'empirical_analysis');
});

test('empirical_analysis is a known intent', () => {
  assert.ok(llm.INTENTS.includes('empirical_analysis'));
});

test('mockPlan for empirical_analysis yields the data pipeline', async () => {
  const { parsed } = await llm.mockPlan({ domain: 'academic', intent: 'empirical_analysis', journal: 'CSSCI', language: 'zh' });
  const tools = parsed.plan.map(n => n.tool);
  for (const t of ['dataImport', 'dataClean', 'dataTransform', 'dataDescribe', 'dataRegress', 'dataExport']) {
    assert.ok(tools.includes(t), 'missing ' + t);
  }
  // zh branch should produce Chinese section titles
  assert.ok(parsed.plan.some(n => /中文|实证|数据/.test(n.title)), 'expected Chinese-titled nodes');
});

// ---- askUser mechanism ----
test('askUser auto mode returns the academic convention (first option)', async () => {
  const a = createApproval({ mode: 'auto' });
  const ans = await a.ask('缺失值如何处理？', ['均值填充', '删除行', '按学界通用做法']);
  assert.strictEqual(ans, '均值填充');
});

test('askUser server mode pauses and resolves via _resolveQuestion', async () => {
  const session = { pendingQuestion: null, _resolveQuestion: null };
  const a = createApproval({ mode: 'server', session });
  const p = a.ask('异常值如何处理？', ['IQR 删除', '缩尾 winsorize', '按学界通用做法']);
  // It must be pending before resolution
  assert.ok(session.pendingQuestion && session.pendingQuestion.question.includes('异常值'));
  assert.strictEqual(session.pendingQuestion.options.length, 3);
  session._resolveQuestion('缩尾 winsorize');
  const ans = await p;
  assert.strictEqual(ans, '缩尾 winsorize');
  assert.strictEqual(session.pendingQuestion, null);
});

// ---- Data tool input validation (no python needed) ----
test('dataImport rejects empty files without invoking python', async () => {
  const r = await data.dataImport(process.cwd(), {});
  assert.strictEqual(r.ok, false);
  assert.match(r.error, /files/);
});

test('data tools report a helpful error when no pandas python exists', async () => {
  const prev = process.env.VIBEBASE_PYTHON;
  process.env.VIBEBASE_PYTHON = path.join(os.tmpdir(), 'no-such-python-xyz.exe');
  try {
    const r = await data.dataClean(process.cwd(), { file: 'x.csv' });
    assert.strictEqual(r.ok, false);
    assert.ok(r.hint && /pip install/.test(r.hint), 'expected pip install hint, got ' + JSON.stringify(r));
  } finally {
    if (prev === undefined) delete process.env.VIBEBASE_PYTHON; else process.env.VIBEBASE_PYTHON = prev;
  }
});

// ---- Registry merge ----
test('academic registry exposes the data tools + askUser schema slot', () => {
  const reg = require('../bin/lib/server').academicRegistry();
  for (const t of ['dataImport', 'dataClean', 'dataTransform', 'dataDescribe', 'dataRegress', 'dataExport']) {
    assert.ok(reg.tools[t], 'registry missing ' + t);
  }
  // dataDescribe / dataRegress are read-only (low risk); import/clean/transform high risk
  assert.strictEqual(reg.riskLevel('dataDescribe'), 'low');
  assert.strictEqual(reg.riskLevel('dataImport'), 'high');
});

// ---- Full wiring e2e: empirical_analysis intent flows to the run state ----
test('POST /api/agent/run empirical_analysis surfaces intent+journal+language', async () => {
  process.env.VIBEBASE_NO_OPEN = '1';
  process.env.VIBEBASE_PROVIDER = 'mock';
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vb-data-'));
  fs.mkdirSync(path.join(tmp, '.vibe'), { recursive: true });
  const server = launchUI(tmp, { noOpen: true });
  await new Promise(r => server.listening ? r() : server.once('listening', r));
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;
  const post = (url, body) => new Promise((res, rej) => {
    const data = JSON.stringify(body);
    const req = http.request(base + url, { method: 'POST', agent: false, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), 'Connection': 'close' } }, r => {
      let o = ''; r.on('data', c => o += c); r.on('end', () => { try { r.destroy(); } catch (e) {} res({ status: r.statusCode, body: o }); });
    });
    req.on('error', rej); req.write(data); req.end();
  });
  const get = (url) => new Promise((res, rej) => {
    http.get(base + url, { agent: false, headers: { 'Connection': 'close' } }, r => { let o = ''; r.on('data', c => o += c); r.on('end', () => { try { r.destroy(); } catch (e) {} res(JSON.parse(o)); }); }).on('error', rej);
  });
  try {
    await post('/api/agent/run', { goal: '实证分析数字金融对碳排放的影响', domain: 'academic', intent: 'empirical_analysis', journal: 'CSSCI', language: 'zh' });
    const st = await get('/api/agent/status');
    assert.strictEqual(st.intent, 'empirical_analysis');
    assert.strictEqual(st.journal, 'CSSCI');
    assert.strictEqual(st.language, 'zh');
  } finally {
    // Force-close any lingering keep-alive sockets, then await the server
    // fully shutting down so node --test can finalize.
    try { if (server.closeAllConnections) server.closeAllConnections(); } catch (e) { /* ignore */ }
    await new Promise(r => server.close(r));
  }
});
