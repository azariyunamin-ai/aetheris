# /run-experiment
> Action: run-experiment
> Category: Core Pipeline
> Triggers: "run experiment,execute training"

## Overview
Experiment execution. Design, run, and log results with reproducible configs.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/run-experiment/SKILL.md` by the Aetheris skill loader.
