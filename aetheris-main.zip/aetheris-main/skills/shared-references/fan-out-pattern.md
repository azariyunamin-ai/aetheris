# fan-out-pattern.md
