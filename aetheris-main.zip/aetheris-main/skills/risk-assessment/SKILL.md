# /risk-assessment
> Action: risk-assessment
> Category: PM
> Triggers: "risk analysis,what if"

## Overview
Risk assessment framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/risk-assessment/SKILL.md` by the Aetheris skill loader.
