# /auto-review-loop-llm
> Action: auto-review-loop-llm
> Category: Review Audit
> Triggers: "LLM review,DeepSeek review"

## Overview
Auto review loop using LLM backend.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/auto-review-loop-llm/SKILL.md` by the Aetheris skill loader.
