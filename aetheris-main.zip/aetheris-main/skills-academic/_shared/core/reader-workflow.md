# Reader Workflow (5-Step Question Sequence)

A shared mental model for evaluating scientific manuscripts. Used by `nature-writing` (so drafts answer reader questions) and `nature-polishing` (so revisions strengthen reader-facing clarity). Also referenced by `nature-reader` for source evaluation.

## The 5-Step Reader Question Sequence

For every section — and ultimately the whole paper — a skeptical reader asks five questions in order. The manuscript should answer each before the next one is prompted.

### 1. What is the claim?
Every paragraph, figure, and section should have ONE central claim. State it early.
- Bad: "We performed several analyses showing interesting patterns."
- Good: "IL-6 serum levels were significantly elevated in patients with active disease (p < 0.001, n=142)."

### 2. How was it measured?
Describe the method, sample size, controls, and statistical test used to support the claim.
- Include: instrument/model, n, replicates, blinding, pre-registration.
- Never bury methods in supplementary unless the journal explicitly allows it.

### 3. Is the evidence sufficient?
Critically evaluate whether the data support the claim at the stated strength.
- Are error bars appropriate (SD vs SEM)?
- Is the sample size adequate for the effect size?
- Are confounding variables addressed?
- Were multiple comparisons corrected?

### 4. What are the boundaries?
Every claim has limits. State them explicitly.
- "This finding applies to adult patients with type 2 diabetes; generalization to pediatric populations requires further study."
- "The model was trained on European data and may not generalise to Asian populations."

### 5. Does this advance the field?
Place the finding in context: what was known before, what this adds, what it enables next.
- Not "this is novel" — show the gap and how this fills it.
- Use the IMRaD Discussion structure: summary → interpretation → comparison → limitations → implications.

## Application rules
- **Drafting**: before writing each section, answer these 5 questions in order. The answers become the section's structure.
- **Polishing**: check each paragraph against this sequence. If a paragraph doesn't answer question 1, it has no claim. If it answers 1 but skips 2-3, it's unfounded. If it skips 4, it overclaims.
- **Reading**: evaluate a source paper by scoring how well it answers these questions. Papers that fail questions 1-3 are low-quality; papers that answer 1-3 but skip 4-5 are preliminary.
