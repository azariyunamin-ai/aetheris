# Reviewer Routing — Dual-model adversarial review pipeline

## Architecture
Executor model ≠ Reviewer model. Two separate LLM providers with different parameters.

## Routing Rules
- **Executor**: Default provider (VIBEBASE_PROVIDER) — temperature 0.7, full tool access
- **Reviewer**: Reviewer provider (VIBEBASE_REVIEWER_PROVIDER) — temperature 0.1, read-only tools only
- **Consolidator**: Default provider — temperature 0.3, resolves Executor vs Reviewer conflicts

## Interaction Protocol
1. Executor completes task → produces output + claims
2. Reviewer analyzes output → identifies weaknesses, scores each claim (1-10)
3. Consolidator receives both → resolves disputes, produces final report
4. Loop: if >3 claims scored <5/10, return to Executor for revision

## Model Selection
- Recommended: Executor=GPT-5/Claude, Reviewer=DeepSeek/GPT-5 with different seed
- Never use the same model+seed for both — defeats adversarial purpose
