# /render-html
> Action: render-html
> Category: Rendering
> Triggers: "render HTML,markdown to html"

## Overview
Markdown to HTML renderer.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/render-html/SKILL.md` by the Aetheris skill loader.
