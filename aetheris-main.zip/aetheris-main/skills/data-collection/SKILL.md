# /data-collection
> Action: data-collection
> Category: ML Data
> Triggers: "collect data,gather dataset"

## Overview
Data collection strategy.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/data-collection/SKILL.md` by the Aetheris skill loader.
