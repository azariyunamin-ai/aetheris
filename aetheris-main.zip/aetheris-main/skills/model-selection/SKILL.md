# /model-selection
> Action: model-selection
> Category: ML Data
> Triggers: "choose model,model comparison"

## Overview
Model selection framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/model-selection/SKILL.md` by the Aetheris skill loader.
