# /rebuttal
> Action: rebuttal
> Category: Paper Writing
> Triggers: "write rebuttal,review response"

## Overview
Review rebuttal: parse reviewer comments, formulate strategy, draft response.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/rebuttal/SKILL.md` by the Aetheris skill loader.
