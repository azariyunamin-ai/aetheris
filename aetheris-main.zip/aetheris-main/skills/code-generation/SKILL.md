# /code-generation
> Action: code-generation
> Category: Code
> Triggers: "generate code,write function"

## Overview
Code generation with test-first approach.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/code-generation/SKILL.md` by the Aetheris skill loader.
