# /figure-spec
> Action: figure-spec
> Category: Rendering
> Triggers: "figure specification"

## Overview
Figure specification for paper illustrations.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/figure-spec/SKILL.md` by the Aetheris skill loader.
