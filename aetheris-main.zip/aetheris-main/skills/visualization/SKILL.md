# /visualization
> Action: visualization
> Category: ML Data
> Triggers: "visualize data,plot,chart"

## Overview
Data visualization generator.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/visualization/SKILL.md` by the Aetheris skill loader.
