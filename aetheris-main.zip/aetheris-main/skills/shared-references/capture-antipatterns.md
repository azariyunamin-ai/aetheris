# capture-antipatterns.md
