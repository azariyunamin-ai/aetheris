# /method-figure
> Action: method-figure
> Category: Rendering
> Triggers: "method figure,flowchart"

## Overview
Method flowchart figure generation.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/method-figure/SKILL.md` by the Aetheris skill loader.
