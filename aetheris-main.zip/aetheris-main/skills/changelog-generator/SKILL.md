# /changelog-generator
> Action: changelog-generator
> Category: Docs
> Triggers: "changelog,release notes"

## Overview
Changelog generator.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/changelog-generator/SKILL.md` by the Aetheris skill loader.
