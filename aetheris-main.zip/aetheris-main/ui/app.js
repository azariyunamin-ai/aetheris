/* ==========================================================================
   Aetheris UI — Peng Haoyun
   Frontend logic: sidebar + chat + preview panel.
   Preserves all SSE/REST API compatibility with backend.
   ========================================================================== */

// ---------- State ----------
const state = {
  activePanel: 'chat',
  theme: localStorage.getItem('vibebase-theme') || 'light',
  projectName: 'Loading...',
  activeProjectDir: '',
  projects: [],
  gitBranch: '',
  agentRunning: false,
  sessionId: null,
  currentIntent: '',
  currentJournal: 'Nature',
  currentLanguage: 'en',
  lang: localStorage.getItem('vibebase-lang') || 'zh',
  // SSE polling
  pendingApproval: null,
  pendingQuestion: null,
  planNodes: [],
  planApproved: false,
};

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', () => {
  applyTheme(state.theme);
  loadDashboard();
  loadProjects();
  loadProjectInfo();
  loadSecurity();
  loadGoals();
  updateLangUI();
  bindEvents();
  loadWorkflows();
  loadSessionList();
  loadRuns();
  loadSchedules();
  loadMemory();
  pollAgentState();
  initMotion();
  initVoidCanvas();
  initResizeHandles();
});

/* ==========================================================================
   RESIZABLE PANELS — embedded handles inside sidebar / preview
   ========================================================================== */
function initResizeHandles() {
  ['resize-sidebar', 'resize-preview'].forEach(id => {
    const h = document.getElementById(id);
    if (!h) return;
    const isSidebar = id === 'resize-sidebar';
    const cssVar = isSidebar ? '--sidebar-w' : '--preview-w';
    const min = isSidebar ? 48 : 200, max = isSidebar ? 200 : 600;
    const lsKey = isSidebar ? 'vibebase-sidebar-w' : 'vibebase-preview-w';

    // Restore saved width
    const saved = localStorage.getItem(lsKey);
    if (saved) document.documentElement.style.setProperty(cssVar, saved + 'px');

    let dragging = false, startX, startW;
    h.addEventListener('mousedown', (e) => {
      e.preventDefault(); e.stopPropagation();
      dragging = true; startX = e.clientX;
      startW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue(cssVar)) || min;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      document.querySelector('.app-layout').style.transition = 'none';
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const delta = isSidebar ? (e.clientX - startX) : -(e.clientX - startX);
      document.documentElement.style.setProperty(cssVar, Math.max(min, Math.min(max, startW + delta)) + 'px');
    });
    document.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      document.querySelector('.app-layout').style.transition = '';
      const w = parseFloat(getComputedStyle(document.documentElement).getPropertyValue(cssVar));
      if (w) localStorage.setItem(lsKey, Math.round(w));
    });
  });
}

/* ==========================================================================
   VOID CANVAS — Dala particle field (tiny triangles scattered on black)
   ========================================================================== */
function initVoidCanvas() {
  const container = document.getElementById('void-canvas');
  if (!container) return;
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // --- Config ---
  const PARTICLE_COUNT = 280;
  const SHAPE_PARTICLES = 210;  // form the constellation
  const AMBIENT = 70;           // drift freely
  const CONNECT_DIST = 90;
  const SPRING = 0.012;         // attraction to target
  const DAMPING = 0.94;
  const MOUSE_REPEL_RANGE = 120;
  const MOUSE_REPEL_FORCE = 0.25;
  const CLICK_BURST_RANGE = 200;
  const CLICK_BURST_FORCE = 4.5;
  const MAX_ROT = 0.06;         // ~3.5° — subtle, not distracting
  const ROT_LERP = 0.04;       // smooth follow (inertia)

  // --- Linear + Cursor palette ---
  const PALETTE_DARK = [
    { r: 94,  g: 106, b: 210 },{ r: 130, g: 143, b: 255 },
    { r: 223, g: 168, b: 143 },{ r: 159, g: 201, b: 162 },
    { r: 159, g: 187, b: 224 },{ r: 192, g: 168, b: 221 },
  ];
  const PALETTE_LIGHT = [
    { r: 94,  g: 106, b: 210 },{ r: 79,  g: 91,  b: 196 },
    { r: 184, g: 122, b: 94  },{ r: 110, g: 154, b: 113 },
    { r: 110, g: 138, b: 176 },{ r: 142, g: 120, b: 176 },
  ];
  function getPalette() { return document.body.classList.contains('theme-dark') ? PALETTE_DARK : PALETTE_LIGHT; }
  function isDark() { return document.body.classList.contains('theme-dark'); }

  // ====================================================================
  //  SHAPE GENERATORS — each returns N points in [0,1]×[0,1] space
  // ====================================================================
  function brainShape(n) {
    // Organic neural cluster — multiple gaussian blobs overlapping
    const pts = [];
    const clusters = [
      { cx: 0.42, cy: 0.48, r: 0.28, w: 0.45 },
      { cx: 0.56, cy: 0.44, r: 0.24, w: 0.20 },
      { cx: 0.50, cy: 0.58, r: 0.20, w: 0.25 },
      { cx: 0.44, cy: 0.36, r: 0.16, w: 0.10 },
    ];
    for (let i = 0; i < n; i++) {
      let c = clusters[i % clusters.length];
      let angle = Math.random() * Math.PI * 2;
      let radius = c.r * (0.3 + Math.random() * 0.7);
      // Add noise to make it biological, not perfect spheres
      let noise = (Math.random() - 0.5) * 0.06;
      pts.push({
        x: c.cx + Math.cos(angle) * radius + noise,
        y: c.cy + Math.sin(angle) * radius + noise,
      });
    }
    return pts;
  }

  function docShape(n) {
    // Document/page — horizontal text lines in a rectangular block
    const pts = [];
    const left = 0.18, right = 0.82, top = 0.18, bottom = 0.78;
    const lines = 18;
    // Outline
    for (let i = 0; i < n * 0.2; i++) {
      let t = Math.random();
      if (t < 0.5) pts.push({ x: left + (right-left)*(Math.random()<0.5?1:0), y: top + (bottom-top)*Math.random() });
      else pts.push({ x: left + (right-left)*Math.random(), y: top + (bottom-top)*(Math.random()<0.5?1:0) });
    }
    // Horizontal lines + fold corner
    for (let i = 0; i < n * 0.6; i++) {
      let y = top + ((i % lines) / (lines-1)) * (bottom - top);
      pts.push({ x: left + Math.random() * (right - left), y: y + (Math.random()-0.5)*0.008 });
    }
    // Folded corner triangle
    for (let i = 0; i < n * 0.2; i++) {
      let t = Math.random();
      pts.push({ x: right - t * 0.08, y: top + t * 0.10 });
    }
    return pts;
  }

  function chartShape(n) {
    // Rising bars (data visualization)
    const pts = [];
    const bars = 6, barW = 0.08, gap = 0.04, startX = 0.15;
    const heights = [0.3, 0.5, 0.38, 0.62, 0.45, 0.72];
    for (let i = 0; i < n; i++) {
      let b = i % bars;
      let bx = startX + b * (barW + gap);
      let h = heights[b];
      pts.push({
        x: bx + Math.random() * barW,
        y: 0.82 - Math.random() * h,
      });
    }
    return pts;
  }

  function waveShape(n) {
    // Sine wave — 2.5 cycles
    const pts = [];
    const cx = 0.5, cy = 0.50, amp = 0.25, cycles = 2.5;
    for (let i = 0; i < n; i++) {
      let x = 0.08 + (i / n) * 0.84;
      let y = cy + Math.sin(x * Math.PI * 2 * cycles) * amp + (Math.random() - 0.5) * 0.02;
      pts.push({ x: x, y: y });
    }
    return pts;
  }

  function radarShape(n) {
    // Hexagonal radar + radial spokes
    const pts = [];
    const cx = 0.5, cy = 0.50;
    const sides = 6, rings = 3;
    for (let i = 0; i < n * 0.5; i++) {
      let ring = 1 + Math.floor(Math.random() * rings);
      let r = ring / rings * 0.35;
      let angle = (Math.floor(Math.random() * sides * 6) / (sides * 6)) * Math.PI * 2;
      pts.push({ x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r });
    }
    for (let i = 0; i < n * 0.3; i++) {
      let side = i % sides;
      let angle = (side / sides) * Math.PI * 2 - Math.PI / 2;
      let r = (0.05 + Math.random() * 0.35);
      pts.push({ x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r });
    }
    for (let i = 0; i < n * 0.2; i++) {
      pts.push({ x: cx + (Math.random()-0.5)*0.1, y: cy + (Math.random()-0.5)*0.1 });
    }
    return pts;
  }

  function gearShape(n) {
    // Circle with teeth
    const pts = [];
    const cx = 0.5, cy = 0.50;
    const teeth = 8, inner = 0.18, outer = 0.34;
    for (let i = 0; i < n; i++) {
      let angle = (i / n) * Math.PI * 2;
      let tooth = Math.floor((angle / (Math.PI * 2)) * teeth);
      let toothAngle = (tooth + 0.5) / teeth * Math.PI * 2;
      let dist = Math.sin(tooth * 4) > 0.7 ? outer + (Math.random()-0.5)*0.04 : inner + Math.random() * 0.04;
      pts.push({ x: cx + Math.cos(angle) * dist, y: cy + Math.sin(angle) * dist });
    }
    return pts;
  }

  const SHAPES = { chat: brainShape, paper: docShape, data: chartShape, plot: waveShape, dashboard: radarShape, settings: gearShape };

  // --- State ---
  const particles = [];
  const mouse = { x: -500, y: -500, active: false };
  let mouseIdleTimer = 0, lastPanel = '', smoothedRot = 0;
  let w = canvas.width, h = canvas.height;

  function resize() { w = canvas.width = container.offsetWidth; h = canvas.height = container.offsetHeight; }
  resize();
  window.addEventListener('resize', resize);

  // --- Create particles ---
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.2, vy: (Math.random() - 0.5) * 0.2,
      tx: 0, ty: 0,   // target (set by setShape)
      size: 1.5 + Math.random() * 4,
      colorIdx: Math.floor(Math.random() * 6),
      alpha: 0.28 + Math.random() * 0.42,
      pulse: Math.random() * Math.PI * 2,
      isShape: i < SHAPE_PARTICLES,
      wanderAngle: Math.random() * Math.PI * 2,
      wanderSpeed: 0.003 + Math.random() * 0.005,
    });
  }

  // --- Assign shape targets ---
  function setShape(panelId) {
    panelId = panelId || 'chat';
    if (!SHAPES[panelId]) panelId = 'chat';
    const gen = SHAPES[panelId];
    const pts = gen(SHAPE_PARTICLES);
    for (let i = 0; i < SHAPE_PARTICLES; i++) {
      if (pts[i]) {
        particles[i].tx = pts[i].x * w;
        particles[i].ty = pts[i].y * h;
      }
    }
    lastPanel = panelId;
  }
  setShape('chat');

  // --- Mouse ---
  document.addEventListener('mousemove', function(e) {
    mouse.x = e.clientX; mouse.y = e.clientY;
    mouse.active = true; mouseIdleTimer = 0;
  });
  document.addEventListener('click', function(e) {
    if (MOTION.reduce) return;
    const cx = e.clientX, cy = e.clientY;
    particles.forEach(p => {
      const dx = p.x - cx, dy = p.y - cy;
      const dist = Math.hypot(dx, dy);
      if (dist < CLICK_BURST_RANGE && dist > 2) {
        const f = CLICK_BURST_FORCE * (1 - dist / CLICK_BURST_RANGE);
        p.vx += (dx / dist) * f; p.vy += (dy / dist) * f;
      }
    });
  });

  // --- Draw ---
  function draw() {
    if (MOTION.reduce || document.hidden) { requestAnimationFrame(draw); return; }

    mouseIdleTimer++;
    if (mouseIdleTimer > 120) mouse.active = false;

    // Track panel switch → morph to new shape
    if (state.activePanel !== lastPanel) setShape(state.activePanel);

    const palette = getPalette();
    const dark = isDark();
    ctx.clearRect(0, 0, w, h);

    // Constellation rotation toward mouse (lerped, subtle)
    const cx = w / 2, cy = h / 2;
    const mdx = mouse.x - cx, mdy = mouse.y - cy;
    const mouseDist = Math.hypot(mdx, mdy);
    const targetRot = Math.atan2(mdy, mdx) * Math.min(MAX_ROT, mouseDist / 1200);
    smoothedRot += (targetRot - smoothedRot) * ROT_LERP;
    const cos = Math.cos(smoothedRot), sin = Math.sin(smoothedRot);

    // Update
    particles.forEach(p => {
      if (p.isShape) {
        // Spring toward rotated target
        let rx = p.tx - cx, ry = p.ty - cy;
        let trx = rx * cos - ry * sin + cx;
        let try_ = rx * sin + ry * cos + cy;
        p.vx += (trx - p.x) * SPRING;
        p.vy += (try_ - p.y) * SPRING;
      } else {
        // Ambient wander
        p.wanderAngle += p.wanderSpeed;
        p.vx += Math.cos(p.wanderAngle) * 0.02;
        p.vy += Math.sin(p.wanderAngle) * 0.02;
      }
      // Mouse repel (all particles)
      if (mouse.active) {
        const dx = p.x - mouse.x, dy = p.y - mouse.y;
        const dist = Math.hypot(dx, dy);
        if (dist < MOUSE_REPEL_RANGE && dist > 2) {
          const f = MOUSE_REPEL_FORCE * (1 - dist / MOUSE_REPEL_RANGE);
          p.vx += (dx / dist) * f;
          p.vy += (dy / dist) * f;
        }
      }
      p.vx *= DAMPING; p.vy *= DAMPING;
      p.x += p.vx; p.y += p.vy;
      if (p.x < -40) p.x = w + 40; if (p.x > w + 40) p.x = -40;
      if (p.y < -40) p.y = h + 40; if (p.y > h + 40) p.y = -40;
      p.pulse += 0.007;
    });

    // --- Constellation lines ---
    const linkColor = palette[0];
    ctx.lineWidth = 0.7;
    for (let i = 0; i < SHAPE_PARTICLES; i++) {
      for (let j = i + 1; j < SHAPE_PARTICLES; j++) {
        const a = particles[i], b = particles[j];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < CONNECT_DIST) {
          const o = (1 - dist / CONNECT_DIST) * (dark ? 0.16 : 0.10);
          ctx.strokeStyle = 'rgba(' + linkColor.r + ',' + linkColor.g + ',' + linkColor.b + ',' + o.toFixed(2) + ')';
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }

    // --- Draw particles ---
    particles.forEach(p => {
      const c = palette[p.colorIdx];
      const a = p.alpha + Math.sin(p.pulse) * 0.06;
      const s = p.size;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(Math.atan2(p.vy, p.vx) + 0.2);
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.lineTo(s * 0.6, s * 0.5);
      ctx.lineTo(-s * 0.6, s * 0.5);
      ctx.closePath();
      ctx.strokeStyle = 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + Math.max(0.07, a).toFixed(2) + ')';
      ctx.lineWidth = dark ? 1.0 : 1.3;
      ctx.stroke();
      if (dark) {
        ctx.fillStyle = 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + Math.max(0.02, a * 0.35).toFixed(2) + ')';
        ctx.fill();
      }
      ctx.restore();
    });

    requestAnimationFrame(draw);
  }

  draw();
}

/* ==========================================================================
   WORKFLOW PILLS + SESSION MANAGEMENT (ARIS / EvoScientist patterns)
   ========================================================================== */
let currentWorkflow = '';

async function loadWorkflows() {
  const bar = document.getElementById('workflow-bar');
  if (!bar) return;
  try {
    const res = await fetch('/api/workflows');
    if (!res.ok) return;
    const workflows = await res.json();
    bar.style.display = 'flex';
    const isZh = state.lang === 'zh';
    bar.innerHTML = workflows.map(w =>
      '<span class="wf-pill" data-wf="' + w.id + '" data-name="' + (w.name || '') + '" data-name-zh="' + (w.nameZh || w.name || '') + '" title="' + (w.desc || '') + '">' + (isZh && w.nameZh ? w.nameZh : w.name) + '</span>'
    ).join('');
    bar.querySelectorAll('.wf-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        const wfId = pill.dataset.wf;
        const wf = workflows.find(w => w.id === wfId);
        if (!wf) return;
        if (currentWorkflow === wfId) {
          currentWorkflow = '';
          bar.querySelectorAll('.wf-pill').forEach(p => p.classList.remove('active'));
          return;
        }
        currentWorkflow = wfId;
        state.currentWorkflowName = wf.name || '';
        state.currentWorkflowNameZh = wf.nameZh || wf.name || '';
        bar.querySelectorAll('.wf-pill').forEach(p => p.classList.toggle('active', p.dataset.wf === wfId));
        const input = document.getElementById('chat-input');
        const wfName = (state.lang === 'zh' && wf.nameZh) ? wf.nameZh : wf.name;
        if (input) { input.placeholder = '[' + wfName + '] 描述你的研究需求…'; input.focus(); }
        state.currentIntent = wf.intent;
        state.currentWorkflowDomain = wf.domain || '';
        localStorage.setItem('vibebase-workflow', wfId);
        // Visual feedback so the user sees the mode is active
        const bar2 = document.getElementById('workflow-bar');
        if (bar2) {
          const label = bar2.querySelector('.wf-active-label');
          if (label) label.textContent = '当前模式: ' + (state.lang === 'zh' ? wf.nameZh : wf.name);
        }
      });
    });
    const saved = localStorage.getItem('vibebase-workflow');
    if (saved) {
      const pill = bar.querySelector('.wf-pill[data-wf="' + saved + '"]');
      if (pill) pill.click();
    }
  } catch(e) {}
}

async function saveSession() {
  try {
    const res = await fetch('/api/sessions/save', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ label: state.sessionLabel || '' })
    });
    if (res.ok) { showToast('会话已保存', 'success'); loadSessionList(); }
  } catch(e) { showToast('保存失败', 'error'); }
}

async function loadSession(id) {
  try {
    const res = await fetch('/api/sessions/load', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (res.ok) showToast('会话已恢复', 'success');
    else { const e = await res.json(); showToast(e.error || '加载失败', 'error'); }
  } catch(e) { showToast('加载失败', 'error'); }
}

async function deleteSession(id) {
  if (!confirm('确定删除此会话？')) return;
  try {
    await fetch('/api/sessions/delete', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    showToast('已删除', 'success'); loadSessionList();
  } catch(e) { showToast('删除失败', 'error'); }
}

async function loadSessionList() {
  const container = document.getElementById('session-list');
  if (!container) return;
  try {
    const res = await fetch('/api/sessions');
    if (!res.ok) return;
    const sessions = await res.json();
    if (!sessions.length) { container.innerHTML = '<div style="padding:6px 12px;font-size:10px;color:var(--text-tertiary)">' + t('session.empty') + '</div>'; return; }
    container.innerHTML = sessions.slice(0, 8).map(s =>
      '<div class="session-row" data-sid="' + s.id + '" style="display:flex;align-items:center;justify-content:space-between;padding:4px 10px;cursor:pointer;font-size:11px;border-radius:6px"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">' + (s.label || s.goal || 'Untitled').substring(0, 40) + '</span><span style="color:var(--text-tertiary);font-size:9px;flex-shrink:0;margin-left:4px" onclick="event.stopPropagation();deleteSession(\'' + s.id + '\')">✕</span></div>'
    ).join('');
    container.querySelectorAll('.session-row').forEach(row => {
      row.addEventListener('mouseenter', () => row.style.background = 'var(--bg-surface-hover)');
      row.addEventListener('mouseleave', () => row.style.background = 'transparent');
      row.addEventListener('click', () => loadSession(row.dataset.sid));
    });
  } catch(e) {}
}

/* ==========================================================================
   RUN HISTORY DASHBOARD + SCHEDULE PANEL (karpathy / EvoScientist patterns)
   ========================================================================== */
async function loadRuns() {
  const container = document.getElementById('runs-content');
  if (!container) return;
  try {
    const res = await fetch('/api/runs');
    if (!res.ok) return;
    const runs = await res.json();
    if (!runs.length) { container.innerHTML = '<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg><h4>' + t('runs.empty_title') + '</h4><p>' + t('runs.empty') + '</p></div>'; return; }
    const recent = runs.slice(-20).reverse();
    // Simple bar chart of durations
    const maxDur = Math.max(...recent.map(r => r.durationMs || 0), 1);
    const chartHtml = '<div style="display:flex;align-items:flex-end;gap:3px;height:40px;margin-bottom:10px">' +
      recent.map(r => {
        const h = Math.max(3, ((r.durationMs || 0) / maxDur) * 38);
        const bg = r.status === 'done' ? 'var(--accent)' : 'var(--danger)';
        return '<div title="' + (r.goal || '').substring(0,40) + ': ' + Math.round((r.durationMs||0)/1000) + 's" style="flex:1;height:'+h+'px;background:'+bg+';border-radius:2px;opacity:0.7;min-width:6px"></div>';
      }).join('') + '</div>';
    // Table
    const rows = recent.map(r =>
      '<tr>' +
      '<td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + (r.goal||'') + '">' + (r.goal||'?').substring(0,30) + '</td>' +
      '<td>' + (r.domain||'-') + '/' + (r.intent||'-') + '</td>' +
      '<td>' + (r.steps||0) + '</td>' +
      '<td>' + Math.round((r.durationMs||0)/1000) + 's</td>' +
      '<td><span style="color:' + (r.status==='done'?'var(--success)':'var(--danger)') + '">' + (r.status||'?') + '</span></td>' +
      '<td style="font-size:9px;color:var(--text-tertiary)">' + (r.completedAt ? new Date(r.completedAt).toLocaleString('zh-CN').slice(5) : '-') + '</td>' +
      '</tr>'
    ).join('');
    container.innerHTML = chartHtml +
      '<table style="width:100%;font-size:11px;border-collapse:collapse">' +
      '<thead><tr style="color:var(--text-tertiary);border-bottom:1px solid var(--border-subtle)"><th style="text-align:left;padding:2px 4px">Goal</th><th style="text-align:left;padding:2px 4px">Domain</th><th style="text-align:left;padding:2px 4px">Steps</th><th style="text-align:left;padding:2px 4px">Dur</th><th style="text-align:left;padding:2px 4px">Status</th><th style="text-align:left;padding:2px 4px">Time</th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table>';
  } catch(e) {}
}

async function loadSchedules() {
  const container = document.getElementById('schedule-list');
  if (!container) return;
  try {
    const res = await fetch('/api/schedule');
    if (!res.ok) return;
    const scheds = await res.json();
    if (!scheds.length) { container.innerHTML = '<p style="color:var(--text-tertiary);font-size:12px">暂无定时任务。</p>'; return; }
    container.innerHTML = scheds.map(s => {
      const intv = parseInt(s.cron) || 3600;
      const intvLabel = intv < 120 ? intv + 's' : intv < 3600 ? Math.round(intv/60) + 'min' : Math.round(intv/3600) + 'hr';
      const statusColor = s.enabled ? 'var(--success)' : 'var(--text-tertiary)';
      const lastRun = s.lastRun ? new Date(s.lastRun).toLocaleString('zh-CN').slice(5) : 'never';
      return '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border-subtle)">' +
        '<div style="flex:1;min-width:0">' +
        '<div style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + (s.goal||'?').substring(0,50) + '</div>' +
        '<div style="font-size:10px;color:var(--text-tertiary)">每 ' + intvLabel + ' · 上次运行: ' + lastRun + ' · <span style="color:' + statusColor + '">' + (s.enabled ? '启用' : '停用') + '</span></div>' +
        '</div>' +
        '<div style="display:flex;gap:4px;flex-shrink:0;margin-left:8px">' +
        '<button onclick="toggleSchedule(\'' + s.id + '\')" style="font-size:10px;padding:2px 6px;border-radius:4px;border:1px solid var(--border-default);background:transparent;color:var(--text-secondary);cursor:pointer">' + (s.enabled ? '停用' : '启用') + '</button>' +
        '<button onclick="removeSchedule(\'' + s.id + '\')" style="font-size:10px;padding:2px 6px;border-radius:4px;border:1px solid var(--border-default);background:transparent;color:var(--danger);cursor:pointer">删除</button>' +
        '</div></div>';
    }).join('');
  } catch(e) {}
}

async function addSchedule() {
  const goal = document.getElementById('schedule-add-goal')?.value?.trim();
  const interval = document.getElementById('schedule-add-interval')?.value;
  if (!goal) { showToast('请输入任务描述', 'error'); return; }
  try {
    const res = await fetch('/api/schedule/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goal, cron: String(interval || 3600) })
    });
    if (res.ok) { showToast('定时任务已添加', 'success'); loadSchedules(); }
    else { const e = await res.json(); showToast(e.error || '添加失败', 'error'); }
  } catch(e) { showToast('添加失败', 'error'); }
}

async function toggleSchedule(id) {
  try {
    const res = await fetch('/api/schedule/toggle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (res.ok) loadSchedules();
  } catch(e) {}
}

async function removeSchedule(id) {
  if (!confirm('确定删除此定时任务？')) return;
  try {
    await fetch('/api/schedule/remove', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    loadSchedules();
  } catch(e) {}
}

/* ==========================================================================
   MEMORY PANEL + SCIENCE SEARCH + REVIEW (hidden → now visible)
   ========================================================================== */
async function loadMemory() {
  const container = document.getElementById('memory-content');
  if (!container) return;
  try {
    const res = await fetch('/api/memory');
    if (!res.ok) return;
    const mem = await res.json();
    if (!mem.observations || !mem.observations.length) {
      container.innerHTML = '<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/></svg><h4>' + t('memory.empty_title') + '</h4><p>' + t('memory.empty') + '</p></div>';
      return;
    }
    const tags = {};
    mem.observations.forEach(o => (o.tags||[]).forEach(t => { tags[t] = (tags[t]||0)+1; }));
    const tagList = Object.entries(tags).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([t,c]) => '<span style="display:inline-block;margin:2px;padding:2px 8px;border-radius:12px;background:var(--accent-light);color:var(--accent);font-size:10px">'+t+' ('+c+')</span>').join('');
    container.innerHTML =
      '<div style="display:flex;gap:12px;margin-bottom:8px">' +
      '<span>🧠 ' + mem.observations.length + ' 条观察</span>' +
      '<span>🔗 ' + (mem.links||[]).length + ' 条关联</span>' +
      '<span>🛠 ' + (mem.skills||[]).length + ' 个技能建议</span>' +
      '</div>' +
      '<div style="margin-bottom:6px">' + tagList + '</div>' +
      '<div style="font-size:10px;color:var(--text-tertiary)">最近观察：' + mem.observations.slice(-3).reverse().map(o => '<div style="margin:3px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+(o.goal||'?').substring(0,60)+'</div>').join('') + '</div>';
    if (mem.skills && mem.skills.length) {
      container.innerHTML += '<div style="margin-top:8px;padding:6px 10px;background:var(--success-bg);border-radius:6px;font-size:11px;color:var(--success)">💡 ' + mem.skills.length + ' 个技能建议</div>';
    }
  } catch(e) {}
}

async function doScienceSearch() {
  const query = document.getElementById('science-query')?.value?.trim();
  const resultsDiv = document.getElementById('science-results');
  if (!query || !resultsDiv) return;
  resultsDiv.innerHTML = '<span style="color:var(--text-tertiary)">搜索中…</span>';
  try {
    const res = await fetch('/api/science/search', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query })
    });
    const data = await res.json();
    if (!data.ok) { resultsDiv.innerHTML = '<span style="color:var(--danger)">搜索失败</span>'; return; }
    const r = data.results;
    let html = '';
    if (Array.isArray(r) && r.length) {
      html = r.slice(0,5).map(p => '<div style="margin:4px 0;padding:4px 0;border-bottom:1px solid var(--border-subtle)"><div style="font-weight:500">'+(p.title||p.name||'?')+'</div><div style="color:var(--text-tertiary)">'+(p.source||'')+' · '+(p.summary||p.function||'').substring(0,120)+'</div></div>').join('');
    } else if (r && typeof r === 'object') {
      Object.entries(r).forEach(([db, items]) => { if (Array.isArray(items) && items.length) html += '<div style="margin:4px 0;color:var(--text-secondary)">'+db.toUpperCase()+': ' + items.length + ' 条结果</div>' + items.slice(0,2).map(p => '<div style="font-size:10px">'+(p.title||p.name||'?')+'</div>').join('') + '<br>'; });
    }
    resultsDiv.innerHTML = html || '<span style="color:var(--text-tertiary)">无结果</span>';
  } catch(e) { resultsDiv.innerHTML = '<span style="color:var(--danger)">搜索出错</span>'; }
}

async function triggerReview() {
  showToast('正在启动对抗性审查…', 'info');
  try {
    const res = await fetch('/api/agent/review', { method: 'POST' });
    if (res.ok) showToast('审查已启动，结果将出现在对话中', 'success');
    else showToast('审查启动失败', 'error');
  } catch(e) { showToast('审查启动失败', 'error'); }
}

/* ==========================================================================
   MOTION — GSAP-powered animation engine (taste-skill + gsap)
   Spring physics, staggered reveals, hover magnetism, scroll progress.
   ========================================================================== */
const MOTION = { intensity: 7, reduce: false };
let mm = null; // gsap.matchMedia instance

function initMotion() {
  MOTION.reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (MOTION.reduce) return; // GSM automatically degrades via matchMedia

  gsap.registerPlugin(ScrollTrigger);
  mm = gsap.matchMedia();

  // Reduce motion gate
  mm.add('(prefers-reduced-motion: no-preference)', () => {
    // --- Logo heartbeat (gsap, spring) ---
    gsap.to('.ae-logo', {
      scale: 1.04, duration: 1.2, ease: 'sine.inOut',
      yoyo: true, repeat: -1, transformOrigin: '50% 62%'
    });
    // --- Aurora blobs ---
    gsap.to('.aurora-blob:nth-child(1)', { x: '+=30', y: '-=25', scale: 1.08, duration: 22, ease: 'sine.inOut', repeat: -1, yoyo: true });
    gsap.to('.aurora-blob:nth-child(2)', { x: '-=35', y: '+=20', scale: 0.94, duration: 27, ease: 'sine.inOut', repeat: -1, yoyo: true });
    gsap.to('.aurora-blob:nth-child(3)', { x: '+=25', y: '+=30', scale: 1.05, duration: 24, ease: 'sine.inOut', repeat: -1, yoyo: true });
    // --- Welcome hero stagger ---
    const heroKids = gsap.utils.toArray('.chat-welcome > *');
    if (heroKids.length) {
      gsap.from(heroKids, {
        y: 24, autoAlpha: 0, duration: 0.7, stagger: 0.08,
        ease: 'back.out(1.4)', delay: 0.15
      });
    }
    return () => { /* ScrollTrigger cleanup handled internally */ };
  });

  // --- Scroll progress bar ---
  mm.add('(prefers-reduced-motion: no-preference)', () => {
    const center = document.querySelector('.center-panel');
    if (!center) return;
    const bar = document.createElement('div');
    bar.className = 'scroll-progress';
    center.prepend(bar);
    const targets = document.querySelectorAll('.chat-messages, .panel-body');
    targets.forEach(el => {
      ScrollTrigger.create({
        trigger: el, start: 'top top', end: 'bottom bottom', scrub: 0.3,
        onUpdate: self => { bar.style.transform = 'scaleX(' + self.progress + ')'; }
      });
    });
    return () => { bar.remove(); };
  });

  // --- Hover physics (magnetic buttons, cards) ---
  mm.add('(prefers-reduced-motion: no-preference) and (hover: hover)', () => {
    document.querySelectorAll('.sidebar-btn, .card, .btn-primary').forEach(el => {
      el.addEventListener('mouseenter', () => {
        gsap.to(el, { scale: 1.04, duration: 0.35, ease: 'back.out(2)' });
      });
      el.addEventListener('mouseleave', () => {
        gsap.to(el, { scale: 1, duration: 0.45, ease: 'elastic.out(1, 0.4)' });
      });
    });
    // Cards get lift + shadow boost
    document.querySelectorAll('.card').forEach(el => {
      el.addEventListener('mouseenter', () => {
        gsap.to(el, { y: -4, boxShadow: '0 18px 40px -12px rgba(0,0,0,0.18)', duration: 0.35, ease: 'power2.out' });
      });
      el.addEventListener('mouseleave', () => {
        gsap.to(el, { y: 0, boxShadow: '0 2px 12px rgba(0,0,0,0.06)', duration: 0.45, ease: 'power2.out' });
      });
    });
    return () => {};
  });

  // ---- Initial reveal for the default panel ----
  revealPanel('chat');
}

// Staggered entrance for a panel — called on both init and switchPanel.
function revealPanel(panelId) {
  if (MOTION.reduce) return;
  const panel = document.getElementById('panel-' + panelId);
  if (!panel) return;
  const items = gsap.utils.toArray(panel.querySelectorAll('.card, .panel-chat, .panel-header, .chat-header, .chat-welcome > *, .chat-input-area, .preview-header, .harness-row'));
  if (!items.length) return;
  gsap.fromTo(items, { y: 28, autoAlpha: 0 }, {
    y: 0, autoAlpha: 1, duration: 0.65, stagger: 0.05,
    ease: 'back.out(1.2)', overwrite: 'auto'
  });
  // Layout changed (panel switch) → keep scroll-progress triggers accurate.
  if (window.ScrollTrigger) ScrollTrigger.refresh();
}

// Toast notification with bounce-in (gsap, replaces CSS-only toast).
function showToast(msg, type) {
  if (type === void 0) type = 'info';
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:2000;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.className = 'toast toast-' + type;
  el.textContent = msg;
  container.appendChild(el);
  gsap.fromTo(el, { x: 60, autoAlpha: 0 }, { x: 0, autoAlpha: 1, duration: 0.5, ease: 'back.out(1.7)' });
  gsap.to(el, { autoAlpha: 0, x: 30, duration: 0.35, delay: 2.8, ease: 'power2.in', onComplete: () => el.remove() });
  // Limit toasts
  if (container.children.length > 4) container.firstChild.remove();
}

// Chat message entrance (called when a new message is added to the DOM).
function animateMessageEntry(el) {
  if (MOTION.reduce || !el) return;
  gsap.from(el, { y: 16, autoAlpha: 0, scale: 0.97, duration: 0.4, ease: 'back.out(1.3)' });
}

function applyTheme(t) {
  state.theme = t;
  document.body.classList.remove('theme-light', 'theme-dark');
  document.body.classList.add('theme-' + t);
  localStorage.setItem('vibebase-theme', t);
}

// ---------- I18N (minimal inline) ----------
const I18N = {
  zh: {
    'page.title': '灵思',
    'chat.input_ph': '让灵思帮你写论文、跑分析、画图…',
    'chat.welcome_title': '灵思',
    'chat.welcome_desc': '让我帮你写论文、跑数据分析、绘图，或执行任何任务。',
    'quick.paper': '写论文',
    'quick.research': '自主研究训练',
    'quick.plot': '绘制图表',
    'quick.analyze': '分析数据',
    'chat.title': 'Aetheris',
    'chat.subtitle': '智能助手',
    'paper.topic_ph': '例如：基于图神经网络的药物相互作用预测',
    'paper.journal_label': '目标期刊',
    'paper.lang_label': '语言',
    'paper.intent_label': '意图',
    'paper.provider_label': '模型提供方',
    'paper.generate': '生成论文',
    'paper.cancel': '取消',
    'paper.rag_title': '本地知识库 (RAG)',
    'paper.rag_desc': '上传你的 PDF / 实验笔记 / 论文，智能体会基于这些内容检索并写作。',
    'paper.rag_upload': '上传并入库',
    'paper.rag_query_ph': '向知识库提问…',
    'paper.rag_query_btn': '检索',
    'plot.title': '绘图编辑器',
    'plot.code_label': 'Matplotlib Python 代码',
    'plot.render': '渲染',
    'plot.export': '导出 PNG',
    'dash.title': '仪表盘',
    'dash.handoff': '交接笔记',
    'dash.security': '安全状态',
    'dash.goals': '目标进度',
    'settings.title': '设置',
    'settings.providers': '模型提供方',
    'preview.title': '预览',
    'preview.empty': '选择文件或结果进行预览',
    'lang.btn': 'EN',
    'theme.toggle': '切换主题',
    'nav.chat': '对话',
    'nav.paper': '论文',
    'nav.dashboard': '仪表盘',
    'nav.plot': '绘图',
    'nav.settings': '设置',
    'agent.timeline_title': '智能体活动',
    'agent.approval_required': '需要审批',
    'agent.high_risk': '高风险',
    'agent.approve': '通过',
    'agent.reject': '拒绝',
    'agent.edit': '编辑',
    'agent.question': '问题',
    'agent.submit': '提交',
    'agent.plan_title': '执行计划',
    'agent.approve_plan': '批准计划',
    'agent.reject_plan': '拒绝计划',
    'agent.cancel': '取消',
    'agent.done': '已完成',
    'agent.error': '错误',
    'chat.context': '上下文',
    'chat.mode': '模式',
    'chat.mode_discuss': '讨论',
    'chat.mode_edit': '编辑（可应用改动）',
    'chat.provider': '模型',
    'harness.mode': 'Harness 模式',
    'harness.mode_desc': '规格约束 + 完成验证 + 结构化追踪',
    'harness.rules_ph': '约束规则（逗号分隔）',
    'harness.verify_ph': '验证命令（如：pytest, npm run lint）',
    'settings.providers_desc': '配置自定义模型提供方和 API Key。',
    'settings.add_provider': '添加提供方',
    'settings.provider_name': '名称',
    'settings.provider_type': '类型',
    'settings.provider_url': 'Base URL（OpenAI 兼容接口可选）',
    'settings.provider_model': '模型名（必填）',
    'settings.provider_key': 'API Key',
    'settings.provider_add_btn': '添加',
    'settings.provider_remove': '删除',
    'settings.provider_edit': '编辑',
    'settings.provider_cancel': '取消编辑',
    'data.title': '数据分析',
    'data.upload': '数据文件',
    'data.upload_btn': '加载',
    'data.analysis': '分析',
    'data.describe': '描述统计',
    'data.regress': '回归分析',
    'data.clean': '数据清洗',
    'data.transform': '变量变换',
    'data.export_btn': '导出结果',
    'data.vars': '变量（逗号分隔，留空=全部）',
    'data.figure': '生成图表',
    'data.y': '因变量 Y',
    'data.x': '自变量 X（逗号分隔）',
    'data.method': '方法',
    'data.missing': '缺失值处理',
    'data.outlier': '异常值处理',
    'data.duplicate': '重复值处理',
    'data.transform_desc': 'Python 表达式（用 df["col"] 引用列）',
    'data.export_format': '导出格式',
    'data.export_name': '文件名（不含扩展名）',
    'data.run': '运行分析',
    'data.result': '分析结果',
    'data.file_loaded': '已加载: ',
    'data.no_file': '请先加载数据文件',
    'data.running': '分析中…',
    'data.error': '错误',
    'panel.custom': '自定义需求',
    'panel.custom_hint': '没找到你想要的功能？描述你的需求，AI 会帮你处理。',
    'panel.custom_ph': '例如：请帮我生成一张相关性热力图…',
    // New keys — Phase 1+2 integrations
    'tab.chat': '💬 对话',
    'tab.paper': '📄 论文',
    'tab.data': '📊 数据',
    'tab.plot': '📈 绘图',
    'tab.dashboard': '📋 仪表盘',
    'tab.settings': '⚙ 设置',
    'tab.features': '📖 字典',
    'dash.runs': '运行记录',
    'dash.memory': '记忆',
    'dash.science': '科学搜索',
    'dash.science_ph': '搜索 arXiv, PubMed, PDB, UniProt...',
    'dash.science_btn': '搜索',
    'schedule.title': '定时任务',
    'schedule.add': '添加任务',
    'schedule.goal': '任务描述',
    'schedule.interval': '间隔（秒）',
    'schedule.add_btn': '添加',
    'schedule.enable': '启用',
    'schedule.disable': '停用',
    'schedule.delete': '删除',
    'schedule.empty': '暂无定时任务',
    'schedule.running': '运行中',
    'session.save': '保存当前会话',
    'session.saved': '会话已保存',
    'session.restored': '会话已恢复',
    'session.deleted': '会话已删除',
    'session.empty': '暂无保存的会话',
    'session.label': '会话',
    'review.trigger': '🔍 Cross-model Review',
    'review.started': '审查已启动',
    'chat.clear': '清空对话',
    'chat.clear_confirm': '确定清空当前对话？',
    'memory.empty': '暂无记忆。执行agent任务后自动积累。',
    'memory.empty_title': '知识图谱为空',
    'memory.obs': '条观察',
    'memory.links': '条关联',
    'memory.skills': '个技能建议',
    'memory.recent': '最近观察',
    'memory.suggest': '个技能建议可通过 /api/memory/skills 查看',
    'science.searching': '搜索中…',
    'science.empty': '无结果',
    'science.error': '搜索失败',
    'project.create': '新建项目',
    'project.create_desc': '输入项目名称，系统自动创建并初始化：',
    'project.create_ph': 'my-project',
    'project.create_btn': '创建项目',
    'project.created': '项目已创建，自动切换中…',
    'project.switched': '已切换至',
    'runs.empty': '暂无运行记录。执行agent任务后自动记录。',
    'runs.empty_title': '还没有运行记录',
  },
  en: {
    'page.title': 'Aetheris',
    'chat.input_ph': 'Ask Aetheris to write a paper, analyze data, plot...',
    'chat.welcome_title': 'Aetheris',
    'chat.welcome_desc': 'Ask me to write a paper, run an analysis, plot data, or execute a task.',
    'quick.paper': 'Write a paper',
    'quick.research': 'Research training',
    'quick.plot': 'Plot data',
    'quick.analyze': 'Analyze data',
    'chat.title': 'Aetheris',
    'chat.subtitle': 'Control Panel',
    'paper.topic_ph': 'e.g. Graph neural networks for drug interaction prediction',
    'paper.journal_label': 'Target journal',
    'paper.lang_label': 'Language',
    'paper.intent_label': 'Intent',
    'paper.provider_label': 'Model provider',
    'paper.generate': 'Generate paper',
    'paper.cancel': 'Cancel',
    'paper.rag_title': 'Knowledge Base (RAG)',
    'paper.rag_desc': 'Upload your PDFs, notes, or papers for grounded writing.',
    'paper.rag_upload': 'Upload',
    'paper.rag_query_ph': 'Ask your knowledge base...',
    'paper.rag_query_btn': 'Search',
    'plot.title': 'Plot Editor',
    'plot.code_label': 'Matplotlib Python code',
    'plot.render': 'Render',
    'plot.export': 'Export PNG',
    'dash.title': 'Dashboard',
    'dash.handoff': 'Handoff Notes',
    'dash.security': 'Security',
    'dash.goals': 'Goals',
    'settings.title': 'Settings',
    'settings.providers': 'Model Providers',
    'preview.title': 'Preview',
    'preview.empty': 'Select a file or result to preview',
    'lang.btn': '中文',
    'theme.toggle': 'Toggle theme',
    'nav.chat': 'Chat',
    'nav.paper': 'Paper',
    'nav.dashboard': 'Dashboard',
    'nav.plot': 'Plot',
    'nav.settings': 'Settings',
    'agent.timeline_title': 'Agent Activity',
    'agent.approval_required': 'Approval Required',
    'agent.high_risk': 'High Risk',
    'agent.approve': 'Approve',
    'agent.reject': 'Reject',
    'agent.edit': 'Edit',
    'agent.question': 'Question',
    'agent.submit': 'Submit',
    'agent.plan_title': 'Execution Plan',
    'agent.approve_plan': 'Approve Plan',
    'agent.reject_plan': 'Reject Plan',
    'agent.cancel': 'Cancel',
    'agent.done': 'Completed',
    'agent.error': 'Error',
    'chat.context': 'Context',
    'chat.mode': 'Mode',
    'chat.mode_discuss': 'Discuss',
    'chat.mode_edit': 'Edit (apply changes)',
    'chat.provider': 'Provider',
    'harness.mode': 'Harness Mode',
    'harness.mode_desc': 'Spec-constrained + verification + structured trace',
    'harness.rules_ph': 'Constraints (comma-separated)',
    'harness.verify_ph': 'Verification commands (e.g. pytest, npm run lint)',
    'settings.providers_desc': 'Configure custom model providers and API keys.',
    'settings.add_provider': 'Add Provider',
    'settings.provider_name': 'Name',
    'settings.provider_type': 'Type',
    'settings.provider_url': 'Base URL (optional for OpenAI-compatible)',
    'settings.provider_model': 'Model name (required)',
    'settings.provider_key': 'API Key',
    'settings.provider_add_btn': 'Add',
    'settings.provider_remove': 'Remove',
    'settings.provider_edit': 'Edit',
    'settings.provider_cancel': 'Cancel Edit',
    'data.title': 'Data Analysis',
    'data.upload': 'Data File',
    'data.upload_btn': 'Load',
    'data.analysis': 'Analysis',
    'data.describe': 'Describe',
    'data.regress': 'Regress',
    'data.clean': 'Clean',
    'data.transform': 'Transform',
    'data.export_btn': 'Export',
    'data.vars': 'Variables (comma-separated, blank=all)',
    'data.figure': 'Generate figure',
    'data.y': 'Dependent variable Y',
    'data.x': 'Independent variables X (comma-separated)',
    'data.method': 'Method',
    'data.missing': 'Missing values',
    'data.outlier': 'Outliers',
    'data.duplicate': 'Duplicates',
    'data.transform_desc': 'Python expression (use df["col"] to reference columns)',
    'data.export_format': 'Format',
    'data.export_name': 'Filename (without extension)',
    'data.run': 'Run',
    'data.result': 'Results',
    'data.file_loaded': 'Loaded: ',
    'data.no_file': 'Load a data file first',
    'data.running': 'Running...',
    'data.error': 'Error',
    'panel.custom': 'Custom Request',
    'panel.custom_hint': 'Not finding what you need? Describe your requirement below.',
    'panel.custom_ph': 'e.g. Generate a correlation heatmap for my variables...',
    // New keys — Phase 1+2 integrations
    'tab.chat': '💬 Chat',
    'tab.paper': '📄 Paper',
    'tab.data': '📊 Data',
    'tab.plot': '📈 Plot',
    'tab.dashboard': '📋 Dashboard',
    'tab.settings': '⚙ Settings',
    'tab.features': '📖 Dictionary',
    'dash.runs': 'Run History',
    'dash.memory': 'Memory',
    'dash.science': 'Science Search',
    'dash.science_ph': 'Search arXiv, PubMed, PDB, UniProt...',
    'dash.science_btn': 'Search',
    'schedule.title': 'Scheduled Tasks',
    'schedule.add': 'Add Task',
    'schedule.goal': 'Goal',
    'schedule.interval': 'Interval (seconds)',
    'schedule.add_btn': 'Add',
    'schedule.enable': 'Enable',
    'schedule.disable': 'Disable',
    'schedule.delete': 'Delete',
    'schedule.empty': 'No scheduled tasks',
    'schedule.running': 'Running',
    'session.save': 'Save session',
    'session.saved': 'Session saved',
    'session.restored': 'Session restored',
    'session.deleted': 'Deleted',
    'session.empty': 'No saved sessions',
    'session.label': 'Sessions',
    'review.trigger': '🔍 Cross-model Review',
    'review.started': 'Review started',
    'chat.clear': 'Clear Chat',
    'chat.clear_confirm': 'Clear current chat?',
    'memory.empty': 'No memories yet. Accumulates after agent tasks.',
    'memory.obs': 'observations',
    'memory.links': 'links',
    'memory.skills': 'skill suggestions',
    'memory.recent': 'Recent',
    'memory.suggest': 'skill suggestions available via /api/memory/skills',
    'science.searching': 'Searching...',
    'science.empty': 'No results',
    'science.error': 'Search failed',
    'project.create': 'New Project',
    'project.create_desc': 'Enter a project name. Auto-scaffolds on creation:',
    'project.create_ph': 'my-project',
    'project.create_btn': 'Create',
    'project.created': 'Project created, switching...',
    'project.switched': 'Switched to',
    'runs.empty': 'No runs yet. Auto-recorded after agent tasks.',
    'runs.empty_title': 'No run history yet',
    'memory.empty': 'No memory yet. Auto-accumulated after agent tasks.',
    'memory.empty_title': 'Knowledge graph is empty',
  }
};

function t(key) { return (I18N[state.lang] && I18N[state.lang][key]) || key; }

// Select option translations: selectId → { optionValue: { zh: "...", en: "..." } }
const SELECT_I18N = {
  'paper-journal': {
    'Nature': { zh: 'Nature（英文）', en: 'Nature (English)' },
    'Nature Communications': { zh: 'Nature Communications', en: 'Nature Communications' },
    'Science': { zh: 'Science', en: 'Science' },
    'Cell': { zh: 'Cell', en: 'Cell' },
    'CSSCI': { zh: 'CSSCI 中文核心', en: 'CSSCI (Chinese)' },
  },
  'paper-language': {
    'en': { zh: '英文', en: 'English' },
    'zh': { zh: '中文', en: 'Chinese' },
  },
  'paper-intent': {
    '': { zh: '自动', en: 'Auto' },
    'new_paper': { zh: '新建论文', en: 'New paper' },
    'revise_section': { zh: '修改章节', en: 'Revise section' },
    'review_response': { zh: '审稿回复', en: 'Review response' },
    'to_ppt': { zh: '导出 PPT', en: 'Export PPT' },
    'empirical_analysis': { zh: '实证分析（数据）', en: 'Empirical analysis' },
    'autonomous_research': { zh: '自主研究（训练）', en: 'Research training' },
    'chat': { zh: '问答', en: 'Q&A' },
  },
  'paper-provider': {
    '': { zh: 'mock（默认）', en: 'mock (default)' },
  },
  'chat-mode': {
    'discuss': { zh: '讨论', en: 'Discuss' },
    'edit': { zh: '编辑（可应用改动）', en: 'Edit (apply changes)' },
  },
  'data-regress-method': {
    'ols': { zh: 'OLS 普通最小二乘', en: 'OLS' },
    'logit': { zh: 'Logit', en: 'Logit' },
    'probit': { zh: 'Probit', en: 'Probit' },
  },
  'data-clean-missing': {
    'report': { zh: '仅报告', en: 'Report only' },
    'drop_rows': { zh: '删除缺失行', en: 'Drop rows' },
    'mean': { zh: '均值填充', en: 'Fill with mean' },
    'median': { zh: '中位数填充', en: 'Fill with median' },
    'ffill': { zh: '前向填充', en: 'Forward fill' },
    'interpolate': { zh: '插值填充', en: 'Interpolate' },
  },
  'data-clean-outlier': {
    'report': { zh: '仅报告', en: 'Report only' },
    'zscore': { zh: 'Z-score (3σ)', en: 'Z-score (3σ)' },
    'iqr': { zh: 'IQR (1.5倍)', en: 'IQR (1.5x)' },
    'winsorize': { zh: 'Winsorize (1%)', en: 'Winsorize (1%)' },
  },
  'data-clean-duplicate': {
    'report': { zh: '仅报告', en: 'Report only' },
    'drop': { zh: '删除重复', en: 'Drop' },
  },
  'data-export-format': {
    'md': { zh: 'Markdown', en: 'Markdown' },
    'csv': { zh: 'CSV', en: 'CSV' },
  },
  'provider-add-type': {
    'openai': { zh: 'OpenAI 兼容', en: 'OpenAI Compatible' },
    'claude': { zh: 'Claude (Anthropic)', en: 'Claude (Anthropic)' },
    'ollama': { zh: 'Ollama（本地）', en: 'Ollama (Local)' },
  },
};

function updateLangUI() {
  document.title = t('page.title');

  // Update the lang toggle button text
  const langBtn = document.getElementById('lang-toggle-btn');
  if (langBtn) langBtn.textContent = t('lang.btn');

  // Update all [data-i18n] elements
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const text = t(key);
    if (text && text !== key) el.textContent = text;
  });

  // Update all [data-i18n-ph] placeholders
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const key = el.dataset.i18nPh;
    const text = t(key);
    if (text && text !== key) el.placeholder = text;
  });

  // Update welcome text
  const welcomeTitle = document.querySelector('.chat-welcome h3');
  if (welcomeTitle) welcomeTitle.textContent = t('chat.welcome_title');
  const welcomeDesc = document.querySelector('.chat-welcome p');
  if (welcomeDesc) welcomeDesc.textContent = t('chat.welcome_desc');

  // Update chat subtitle label (handled by data-i18n scan above)

  // Refresh dynamic panels that use t()
  loadWorkflows();
  loadSessionList();
  loadRuns();
  loadMemory();
  loadSchedules();

  // Update preview empty text
  const previewEmpty = document.querySelector('.preview-empty p');
  if (previewEmpty) previewEmpty.textContent = t('preview.empty');

  // Update panel headers
  document.querySelectorAll('.panel-header h2').forEach(h2 => {
    if (h2.closest('#panel-paper')) h2.textContent = 'Paper Agent';
    else if (h2.closest('#panel-plot')) h2.textContent = t('plot.title');
    else if (h2.closest('#panel-dashboard')) h2.textContent = t('dash.title');
    else if (h2.closest('#panel-settings')) h2.textContent = t('settings.title');
  });

  // Update preview header
  const previewHeader = document.querySelector('.preview-header h3');
  if (previewHeader) previewHeader.textContent = t('preview.title');

  // Update select option text
  Object.keys(SELECT_I18N).forEach(selectId => {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    const mapping = SELECT_I18N[selectId];
    Array.from(sel.options).forEach(opt => {
      const entry = mapping[opt.value];
      if (entry && entry[state.lang]) {
        opt.textContent = entry[state.lang];
      }
    });
  });
}

// ---------- Event Binding ----------
function bindEvents() {
  // Main tab bar navigation (EvoScientist unified-entry pattern)
  document.querySelectorAll('.main-tab[data-tab]').forEach(tab => {
    tab.addEventListener('click', () => switchPanel(tab.dataset.tab));
  });

  // Theme toggle
  document.getElementById('theme-toggle-btn').addEventListener('click', () => {
    applyTheme(state.theme === 'light' ? 'dark' : 'light');
  });

  // Language toggle
  document.getElementById('lang-toggle-btn').addEventListener('click', () => {
    state.lang = state.lang === 'zh' ? 'en' : 'zh';
    localStorage.setItem('vibebase-lang', state.lang);
    updateLangUI();
  });

  // Back buttons
  document.querySelectorAll('.panel-back-btn').forEach(btn => {
    btn.addEventListener('click', () => switchPanel(btn.dataset.back));
  });

  // Chat send
  const chatInput = document.getElementById('chat-input');
  const sendBtn = document.getElementById('chat-send-btn');
  sendBtn.addEventListener('click', () => sendChatMessage());
  chatInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
  });
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
  });

  // Paper Agent
  const paperRunBtn = document.getElementById('paper-run-btn');
  if (paperRunBtn) paperRunBtn.addEventListener('click', runPaperAgent);
  const paperCancelBtn = document.getElementById('paper-cancel-btn');
  if (paperCancelBtn) paperCancelBtn.addEventListener('click', cancelAgent);

  // Journal ↔ language sync
  const journalSel = document.getElementById('paper-journal');
  const langSel = document.getElementById('paper-language');
  if (journalSel && langSel) {
    journalSel.addEventListener('change', () => {
      if (journalSel.value === 'CSSCI') langSel.value = 'zh';
      else langSel.value = 'en';
    });
    langSel.addEventListener('change', () => {
      if (langSel.value === 'zh' && journalSel.value !== 'CSSCI') journalSel.value = 'CSSCI';
      else if (langSel.value === 'en' && journalSel.value === 'CSSCI') journalSel.value = 'Nature';
    });
  }

  // RAG
  const ragUploadBtn = document.getElementById('rag-upload-btn');
  const ragQueryBtn = document.getElementById('rag-query-btn');
  if (ragUploadBtn) ragUploadBtn.addEventListener('click', ragUpload);
  if (ragQueryBtn) ragQueryBtn.addEventListener('click', ragQuery);

  // Plot
  const plotRunBtn = document.getElementById('plot-run-btn');
  const plotExportPng = document.getElementById('plot-export-png');
  const plotExportTiff = document.getElementById('plot-export-tiff');
  const plotExportPdf = document.getElementById('plot-export-pdf');
  if (plotRunBtn) plotRunBtn.addEventListener('click', renderPlot);
  if (plotExportPng) plotExportPng.addEventListener('click', () => downloadPlot('png'));
  if (plotExportTiff) plotExportTiff.addEventListener('click', () => downloadPlot('tiff'));
  if (plotExportPdf) plotExportPdf.addEventListener('click', () => downloadPlot('pdf'));

  // Preview close
  const previewCloseBtn = document.getElementById('preview-close-btn');
  if (previewCloseBtn) previewCloseBtn.addEventListener('click', closePreview);

  // Provider management
  const providerAddBtn = document.getElementById('provider-add-btn');
  if (providerAddBtn) providerAddBtn.addEventListener('click', addProvider);

  // Harness toggle
  setupHarnessToggle();

  // Data panel
  setupDataPanel();

  // Agent Lab (Dashboard: skills/pipeline/training/channels/wiki)
  initAgentLab();

  // Chat mode toggle (Discuss ↔ Agent)
  initChatModeToggle();

  // Chat attachments (external files → rag-uploads)
  initChatAttachments();

  // Notes panel (preview sidebar: user notes + agent-read toggle)
  initNotesPanel();

  // Panel chat (mini LLM dialogs in Paper/Data/Plot)
  setupPanelChats();

  // Load providers into dropdowns on init
  loadProviders();

  // Agent approval
  document.getElementById('agent-approve-btn')?.addEventListener('click', () => respondApproval('approve'));
  document.getElementById('agent-reject-btn')?.addEventListener('click', () => respondApproval('reject'));
  document.getElementById('agent-edit-btn')?.addEventListener('click', () => {
    const editArea = document.getElementById('agent-edit-area');
    if (editArea) editArea.style.display = editArea.style.display === 'none' ? 'block' : 'none';
  });
  document.getElementById('agent-edit-save-btn')?.addEventListener('click', respondEditApproval);

  // Agent plan
  document.getElementById('agent-approve-plan-btn')?.addEventListener('click', () => respondPlan('approve'));
  document.getElementById('agent-reject-plan-btn')?.addEventListener('click', () => respondPlan('reject'));

  // Project management
  document.getElementById('sidebar-add-project-btn')?.addEventListener('click', () => openAddProjectModal());
  document.getElementById('sidebar-add-subproject-btn')?.addEventListener('click', () => openAddProjectModal(state.rootProject, true));
  setupProjectContextMenu();
  document.getElementById('modal-cancel-btn')?.addEventListener('click', closeAddProjectModal);
  document.getElementById('modal-add-btn')?.addEventListener('click', () => {
    const input = document.getElementById('modal-project-name');
    if (!input || !input.value.trim()) return;
    if (window._modalParent) createSubproject(input.value.trim(), window._modalParent);
    else addProject(input.value.trim());
  });
  document.getElementById('modal-project-name')?.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target.value.trim()) return;
    if (window._modalParent) createSubproject(e.target.value.trim(), window._modalParent);
    else addProject(e.target.value.trim());
  });
  document.getElementById('add-project-modal')?.addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeAddProjectModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAddProjectModal();
  });

  // Schedule management (EvoScientist pattern)
  document.getElementById('schedule-add-btn')?.addEventListener('click', addSchedule);

  // Science search button
  document.getElementById('science-search-btn')?.addEventListener('click', doScienceSearch);
  document.getElementById('science-query')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doScienceSearch();
  });

  // Clear chat button (in header)
  document.getElementById('header-clear-btn')?.addEventListener('click', () => {
    if (confirm('确定清空当前对话？')) {
      const container = document.getElementById('chat-messages');
      if (container) container.innerHTML = '<div class="chat-welcome"><div class="welcome-aura" aria-hidden="true"></div><h3 class="brand-gradient">灵思</h3><p>让我帮你写论文、跑数据分析、绘图，或执行任何任务。</p></div>';
      if (state.activeProjectDir) delete window._chatCache[state.activeProjectDir];
    }
  });
  // Features dictionary — open in preview panel
  // Sidebar collapse / reopen
  const collapseBtn = document.getElementById('sidebar-collapse-btn');
  if (collapseBtn) collapseBtn.addEventListener('click', toggleSidebar);
  const reopenBtn = document.getElementById('sidebar-reopen-btn');
  if (reopenBtn) reopenBtn.addEventListener('click', toggleSidebar);
}

// ---------- Panel Navigation ----------
function switchPanel(panelId) {
  state.activePanel = panelId;
  document.querySelectorAll('.tab-content').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.main-tab').forEach(b => b.classList.remove('active'));

  const target = document.getElementById('panel-' + panelId);
  const tab = document.querySelector(`.main-tab[data-tab="${panelId}"]`);
  if (target) target.classList.add('active');
  if (tab) tab.classList.add('active');

  // Staggered entrance for this panel's content.
  revealPanel(panelId);

  // Reset scroll-progress bar for the newly active panel.
  const bar = document.querySelector('.scroll-progress');
  if (bar) bar.style.transform = 'scaleX(0)';

  // Refresh providers when switching to any panel that shows them
  if (panelId === 'settings' || panelId === 'paper' || panelId === 'chat') loadProviders();
  if (panelId === 'dashboard') loadDashboard();
}

// ---------- Chat ----------
function createThinkingMessage(providerName) {
  const container = document.getElementById('chat-messages');
  const welcomeEl = container.querySelector('.chat-welcome');
  if (welcomeEl) welcomeEl.style.display = 'none';

  const div = document.createElement('div');
  div.className = 'chat-msg agent';
  const avatar = document.createElement('div');
  avatar.className = 'chat-msg-avatar';
  avatar.textContent = 'V';
  const bubble = document.createElement('div');
  bubble.className = 'chat-msg-bubble chat-thinking';
  bubble.innerHTML =
    '<div class="thinking-block">' +
      '<div class="thinking-block-label">' +
        '<span class="thinking-block-dot"></span>思考过程' +
        '<button class="thinking-stop-btn" id="agent-stop-btn" title="停止执行" onclick="cancelAgent()" style="display:none">⏹ 停止</button>' +
      '</div>' +
      '<div class="thinking-steps"></div>' +
      '<div class="thinking-line"><span class="thinking-spinner"></span><span class="thinking-text">思考中…</span></div>' +
    '</div>' +
    '<div class="thinking-answer-wrap" style="display:none">' +
      '<div class="answer-block-label">回答</div>' +
      '<div class="thinking-answer"></div>' +
    '</div>';
  div.appendChild(avatar);
  div.appendChild(bubble);
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return div;
}

// Parse the SSE stream from /api/chat and render live status + tokens.
async function streamChatResponse(msgEl, body) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  const thinkingBlock = msgEl.querySelector('.thinking-block');
  const stepsEl = msgEl.querySelector('.thinking-steps');
  const answerWrap = msgEl.querySelector('.thinking-answer-wrap');
  const answerEl = msgEl.querySelector('.thinking-answer');
  const statusLine = msgEl.querySelector('.thinking-line');
  const thinkingLabel = msgEl.querySelector('.thinking-block-label');
  // Show the stop button during agent execution.
  if ((window._chatAgentMode || 'discuss') === 'agent') {
    const stopBtn = msgEl.querySelector('#agent-stop-btn');
    if (stopBtn) stopBtn.style.display = 'inline-flex';
    state.agentRunning = true;
  } else {
    const stopBtn = msgEl.querySelector('#agent-stop-btn');
    if (stopBtn) stopBtn.style.display = 'none';
  }
  let answerText = '';
  let usage = null;
  let answerStarted = false;

  const appendStep = (text, endpoint) => {
    if (!stepsEl) return;
    const row = document.createElement('div');
    row.className = 'thinking-step';
    row.innerHTML = '<span class="step-dot"></span><span class="step-text">' + escapeHtml(text) + '</span>' +
      (endpoint ? '<span class="step-endpoint">' + escapeHtml(endpoint) + '</span>' : '');
    stepsEl.appendChild(row);
    const c = document.getElementById('chat-messages');
    if (c) c.scrollTop = c.scrollHeight;
  };

  const showAnswer = () => {
    if (answerStarted) return;
    answerStarted = true;
    answerWrap.style.display = 'block';
    answerEl.textContent = answerText;
    const c = document.getElementById('chat-messages');
    if (c) c.scrollTop = c.scrollHeight;
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buf.indexOf('\n\n')) !== -1) {
      const chunk = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      const line = chunk.split('\n').find(l => l.startsWith('data:'));
      if (!line) continue;
      let ev;
      try { ev = JSON.parse(line.slice(5).trim()); } catch (_) { continue; }
      if (ev.type === 'status') {
        appendStep(ev.text, ev.endpoint);
      } else if (ev.type === 'step') {
        // Agent tool-call step: show which Aetheris capability is in use.
        const s = ev.step || {};
        const f = ev.feature;
        let label = s.description || s.thought || '';
        if (s.tool) label = '运行工具 ' + s.tool + (label ? ' — ' + label : '');
        appendStep(f ? ('[' + f.icon + ' ' + f.label + '] ' + label) : label, (f && f.detail) ? f.detail : null);
      } else if (ev.type === 'checkpoint') {
        // 中间检查点：展示节点结果 + 继续/修改/跳过按钮。
        appendStep('⏸ 检查点: ' + ((ev.node && ev.node.title) || '阶段完成'), null);
        showCheckpointCard(ev, msgEl);
      } else if (ev.type === 'artifact') {
        // 实时产物推送：agent 写文件 → 显示产物卡片。
        appendArtifactCard(ev, msgEl);
      } else if (ev.type === 'token') {
        answerText += ev.text;
        showAnswer();
        answerEl.textContent = answerText;
        const c = document.getElementById('chat-messages');
        if (c) c.scrollTop = c.scrollHeight;
      } else if (ev.type === 'done') {
        // Hide stop button.
        const stopBtn = msgEl.querySelector('#agent-stop-btn');
        if (stopBtn) stopBtn.style.display = 'none';
        state.agentRunning = false;
        usage = ev.usage || null;
        // Record the completed answer into the discussion history so the next
        // turn (discuss or agent) can understand the conversation context.
        if (window._discussionHistory && answerText && answerText.trim()) {
          window._discussionHistory.push({ role: 'assistant', content: answerText.trim().slice(0, 6000) });
          if (window._discussionHistory.length > 24) window._discussionHistory.shift();
        }
        // Collapse thinking block, keep a toggle on its label row.
        if (stepsEl && thinkingLabel) {
          const count = stepsEl.querySelectorAll('.thinking-step').length;
          thinkingLabel.classList.add('thinking-collapsible');
          thinkingLabel.innerHTML = '<span class="thinking-block-dot"></span>思考过程 <span class="thinking-count">(' + count + ' 步)</span> <span class="thinking-arrow">▾</span>';
          thinkingLabel.onclick = () => {
            const hidden = stepsEl.style.display === 'none';
            stepsEl.style.display = hidden ? 'block' : 'none';
            thinkingLabel.querySelector('.thinking-arrow').textContent = hidden ? '▴' : '▾';
          };
          stepsEl.style.display = 'none';
        }
        if (statusLine) statusLine.style.display = 'none';
        // Mark the answer area as the deliverable so the user knows where the result is.
        if (answerText && answerText.trim()) {
          const abl = answerWrap.querySelector('.answer-block-label');
          if (abl) abl.textContent = '📋 执行成果（可复制）';
        }
        showAnswer();
        if (usage && (usage.total || usage.input)) {
          const u = document.createElement('div');
          u.className = 'chat-usage';
          u.textContent = '≈ 输入 ' + (usage.input ?? '?') + ' · 输出 ' + (usage.output ?? '?') + ' · 共 ' + (usage.total || ((usage.input || 0) + (usage.output || 0))) + ' tokens';
          answerWrap.appendChild(u);
        }
        if (ev.file) {
          const f = document.createElement('div');
          f.className = 'chat-output-file';
          f.textContent = '💾 结果文件已输出: ' + ev.file;
          f.title = '项目目录下的相对路径';
          answerWrap.appendChild(f);
        }
      } else if (ev.type === 'error') {
        state.agentRunning = false;
        const stopBtn = msgEl.querySelector('#agent-stop-btn');
        if (stopBtn) stopBtn.style.display = 'none';
        failThinkingMessage(msgEl, 'Error: ' + ev.error);
        return;
      }
    }
  }
  if (answerText && !answerStarted) {
    showAnswer();
    if (stepsEl && thinkingLabel) {
      const count = stepsEl.querySelectorAll('.thinking-step').length;
      thinkingLabel.classList.add('thinking-collapsible');
      thinkingLabel.innerHTML = '<span class="thinking-block-dot"></span>思考过程 <span class="thinking-count">(' + count + ' 步)</span> <span class="thinking-arrow">▾</span>';
      thinkingLabel.onclick = () => {
        const hidden = stepsEl.style.display === 'none';
        stepsEl.style.display = hidden ? 'block' : 'none';
        thinkingLabel.querySelector('.thinking-arrow').textContent = hidden ? '▴' : '▾';
      };
      stepsEl.style.display = 'none';
    }
    if (statusLine) statusLine.style.display = 'none';
  }
}

function finishThinkingMessage(msgEl, reply, usage) {
  if (!msgEl) return;
  const bubble = msgEl.querySelector('.chat-msg-bubble');
  if (!bubble) return;
  const tokLine = (usage && (usage.total || usage.input)) ?
    '<div class="chat-usage">≈ 输入 ' + (usage.input ?? '?') + ' · 输出 ' + (usage.output ?? '?') + ' · 共 ' + (usage.total || ((usage.input || 0) + (usage.output || 0))) + ' tokens</div>' : '';
  bubble.className = 'chat-msg-bubble';
  bubble.innerHTML = escapeHtml(reply) + tokLine;
  const container = document.getElementById('chat-messages');
  if (container) container.scrollTop = container.scrollHeight;
}

function failThinkingMessage(msgEl, errText) {
  if (!msgEl) return;
  const bubble = msgEl.querySelector('.chat-msg-bubble');
  if (!bubble) return;
  bubble.className = 'chat-msg-bubble';
  bubble.innerHTML = escapeHtml(errText);
}

function addChatMessage(role, content, badge) {
  const container = document.getElementById('chat-messages');
  const welcomeEl = container.querySelector('.chat-welcome');
  if (welcomeEl) welcomeEl.style.display = 'none';

  const div = document.createElement('div');
  div.className = 'chat-msg ' + role;

  const avatar = document.createElement('div');
  avatar.className = 'chat-msg-avatar';
  avatar.textContent = role === 'user' ? 'Y' : 'V';

  const bubble = document.createElement('div');
  bubble.className = 'chat-msg-bubble';
  bubble.textContent = content;
  if (badge) {
    const badgeEl = document.createElement('span');
    badgeEl.className = 'chat-msg-mode-badge';
    badgeEl.textContent = badge;
    bubble.appendChild(document.createElement('br'));
    bubble.appendChild(badgeEl);
  }

  div.appendChild(avatar);
  div.appendChild(bubble);
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  // Track discussion turns so Agent mode can carry the agreed plan forward.
  if (window._discussionHistory) {
    window._discussionHistory.push({ role: role === 'user' ? 'user' : 'assistant', content: content });
    if (window._discussionHistory.length > 20) window._discussionHistory.shift();
  }
}

async function sendChatMessage() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || state.agentRunning) return;

  // Show active workflow mode as a badge on the user bubble.
  const wfBadge = (currentWorkflow && state.currentWorkflowNameZh) ? ' [' + state.currentWorkflowNameZh + ']' : '';
  addChatMessage('user', text, wfBadge);
  input.value = '';
  input.style.height = 'auto';

  // Check if it's a direct chat or agent task
  const isPaperTask = /论文|paper|写|write|审稿|review|润色|polish|ppt|实证|empirical/i.test(text);
  const isResearchTask = /训练|training|自主研究|autoresearch/i.test(text);
  const isPlotTask = /画图|绘图|plot|可视化|visualize|matplotlib/i.test(text);

  try {
    const contextFile = document.getElementById('chat-context-file')?.value || '';
    const chatMode = document.getElementById('chat-mode')?.value || 'discuss';
    const provider = document.getElementById('chat-provider')?.value || '';
    // Active mode from the toggle: 'discuss' (plan only) or 'agent' (execute).
    const activeMode = window._chatAgentMode || 'discuss';
    const exportFile = document.getElementById('chat-export-file')?.checked || false;
    const checkpoint = document.getElementById('chat-checkpoint')?.checked || false;
    // Mode badge shown on the user message so the active mode is visible.
    const modeLabel = currentWorkflow ? (state.lang === 'zh' ? state.currentWorkflowNameZh : state.currentWorkflowName) : '';

    // Use the chat API (SSE stream: live status + tokens + usage).
    // discuss → skill-informed conversation (no execution); agent → full loop.
    const msgEl = createThinkingMessage(provider || '默认模型');
    try {
      const payload = {
        message: text,
        mode: activeMode === 'agent' ? 'agent' : 'discuss',
        domain: state.currentWorkflowDomain || undefined,
        contextFile: contextFile || undefined,
        provider: provider || undefined,
        intent: state.currentIntent || undefined,
        stream: true,
        exportFile: activeMode === 'agent' && exportFile || undefined,
        checkpoint: activeMode === 'agent' && checkpoint || undefined,
        notesEnabled: window._notesEnabled === true
      };
      // External attachments (uploaded to rag-uploads) → injected as context.
      const atts = (window._attachments || []).filter(a => a.status === 'ok');
      if (atts.length > 10) {
        showToast('附件最多同时携带 10 个，本次仅前 10 个生效（共 ' + atts.length + ' 个）', 'warning');
      }
      if (atts.length) payload.attachments = atts.map(a => a.path).slice(0, 10);
      // Carry the recent discussion (user+agent turns) as context — for BOTH
      // discuss and agent modes so the model understands the conversation.
      if (window._discussionHistory && window._discussionHistory.length) {
        payload.discussion = window._discussionHistory.slice(-10);
      }
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok || !res.body) {
        failThinkingMessage(msgEl, 'Server error (HTTP ' + res.status + ')');
        return;
      }
      await streamChatResponse(msgEl, res.body);
    } catch (e) {
      failThinkingMessage(msgEl, 'Error: ' + e.message);
    }
  } catch (e) {
    // Fallback: try running as an agent
    try {
      await fetch('/api/agent/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal: text, auto: false, domain: state.currentWorkflowDomain || (isPaperTask ? 'academic' : 'coding'), provider: provider || undefined, intent: state.currentIntent || undefined })
      });
    } catch (e2) {
      addChatMessage('agent', 'Server not reachable. Is Aetheris running?');
    }
  }
}

// ---------- Paper Agent ----------
async function runPaperAgent() {
  const goal = document.getElementById('paper-goal').value.trim();
  if (!goal) { alert('Please enter a research topic.'); return; }

  const journal = document.getElementById('paper-journal').value;
  const language = document.getElementById('paper-language').value;
  const intent = document.getElementById('paper-intent').value;
  const provider = document.getElementById('paper-provider').value;
  const harnessEnabled = document.getElementById('agent-harness-toggle')?.checked;
  const harnessRules = document.getElementById('agent-harness-rules')?.value || '';
  const harnessVerify = document.getElementById('agent-harness-verify')?.value || '';

  state.currentJournal = journal;
  state.currentLanguage = language;
  state.currentIntent = intent || 'new_paper';

  const runBtn = document.getElementById('paper-run-btn');
  const cancelBtn = document.getElementById('paper-cancel-btn');
  runBtn.style.display = 'none';
  cancelBtn.style.display = 'inline-flex';
  state.agentRunning = true;

  // Show timeline
  const timelinePanel = document.getElementById('agent-timeline-panel');
  if (timelinePanel) timelinePanel.style.display = 'block';
  const timeline = document.getElementById('agent-timeline');
  if (timeline) timeline.innerHTML = '';

  switchPanel('chat');
  addChatMessage('user', `[Paper Agent] ${goal}\nJournal: ${journal} | Language: ${language} | Intent: ${state.currentIntent}`);

  try {
    const res = await fetch('/api/agent/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        goal,
        domain: 'academic',
        intent: state.currentIntent,
        journal,
        language,
        provider: provider || undefined,
        auto: false,
        harness: harnessEnabled ? { rules: harnessRules.split(',').map(s => s.trim()).filter(Boolean), verify: harnessVerify.split(',').map(s => s.trim()).filter(Boolean) } : undefined
      })
    });
    const data = await res.json();
    if (data.sessionId) state.sessionId = data.sessionId;
  } catch (e) {
    addChatMessage('agent', 'Failed to start agent: ' + e.message);
    resetAgentUI();
  }
}

// ---- 中间检查点卡片 (分段执行) ----
function showCheckpointCard(ev, msgEl) {
  const stepsEl = msgEl ? msgEl.querySelector('.thinking-steps') : null;
  const container = document.createElement('div');
  container.className = 'checkpoint-card';
  container.innerHTML =
    '<div class="checkpoint-title">⏸ 阶段完成 — ' + escapeHtml((ev.node && ev.node.title) || '') + '</div>' +
    '<pre class="checkpoint-result">' + escapeHtml((ev.result || '').slice(0, 600)) + '</pre>' +
    '<div class="checkpoint-actions">' +
      '<button class="btn-primary btn-sm" id="cp-continue">▶ 继续</button>' +
      '<button class="btn-secondary btn-sm" id="cp-modify">✏ 修改后继续</button>' +
      '<button class="btn-ghost btn-sm" id="cp-skip">⏭ 跳过剩余</button>' +
    '</div>';
  if (stepsEl) stepsEl.appendChild(container);
  const done = (decision, note) => {
    fetch('/api/agent/checkpoint', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ decision, note: note || '' }) }).catch(() => {});
    container.querySelectorAll('button').forEach(b => b.disabled = true);
    container.querySelector('.checkpoint-actions').innerHTML = '<span style="color:var(--text-tertiary);font-size:12px">执行中…</span>';
  };
  container.querySelector('#cp-continue')?.addEventListener('click', () => done('continue'));
  container.querySelector('#cp-modify')?.addEventListener('click', () => {
    const note = prompt('输入修改意见，Agent 将在后续阶段中采纳：');
    done('modify', note || '');
  });
  container.querySelector('#cp-skip')?.addEventListener('click', () => done('skip'));
}

// ---- 实时产物卡片 (agent 写文件时推送) ----
function appendArtifactCard(ev, msgEl) {
  const container = document.createElement('div');
  container.className = 'artifact-card';
  const preview = String(ev.preview || '').slice(0, 400);
  container.innerHTML =
    '<div class="artifact-head">📄 <span class="artifact-name">' + escapeHtml(ev.file || '') + '</span>' +
      '<span class="artifact-size">' + fmtBytes(ev.size || 0) + '</span></div>' +
    (preview ? '<pre class="artifact-preview">' + escapeHtml(preview) + '</pre>' : '') +
    '<div class="artifact-actions"><button class="btn-secondary btn-sm" onclick="openArtifactDetail(' + JSON.stringify(String(ev.file || '')) + ')">查看完整内容</button></div>';
  // Append to the ANSWER area (NOT the collapsible thinking steps), so the card
  // stays visible after the thinking block collapses on completion.
  const answerWrap = msgEl ? msgEl.querySelector('.thinking-answer-wrap') : null;
  if (answerWrap) {
    answerWrap.style.display = 'block';
    answerWrap.appendChild(container);
  } else {
    const stepsEl = msgEl ? msgEl.querySelector('.thinking-steps') : null;
    if (stepsEl) stepsEl.appendChild(container);
  }
  const c = document.getElementById('chat-messages');
  if (c) c.scrollTop = c.scrollHeight;
}
function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
// ---- 产物抽屉：列出当前项目所有产物文件 ----
function openArtifactDetail(name) {
  fetch('/api/projects/artifact-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    .then(r => r.json()).then(d => {
      if (d.error) { showToast(d.error, 'error'); return; }
      const panel = document.getElementById('preview-content');
      if (panel) {
        panel.innerHTML = '<div class="preview-header"><strong>📄 ' + escapeHtml(d.name) + '</strong><button class="btn-ghost btn-sm" onclick="this.parentElement.parentElement.querySelector(\'pre\').style.display=this.parentElement.parentElement.querySelector(\'pre\').style.display===\'none\'?\'block\':\'none\'">收起/展开</button></div><pre style="white-space:pre-wrap;font-size:12px;line-height:1.6;max-height:70vh;overflow-y:auto">' + escapeHtml(d.content) + '</pre>';
        document.querySelector('.app-layout')?.classList.add('preview-open');
      } else {
        // No preview panel: show in a modal-ish overlay.
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.style.display = 'flex';
        modal.innerHTML = '<div class="modal-card" style="width:min(760px,92vw);max-height:85vh;overflow:auto"><h3 class="modal-title">📄 ' + escapeHtml(d.name) + '</h3><pre style="white-space:pre-wrap;font-size:12px;line-height:1.6">' + escapeHtml(d.content) + '</pre><div class="modal-actions"><button class="btn-modal-cancel" onclick="this.closest(\'.modal-overlay\').remove()">关闭</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
      }
    }).catch(() => showToast('读取产物失败', 'error'));
}
// ---- 产物抽屉（Chat 头部按钮）----
function openArtifactsDrawer() {
  fetch('/api/projects/artifacts').then(r => r.json()).then(d => {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.style.display = 'flex';
    const list = (d.artifacts || []).length
      ? d.artifacts.map(f => '<div class="artifact-row"><span class="artifact-name">📄 ' + escapeHtml(f.name) + '</span><span class="artifact-size">' + fmtBytes(f.size) + '</span><button class="btn-secondary btn-sm" onclick="openArtifactDetail(' + JSON.stringify(String(f.name)) + ')">查看</button></div>').join('')
      : '<div style="color:var(--text-tertiary);padding:12px 0">暂无产物 — Agent 执行时写入 artifacts/ 目录的文件会出现在这里</div>';
    modal.innerHTML = '<div class="modal-card" style="width:min(640px,92vw);max-height:80vh;display:flex;flex-direction:column"><h3 class="modal-title">📦 项目产物 (' + (d.artifacts || []).length + ')</h3><div style="overflow-y:auto;display:flex;flex-direction:column;gap:6px;padding:4px 0 10px">' + list + '</div><div class="modal-actions"><button class="btn-modal-cancel" onclick="this.closest(\'.modal-overlay\').remove()">关闭</button></div></div>';
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  }).catch(() => showToast('加载产物失败', 'error'));
}

function cancelAgent() {  fetch('/api/agent/cancel', { method: 'POST' }).catch(() => {});
  state.agentRunning = false;
  resetAgentUI();
  addChatMessage('agent', 'Agent cancelled.');
  showToast('Agent cancelled', 'info');
}

function resetAgentUI() {
  state.agentRunning = false;
  const runBtn = document.getElementById('paper-run-btn');
  const cancelBtn = document.getElementById('paper-cancel-btn');
  if (runBtn) runBtn.style.display = 'inline-flex';
  if (cancelBtn) cancelBtn.style.display = 'none';
}

// ---------- Agent Polling (SSE / REST) ----------
async function pollAgentState() {
  try {
    const res = await fetch('/api/agent/status');
    if (!res.ok) { setTimeout(pollAgentState, 2000); return; }
    const data = await res.json();

    if (data.project) state.projectName = data.project;
    if (data.gitBranch) state.gitBranch = data.gitBranch;

    // Update project name in the chat header (with null-safety).
    const nameEl = document.getElementById('project-name-display') || document.getElementById('project-name-header');
    if (nameEl) nameEl.textContent = state.projectName;
    const gitBadge = document.getElementById('git-badge');
    if (state.gitBranch) {
      gitBadge.style.display = 'inline-block';
      gitBadge.textContent = '#' + state.gitBranch;
    }

    // Check for pending events (polling fallback when SSE not connected)
    if (state.sessionId) {
      try {
        const evRes = await fetch('/api/agent/events?sid=' + state.sessionId);
        if (evRes.ok) {
          const evData = await evRes.json();
          if (evData.events) handleAgentEvents(evData.events);
        }
      } catch (_) {}
    }
  } catch (_) {}

  setTimeout(pollAgentState, 2000);
}

// Setup SSE connection
function connectSSE() {
  if (window._sse && window._sse.readyState === EventSource.OPEN) return; // already connected
  if (window._sse) { window._sse.close(); window._sse = null; }
  const es = new EventSource('/api/agent/events');
  window._sse = es;
  es.onmessage = e => {
    try {
      const data = JSON.parse(e.data);
      if (data.type === 'step') handleStep(data);
      else if (data.type === 'pipeline_step') handlePipelineStep(data);
      else if (data.type === 'approval') handleApprovalEvent(data);
      else if (data.type === 'question') handleQuestionEvent(data);
      else if (data.type === 'plan') handlePlanEvent(data);
      else if (data.type === 'done') handleDoneEvent(data);
      else if (data.type === 'error') handleErrorEvent(data);
    } catch (_) {}
  };
  es.onerror = () => { es.close(); window._sse = null; setTimeout(connectSSE, 3000); };
}

function resetChat() {
  const container = document.getElementById('chat-messages');
  if (!container) return;
  container.innerHTML = `
    <div class="chat-welcome">
      <div class="welcome-aura" aria-hidden="true"></div>
      <div class="welcome-logo">
        <svg class="ae-logo ae-logo-lg" width="64" height="64" viewBox="0 0 32 32"><use href="#aetheris-mark" width="32" height="32"/></svg>
      </div>
      <h3 class="brand-gradient">灵思</h3>
      <p>让我帮你写论文、跑数据分析、绘图，或执行任何任务。</p>
      <p class="welcome-credit">by Peng Haoyun</p>
    </div>`;
  // Clear preview tabs
  if (typeof previewState !== 'undefined') { previewState.tabs = []; previewState.activeId = null; }
  const pc = document.getElementById('preview-content');
  if (pc) pc.innerHTML = '<div class="preview-empty"><p>Select a file or result to preview</p></div>';
  document.querySelector('.app-layout')?.classList.remove('preview-open');
  // Reset workflow pills
  currentWorkflow = '';
  document.querySelectorAll('.wf-pill').forEach(p => p.classList.remove('active'));
  // Reset chat input
  const input = document.getElementById('chat-input');
  if (input) { input.value = ''; input.placeholder = '描述你的研究需求…'; }
  // Reset timeline panel
  const tl = document.getElementById('agent-timeline-panel');
  if (tl) tl.style.display = 'none';
  const tlContent = document.getElementById('timeline-content');
  if (tlContent) tlContent.innerHTML = '';
  // Reset agent UI state
  resetAgentUI();
  // Reconnect SSE for the new project
  connectSSE();
}

function handleAgentEvents(events) {
  events.forEach(ev => {
    if (ev.type === 'step') handleStep(ev);
    else if (ev.type === 'approval') handleApprovalEvent(ev);
    else if (ev.type === 'question') handleQuestionEvent(ev);
    else if (ev.type === 'plan') handlePlanEvent(ev);
    else if (ev.type === 'done') handleDoneEvent(ev);
    else if (ev.type === 'error') handleErrorEvent(ev);
  });
}

// 6-Agent pipeline progress → timeline with subagent role chips
function handlePipelineStep(data) {
  const timeline = document.getElementById('agent-timeline');
  if (!timeline) return;
  const empty = timeline.querySelector('.agent-timeline-empty');
  if (empty) empty.remove();
  const li = document.createElement('li');
  const icon = document.createElement('span');
  icon.className = 'tl-icon';
  icon.innerHTML = '&#9654;';
  li.appendChild(icon);
  const chip = document.createElement('span');
  chip.className = 'tl-feature tl-feature-subagent';
  chip.textContent = 'SA ' + (data.role || 'agent');
  li.appendChild(chip);
  const text = document.createElement('span');
  text.textContent = (data.step && (data.step.description || data.step.thought || data.step.tool)) || '执行子智能体步骤…';
  li.appendChild(text);
  timeline.appendChild(li);
  timeline.parentElement.scrollTop = timeline.parentElement.scrollHeight;
}

function handleStep(data) {
  const badge = document.getElementById('agent-step-badge');
  if (badge) badge.textContent = 'step ' + (data.step || '?');

  const timeline = document.getElementById('agent-timeline');
  if (!timeline) return;

  // Remove empty placeholder
  const empty = timeline.querySelector('.agent-timeline-empty');
  if (empty) empty.remove();

  const li = document.createElement('li');
  const icon = document.createElement('span');
  icon.className = 'tl-icon';
  icon.innerHTML = data.tool ? '&#9654;' : '&#9679;';
  li.appendChild(icon);

  // Feature badge: show WHICH Aetheris capability is in use (skill/database/training…).
  if (data.feature) {
    const f = data.feature;
    const chip = document.createElement('span');
    chip.className = 'tl-feature tl-feature-' + (f.kind || 'tool');
    chip.textContent = f.icon + ' ' + f.label;
    chip.title = (f.detail || '') + ' — 正在使用灵思功能';
    li.appendChild(chip);
  }

  const text = document.createElement('span');
  text.textContent = data.description || data.thought || (data.tool ? 'Running ' + data.tool : 'Thinking...');
  li.appendChild(text);
  timeline.appendChild(li);
  timeline.parentElement.scrollTop = timeline.parentElement.scrollHeight;

  // Live output
  if (data.output) {
    const live = document.getElementById('agent-live');
    if (live) {
      live.style.display = 'block';
      live.textContent = data.output;
    }
  }
}

function handleApprovalEvent(data) {
  state.pendingApproval = data;
  const container = document.getElementById('approval-inline');
  if (!container) return;
  container.style.display = 'block';
  container.innerHTML = `
    <div class="approval-card">
      <div class="approval-card-header">
        <h4>Approval Required: ${data.tool || 'action'}</h4>
        <span class="badge" style="color:var(--color-warning)">HIGH RISK</span>
      </div>
      <div class="approval-card-body">
        <pre>${escapeHtml(JSON.stringify(data.args || {}, null, 2))}</pre>
        ${data.reasoning ? `<p style="margin-top:8px;font-size:12px;color:var(--color-text-secondary)">${escapeHtml(data.reasoning)}</p>` : ''}
      </div>
      <div class="approval-card-actions">
        <button class="btn-accept" onclick="respondApproval('approve')">Approve</button>
        <button class="btn-reject" onclick="respondApproval('reject')">Reject</button>
        <button class="btn-ghost btn-sm" onclick="respondApproval('edit')">Edit</button>
      </div>
    </div>
  `;
}

function handleQuestionEvent(data) {
  state.pendingQuestion = data;
  const container = document.getElementById('approval-inline');
  if (!container) return;
  container.style.display = 'block';

  let optionsHtml = '';
  if (data.options && data.options.length) {
    optionsHtml = '<div class="question-card-options">';
    data.options.forEach((opt, i) => {
      optionsHtml += `<button class="btn-secondary" onclick="respondQuestion(${i})">${escapeHtml(opt)}</button>`;
    });
    optionsHtml += '</div>';
  }

  container.innerHTML = `
    <div class="question-card">
      <h4>Question</h4>
      <div class="question-card-body">${escapeHtml(data.question || '')}</div>
      ${optionsHtml}
      <div class="question-card-input-row">
        <input type="text" id="question-text-input" class="form-input" placeholder="Or type your answer..." style="flex:1">
        <button class="btn-primary btn-sm" onclick="respondQuestionText()">Submit</button>
      </div>
    </div>
  `;
}

function handlePlanEvent(data) {
  state.planNodes = data.nodes || [];
  state.planApproved = false;

  const container = document.getElementById('approval-inline');
  if (!container || !state.planNodes.length) return;
  container.style.display = 'block';

  let nodesHtml = '<ul style="list-style:none;padding-left:0">';
  state.planNodes.forEach(n => {
    nodesHtml += `<li style="padding:4px 0;font-size:13px">${n.dependsOn && n.dependsOn.length ? '↳ ' : '• '}${escapeHtml(n.goal || n)}</li>`;
  });
  nodesHtml += '</ul>';

  container.innerHTML = `
    <div class="question-card">
      <h4>Execution Plan (${state.planNodes.length} steps)</h4>
      <div class="question-card-body">${nodesHtml}</div>
      <div class="approval-card-actions">
        <button class="btn-accept" onclick="respondPlan('approve')">Approve Plan</button>
        <button class="btn-reject" onclick="respondPlan('reject')">Reject Plan</button>
      </div>
    </div>
  `;
}

function handleDoneEvent(data) {
  state.agentRunning = false;
  resetAgentUI();
  addChatMessage('agent', data.summary || 'Task completed.');
  // Add review button after agent completion
  const chatContainer = document.getElementById('chat-messages');
  if (chatContainer) {
    const lastMsg = chatContainer.lastElementChild;
    if (lastMsg && lastMsg.classList.contains('msg-agent')) {
      const reviewBtn = document.createElement('button');
      reviewBtn.className = 'btn-ghost';
      reviewBtn.style.cssText = 'margin-top:8px;font-size:11px;padding:4px 10px;border:1px solid var(--accent);color:var(--accent);border-radius:12px;cursor:pointer';
      reviewBtn.textContent = t('review.trigger');
      reviewBtn.title = t('review.trigger');
      reviewBtn.addEventListener('click', triggerReview);
      lastMsg.appendChild(reviewBtn);
    }
  }

  // Auto-surface produced output in the preview panel (B: auto-split preview).
  // The done event only carries a summary; we scan it for file/plot hints so
  // chat-driven tasks also pop a preview tab without manual clicking.
  const text = (data.summary || '') + ' ' + (data.detail || '');
  const fileMatch = text.match(/([\w.\-/\\]+\.(?:md|txt|pdf|csv|tex|png|jpg|jpeg|html|json|py)\b)/i);
  const plotMatch = /plot|figure|图表|图\b|figure/i.test(text);
  if (fileMatch) {
    const fname = fileMatch[1].split(/[\\/]/).pop();
    addPreviewTab(fname, `任务已生成文件：\n${fileMatch[1]}\n\n在预览面板查看完整内容。`, 'text');
  } else if (plotMatch) {
    addPreviewTab('Output', data.summary || 'Task completed.', 'text');
  }

  // Refresh run history dashboard
  loadRuns();

  const container = document.getElementById('approval-inline');
  if (container) container.style.display = 'none';
}

function handleErrorEvent(data) {
  state.agentRunning = false;
  resetAgentUI();
  addChatMessage('agent', 'Error: ' + (data.error || data.message || 'Unknown error'));
}

// ---------- Approval Responses ----------
async function respondApproval(action) {
  const aid = state.pendingApproval?.id;
  if (!aid) return;
  try {
    await fetch('/api/agent/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: aid, action })
    });
  } catch (_) {}
  state.pendingApproval = null;
  document.getElementById('approval-inline').style.display = 'none';
}

async function respondEditApproval() {
  const aid = state.pendingApproval?.id;
  const editArea = document.getElementById('agent-edit-area');
  if (!aid || !editArea) return;
  try {
    const newArgs = JSON.parse(editArea.querySelector('textarea')?.value || '{}');
    await fetch('/api/agent/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: aid, action: 'edit', args: newArgs })
    });
  } catch (_) {}
  state.pendingApproval = null;
  document.getElementById('approval-inline').style.display = 'none';
}

async function respondQuestion(optIndex) {
  if (!state.pendingQuestion) return;
  try {
    await fetch('/api/agent/question', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: state.pendingQuestion.id, answer: String(optIndex) })
    });
  } catch (_) {}
  state.pendingQuestion = null;
  document.getElementById('approval-inline').style.display = 'none';
}

async function respondQuestionText() {
  const input = document.getElementById('question-text-input');
  if (!input || !state.pendingQuestion) return;
  try {
    await fetch('/api/agent/question', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: state.pendingQuestion.id, answer: input.value })
    });
  } catch (_) {}
  state.pendingQuestion = null;
  document.getElementById('approval-inline').style.display = 'none';
}

async function respondPlan(action) {
  try {
    await fetch('/api/agent/plan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action })
    });
  } catch (_) {}
  state.planApproved = action === 'approve';
  document.getElementById('approval-inline').style.display = 'none';
}

// ---------- Dashboard ----------
async function loadDashboard() {
  try {
    const res = await fetch('/api/dashboard');
    if (!res.ok) return;
    const data = await res.json();

    const handoffEl = document.getElementById('handoff-content');
    if (handoffEl && data.handoff) {
      handoffEl.innerHTML = data.handoff.replace(/\n/g, '<br>');
    }
  } catch (_) {}
}

async function loadProjects() {
  try {
    const res = await fetch('/api/projects');
    if (!res.ok) { renderProjectSidebar(); return; }
    const data = await res.json();
    state.activeProjectDir = data.active || '';
    state.projects = data.projects || [];
    state.projectTree = data.tree || null;
    state.rootProject = data.rootProject || '';
    renderProjectSidebar();
  } catch (_) { renderProjectSidebar(); }
}

async function loadProjectInfo() {
  try {
    const st = await fetch('/api/agent/status');
    if (st.ok) {
      const d = await st.json();
      state.projectName = d.project || 'aetheris';
      state.gitBranch = d.gitBranch || '';
    }
  } catch (_) {}
}

function renderProjectSidebar() {
  const list = document.getElementById('sidebar-projects-list');
  if (!list) return;

  const nodeHtml = (node, depth) => {
    if (!node) return '';
    const pad = Math.min(depth, 8);
    const isProject = node.isProject !== false;
    const icon = isProject ? (node.isActive ? '🟣' : '📦') : '📁';
    const name = String(node.name || '');
    const kids = (node.children || []).map(c => nodeHtml(c, depth + 1)).join('');
    return `<div class="sidebar-project-entry${node.isActive ? ' active' : ''}" data-dir="${String(node.dir || '').replace(/"/g, '&quot;')}" data-isproject="${isProject ? 1 : 0}" style="padding-left:${8 + pad * 14}px" title="${String(node.dir || '').replace(/"/g, '&quot;')}">
      <span class="sp-dot"></span>
      <span class="sp-name">${icon} ${name.replace(/</g, '&lt;')}</span>
      ${node.isActive ? '' : '<button class="sp-remove" data-dir="' + String(node.dir || '').replace(/"/g, '&quot;') + '">×</button>'}
    </div>${kids}`;
  };

  const tree = state.projectTree || null;
  // Fallback: no tree → render flat project list so the sidebar stays usable.
  if (!tree) {
    if (state.projects && state.projects.length) {
      list.innerHTML = state.projects.map(p => `<div class="sidebar-project-entry${p.isActive ? ' active' : ''}" data-dir="${String(p.dir || '').replace(/"/g, '&quot;')}" data-isproject="1">
        <span class="sp-dot"></span><span class="sp-name">📦 ${String(p.name || '').replace(/</g, '&lt;')}</span>
        ${p.isActive ? '' : '<button class="sp-remove" data-dir="' + String(p.dir || '').replace(/"/g, '&quot;') + '">×</button>'}
      </div>`).join('');
      list.querySelectorAll('.sidebar-project-entry:not(.active)').forEach(el => {
        el.addEventListener('click', () => switchProject(el.dataset.dir));
        el.addEventListener('contextmenu', (e) => { e.preventDefault(); openProjectContextMenu(e.clientX, e.clientY, el); });
      });
      list.querySelectorAll('.sp-remove').forEach(btn => {
        btn.addEventListener('click', (e) => { e.stopPropagation(); removeProject(btn.dataset.dir); });
      });
      return;
    }
    list.innerHTML = '<div class="sidebar-project-entry" style="opacity:0.5;font-style:italic">添加第一个项目</div>';
    return;
  }
  list.innerHTML = nodeHtml(tree, 0);

  list.querySelectorAll('.sidebar-project-entry').forEach(el => {
    const dir = el.dataset.dir;
    // Right-click: context menu (new sub-project / switch / delete).
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      openProjectContextMenu(e.clientX, e.clientY, el);
    });
    // Left-click: switch (only for real project nodes).
    if (!el.classList.contains('active') && el.dataset.isproject === '1') {
      el.addEventListener('click', () => switchProject(dir));
    }
  });
  list.querySelectorAll('.sp-remove').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); removeProject(btn.dataset.dir); });
  });
}

// ---- Project context menu (right-click) ----
let _ctxDir = '';
let _ctxIsProject = false;
function openProjectContextMenu(x, y, entryEl) {
  _ctxDir = entryEl.dataset.dir;
  _ctxIsProject = entryEl.dataset.isproject === '1';
  const menu = document.getElementById('project-ctx-menu');
  if (!menu) return;
  document.getElementById('ctx-new-sub').style.display = _ctxIsProject ? '' : 'none';
  document.getElementById('ctx-switch').style.display = _ctxIsProject ? '' : 'none';
  document.getElementById('ctx-delete').style.display = _ctxIsProject ? '' : 'none';
  menu.style.display = 'block';
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  menu.style.left = Math.min(x, window.innerWidth - mw - 8) + 'px';
  menu.style.top = Math.min(y, window.innerHeight - mh - 8) + 'px';
  const hide = () => { menu.style.display = 'none'; document.removeEventListener('click', hide); };
  setTimeout(() => document.addEventListener('click', hide), 10);
}
function setupProjectContextMenu() {
  const menu = document.getElementById('project-ctx-menu');
  if (!menu) return;
  document.getElementById('ctx-new-sub')?.addEventListener('click', () => { openAddProjectModal(_ctxDir, true); });
  document.getElementById('ctx-switch')?.addEventListener('click', () => { if (_ctxDir) switchProject(_ctxDir); });
  document.getElementById('ctx-delete')?.addEventListener('click', () => { if (_ctxDir) removeProject(_ctxDir); });
  window.addEventListener('contextmenu', (e) => { if (!e.target.closest('.sidebar-project-entry')) menu.style.display = 'none'; });
}

// Per-project chat cache — persists across project switches within a session
window._chatCache = window._chatCache || {};

async function switchProject(dir) {
  // Save current project's chat before leaving
  const prevDir = state.activeProjectDir;
  if (prevDir) {
    const chatEl = document.getElementById('chat-messages');
    const tlEl = document.getElementById('agent-timeline-panel');
    const previewEl = document.getElementById('preview-content');
    window._chatCache[prevDir] = {
      chatHTML: chatEl ? chatEl.innerHTML : '',
      timelineHTML: tlEl ? tlEl.innerHTML : '',
      timelineVisible: tlEl ? tlEl.style.display : 'none',
      previewHTML: previewEl ? previewEl.innerHTML : '',
      previewOpen: document.querySelector('.app-layout')?.classList.contains('preview-open'),
      workflowId: currentWorkflow,
    };
  }

  try {
    const res = await fetch('/api/projects/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dir })
    });
    if (!res.ok) { const e = await res.json(); showToast(e.error || '切换失败', 'error'); return; }
    const data = await res.json();
    state.projectDir = data.dir;
    state.projectName = data.name;
    state.projects = data.projects || [];
    state.activeProjectDir = data.dir;

    // Restore cached chat if available, else show welcome
    const cached = window._chatCache[data.dir];
    if (cached) {
      restoreChatFromCache(cached);
    } else {
      resetChat();
    }

    loadDashboard();
    loadRuns();
    loadMemory();
    loadSecurity();
    loadGoals();
    loadProjectInfo();
    loadSessionList();
    pollAgentState();
    loadProjects(); // refresh the project tree (active marker + new subs)
    // Reload the notes panel for the switched project (per-project notes).
    if (typeof initNotesPanel === 'function') {
      const editor = document.getElementById('notes-editor');
      if (editor) {
        try {
          fetch('/api/notes').then(r => r.json()).then(d => {
            editor.value = d.content || '';
            window._notesEnabled = !!d.enabled;
            const t = document.getElementById('notes-toggle-text');
            if (t) t.textContent = window._notesEnabled ? '🔓 已授权 — 智能体可读取' : '🔒 未授权 — 智能体不可读';
            const btn = document.getElementById('notes-toggle-btn');
            if (btn) btn.classList.toggle('on', window._notesEnabled);
          }).catch(() => {});
        } catch (_) {}
      }
    }
    showToast('已切换至 ' + data.name, 'success');
  } catch (e) {
    showToast('切换失败：' + (e.message || '网络错误'), 'error');
  }
}

function restoreChatFromCache(cached) {
  const container = document.getElementById('chat-messages');
  if (container && cached.chatHTML) container.innerHTML = cached.chatHTML;
  // Restore timeline
  const tl = document.getElementById('agent-timeline-panel');
  if (tl) { tl.style.display = cached.timelineVisible || 'none'; if (cached.timelineHTML) tl.innerHTML = cached.timelineHTML; }
  // Restore preview
  const pc = document.getElementById('preview-content');
  if (pc && cached.previewHTML) pc.innerHTML = cached.previewHTML;
  if (cached.previewOpen) document.querySelector('.app-layout')?.classList.add('preview-open');
  else document.querySelector('.app-layout')?.classList.remove('preview-open');
  // Restore workflow
  currentWorkflow = cached.workflowId || '';
  document.querySelectorAll('.wf-pill').forEach(p => p.classList.toggle('active', p.dataset.wf === currentWorkflow));
  // Reconnect SSE
  resetAgentUI();
  connectSSE();
}

async function addProject(name) {
  try {
    const res = await fetch('/api/projects/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    if (!res.ok) { const e = await res.json(); showToast(e.error || '创建失败', 'error'); return; }
    const data = await res.json();
    showToast('项目已创建，自动切换中…', 'success');
    // Refresh the project tree, then auto-switch.
    await loadProjects();
    // Close modal + clear input
    closeAddProjectModal();
    const input = document.getElementById('modal-project-name');
    if (input) input.value = '';
    // Auto-switch to the newly added project (using the dir returned by server)
    if (data && data.dir) switchProject(data.dir);
  } catch (e) {
    showToast('创建失败', 'error');
  }
}

// Create a sub-project under a parent project folder (own archive + own notes).
async function createSubproject(name, parentDir) {
  if (!name) return;
  try {
    const res = await fetch('/api/projects/subproject', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, parent: parentDir || undefined })
    });
    const data = await res.json();
    if (!res.ok || !data.ok) { showToast(data.error || '创建失败', 'error'); return; }
    closeAddProjectModal();
    const input = document.getElementById('modal-project-name');
    if (input) input.value = '';
    showToast('子项目已创建: ' + data.name, 'success');
    await loadProjects();
    switchProject(data.dir);
  } catch (e) {
    showToast('创建失败: ' + e.message, 'error');
  }
}

async function removeProject(dir) {
  if (!confirm('⚠️ 此操作将永久删除该项目目录及其所有文件！\n\n确定删除？')) return;
  try {
    const res = await fetch('/api/projects/remove', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dir })
    });
    if (!res.ok) { const e = await res.json(); showToast(e.error || '移除失败', 'error'); return; }
    await loadProjects(); // refresh the project tree after removal
    showToast('已移除', 'success');
    // If the removed project was active, reload dashboard for the fallback project.
    loadDashboard(); loadRuns(); loadMemory(); loadProjectInfo(); loadSessionList();
  } catch (e) {
    showToast('移除失败', 'error');
  }
}

function openAddProjectModal(parentDir, isSub) {
  const modal = document.getElementById('add-project-modal');
  if (!modal) return;
  window._modalParent = parentDir || null;
  const title = document.getElementById('modal-title');
  const desc = document.getElementById('modal-desc');
  const btn = document.getElementById('modal-add-btn');
  if (isSub) {
    const pn = parentDir ? (parentDir.split(/[\\/]/).pop() || '主项目') : '主项目';
    if (title) title.textContent = '新建子项目';
    if (desc) desc.textContent = '将在「' + pn + '」下创建（独立档案 + 备注栏）：';
    if (btn) btn.textContent = '创建子项目';
  } else {
    if (title) title.textContent = '新建项目';
    if (desc) desc.textContent = '输入项目名称，系统自动创建并初始化：';
    if (btn) btn.textContent = '创建项目';
  }
  modal.style.display = 'flex';
  const input = document.getElementById('modal-project-name');
  if (input) { input.value = ''; setTimeout(() => input.focus(), 50); }
}
function closeAddProjectModal() {
  const modal = document.getElementById('add-project-modal');
  if (modal) modal.style.display = 'none';
}

async function loadSecurity() {
  try {
    const res = await fetch('/api/security');
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('security-content');
    if (el) {
      const issues = data.issues || [];
      el.innerHTML = !issues.length
        ? '<p style="color:var(--color-success)">No security issues found.</p>'
        : issues.map(i => '<p style="color:var(--color-danger)">' + escapeHtml(i) + '</p>').join('');
    }
  } catch (_) {}
}

async function loadGoals() {
  try {
    const res = await fetch('/api/goals');
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('goals-content');
    if (el && data.goals) {
      el.innerHTML = data.goals.map(g =>
        `<p>${g.completed ? '&#10003;' : '&#9711;'} ${escapeHtml(g.text)}</p>`
      ).join('');
    }
  } catch (_) {}
}

// ---------- RAG ----------
async function ragUpload() {
  const fileInput = document.getElementById('rag-file');
  const file = fileInput?.files?.[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('file', file);
  try {
    const res = await fetch('/api/rag/ingest', { method: 'POST', body: formData });
    const data = await res.json();
    const resultEl = document.getElementById('rag-result');
    if (resultEl) resultEl.textContent = data.ok ? 'Uploaded: ' + file.name : 'Error: ' + (data.error || '');
  } catch (e) {
    const resultEl = document.getElementById('rag-result');
    if (resultEl) resultEl.textContent = 'Upload failed: ' + e.message;
  }
}

async function ragQuery() {
  const query = document.getElementById('rag-query-input')?.value?.trim();
  if (!query) return;
  try {
    const res = await fetch('/api/rag/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query })
    });
    const data = await res.json();
    const resultEl = document.getElementById('rag-result');
    if (resultEl) resultEl.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    const resultEl = document.getElementById('rag-result');
    if (resultEl) resultEl.textContent = 'Query failed: ' + e.message;
  }
}

// ---------- Plot ----------
let lastPlotId = null;
let currentDataFile = null;

// ---------- Data Analysis ----------
function setupDataPanel() {
  // Tab switching
  document.querySelectorAll('#data-tabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#data-tabs .tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('#panel-data .tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const target = document.getElementById('data-tab-' + btn.dataset.tab);
      if (target) target.classList.add('active');
    });
  });

  // File upload
  document.getElementById('data-upload-btn').addEventListener('click', uploadDataFile);

  // Export content from last result
  const exportContent = document.getElementById('data-result')?.textContent || '';
}

async function uploadDataFile() {
  const fileInput = document.getElementById('data-file');
  const file = fileInput?.files?.[0];
  if (!file) return;

  const statusEl = document.getElementById('data-file-status');
  statusEl.style.display = 'block';
  statusEl.textContent = t('data.running');
  statusEl.style.color = 'var(--color-text-secondary)';

  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await fetch('/api/upload', { method: 'POST', body: formData });
    if (!res.ok) throw new Error('Upload failed');
    const data = await res.json();
    if (data.ok || data.path) {
      currentDataFile = data.path || data.file || file.name;
      statusEl.textContent = t('data.file_loaded') + currentDataFile;
      statusEl.style.color = 'var(--color-success)';
    } else {
      // Try to use the data import tool instead
      currentDataFile = file.name;
      const importRes = await fetch('/api/data/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files: [file.name], targetFormat: 'csv' })
      });
      const importData = await importRes.json();
      if (importData.ok) {
        currentDataFile = importData.file || file.name;
        statusEl.textContent = t('data.file_loaded') + currentDataFile;
        statusEl.style.color = 'var(--color-success)';
      } else {
        statusEl.textContent = 'Import note: ' + (importData.error || 'file ready');
        statusEl.style.color = 'var(--color-warning)';
      }
    }
  } catch (e) {
    // If upload endpoint doesn't exist, use filename directly
    currentDataFile = file.name;
    statusEl.textContent = t('data.file_loaded') + currentDataFile + ' (direct)';
    statusEl.style.color = 'var(--color-success)';
  }
}

async function runDataAnalysis(tool) {
  if (!currentDataFile) {
    alert(t('data.no_file'));
    return;
  }

  const resultCard = document.getElementById('data-result-card');
  const resultEl = document.getElementById('data-result');
  resultCard.style.display = 'block';
  resultEl.textContent = t('data.running');

  let args = { file: currentDataFile };

  if (tool === 'describe') {
    const varsStr = document.getElementById('data-describe-vars')?.value.trim();
    args.vars = varsStr ? varsStr.split(',').map(s => s.trim()).filter(Boolean) : undefined;
    args.figure = document.getElementById('data-describe-figure')?.checked || false;
  } else if (tool === 'regress') {
    args.y = document.getElementById('data-regress-y')?.value.trim();
    const xStr = document.getElementById('data-regress-x')?.value.trim();
    args.x = xStr ? xStr.split(',').map(s => s.trim()).filter(Boolean) : [];
    args.method = document.getElementById('data-regress-method')?.value || 'ols';
    args.figure = document.getElementById('data-regress-figure')?.checked || false;
  } else if (tool === 'clean') {
    args.missing = document.getElementById('data-clean-missing')?.value || 'report';
    args.outlier = document.getElementById('data-clean-outlier')?.value || 'report';
    args.duplicate = document.getElementById('data-clean-duplicate')?.value || 'report';
  } else if (tool === 'transform') {
    const expr = document.getElementById('data-transform-expr')?.value.trim();
    if (!expr) { resultEl.textContent = 'Enter a Python expression.'; return; }
    // For transform, wrap in an op object
    args.ops = [{ op: 'newvar', name: 'new_col', expr: expr }];
  } else if (tool === 'export') {
    const format = document.getElementById('data-export-format')?.value || 'md';
    const name = document.getElementById('data-export-name')?.value.trim() || 'result';
    const content = resultEl.textContent || 'No results to export.';
    args = { content, format, name };
  }

  try {
    const res = await fetch('/api/data/' + tool, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(args)
    });
    const data = await res.json();
    if (data.ok) {
      // Format the output nicely
      let output = '';
      if (data.table) output += data.table;
      if (data.summary) output += '\n' + data.summary;
      if (data.stdout) output += '\n' + data.stdout;
      if (data.content) output += data.content;
      if (data.output) output += data.output;
      if (data.warning) output += '\n⚠ ' + data.warning;
      if (!output.trim()) output = JSON.stringify(data, null, 2);
      resultEl.textContent = output || 'Done.';
      showToast(tool.charAt(0).toUpperCase() + tool.slice(1) + ' completed', 'success');
      if (tool === 'export' && data.wrote) {
        resultEl.textContent = 'Exported to: ' + data.wrote + '\n' + (data.content || '');
      }
    } else {
      resultEl.textContent = t('data.error') + ': ' + (data.error || 'Unknown');
      // Show partial output if available
      if (data.stdout) resultEl.textContent += '\n\nOutput:\n' + data.stdout;
    }
  } catch (e) {
    resultEl.textContent = t('data.error') + ': ' + e.message;
  }
}

async function renderPlot() {
  const code = document.getElementById('plot-code')?.value;
  if (!code) return;

  // Disable export buttons while rendering
  ['plot-export-png', 'plot-export-tiff', 'plot-export-pdf'].forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.disabled = true;
  });
  lastPlotId = null;

  try {
    const res = await fetch('/api/plot/render', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });
    const data = await res.json();
    const preview = document.getElementById('plot-preview-area');
    if (preview && data.preview) {
      preview.innerHTML = `<img src="${data.preview}" alt="Plot">`;
      addPreviewTab('Plot', `<img src="${data.preview}" style="max-width:100%;height:auto" alt="Plot">`, 'html');
    } else if (preview) {
      preview.innerHTML = '<p style="color:var(--color-danger)">Render failed: ' + (data.error || '') + '</p>';
    }
    // Save plot id and enable export buttons for produced formats
    if (data.ok && data.id && data.formats) {
      lastPlotId = data.id;
      data.formats.forEach(f => {
        const btn = document.getElementById('plot-export-' + f);
        if (btn) btn.disabled = false;
      });
    }
  } catch (e) {
    const preview = document.getElementById('plot-preview-area');
    if (preview) preview.innerHTML = '<p style="color:var(--color-danger)">Render error: ' + e.message + '</p>';
  }
}

function downloadPlot(format) {
  if (!lastPlotId) return;
  // Download via the server's export endpoint for proper Content-Type
  const a = document.createElement('a');
  a.href = '/api/plot/export/' + lastPlotId + '/' + format;
  a.download = 'figure.' + format;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// ---------- Panel Chat (context-aware LLM dialog) ----------
function setupPanelChats() {
  document.querySelectorAll('.panel-chat-textarea').forEach(textarea => {
    textarea.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendPanelChat(textarea.dataset.panel);
      }
    });
    textarea.addEventListener('input', () => {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 80) + 'px';
    });
  });
  document.querySelectorAll('.panel-chat .btn-send-sm').forEach(btn => {
    btn.addEventListener('click', () => sendPanelChat(btn.dataset.panel));
  });
}

function getPanelContext(panelId) {
  if (panelId === 'paper') {
    const goal = document.getElementById('paper-goal')?.value || '';
    const journal = document.getElementById('paper-journal')?.value || '';
    const intent = document.getElementById('paper-intent')?.value || '';
    return 'The user is in the Paper Agent panel. Target journal: ' + journal + '. Intent: ' + (intent || 'new_paper') + '. Topic: "' + goal + '". They want a custom action related to academic paper writing.\n\n' +
      'GROUNDING RULES:\n' +
      '- Only use the topic and journal provided above as source material. Do NOT invent additional claims, data, citations, author names, affiliations, or experimental results.\n' +
      '- If the user asks for something the provided context does not cover, respond with: "AUTHOR_INPUT_NEEDED: I need [specific information] to proceed. Please provide [what is missing]."\n' +
      '- Never fabricate bibliographic entries. If a citation is needed, suggest using the litSearch tool or paper panel.\n' +
      '- If asked to write a section, ground every claim in the topic provided. Mark unsupported assertions with "[needs evidence]".';
  }
  if (panelId === 'data') {
    const file = currentDataFile || '(no file specified)';
    return 'The user is in the Data Analysis panel. Loaded data file: ' + file + '. They want a custom analysis, data transformation, or visualization.\n\n' +
      'GROUNDING RULES:\n' +
      '- ONLY reference the data file listed above. Do NOT invent column names, data types, or statistical results unless the user explicitly provides them.\n' +
      '- If the user asks for analysis on data not yet loaded, respond: "DATA_INPUT_NEEDED: Please load the data file first using the upload button above."\n' +
      '- Provide pandas/matplotlib code that is runnable as-is — use pd.read_csv("' + file + '") to load the actual file. Do NOT generate synthetic data unless the user explicitly asks for a demo.\n' +
      '- If column names are unknown, add a step to inspect: "df.columns" or "df.head()" in the code.\n' +
      '- Mark any analysis that depends on unknown column names with "COLUMN_INPUT_NEEDED: [column name]" in the response.';
  }
  if (panelId === 'plot') {
    const code = document.getElementById('plot-code')?.value || '';
    const snippet = code.slice(0, 600);
    return 'The user is in the Plot Editor panel. Current matplotlib code:\n```python\n' + snippet + (code.length > 600 ? '\n# ... (truncated)' : '') + '\n```\nThey want to modify, enhance, or replace this plot.\n\n' +
      'GROUNDING RULES:\n' +
      '- ONLY modify the provided code above. Do NOT generate a completely unrelated plot unless the user explicitly asks to start from scratch.\n' +
      '- Return the FULL modified Python script in a single code block. Do NOT output fragments or partial changes — the user will copy-paste the entire block.\n' +
      '- If the user has not provided any code yet, respond: "CODE_INPUT_NEEDED: Please write or paste matplotlib code in the editor above, then describe what you want to change."\n' +
      '- Do NOT invent data loading paths, figure dimensions, or styling that contradicts the original code. Preserve the original intent while applying the requested changes.\n' +
      '- If a requested change is ambiguous (e.g. "make it better"), ask 1-2 clarifying questions before modifying.';
  }
  return 'The user wants a custom action.\n\nGROUNDING RULES:\n- Only respond based on the information provided. Mark any missing information as "INPUT_NEEDED: [what is missing]".\n- Do not invent facts, paths, or data.';
}

async function sendPanelChat(panelId) {
  const textarea = document.querySelector('.panel-chat-textarea[data-panel="' + panelId + '"]');
  if (!textarea) return;
  const text = textarea.value.trim();
  if (!text) return;

  const msgsContainer = document.getElementById('panel-chat-msgs-' + panelId);
  if (!msgsContainer) return;

  const userMsg = document.createElement('div');
  userMsg.className = 'panel-chat-msg user';
  userMsg.textContent = text;
  msgsContainer.appendChild(userMsg);

  textarea.value = '';
  textarea.style.height = 'auto';

  const thinkId = 'panel-chat-thinking-' + panelId;
  const thinkMsg = document.createElement('div');
  thinkMsg.className = 'panel-chat-msg assistant typing-indicator';
  thinkMsg.innerHTML = '<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>';
  thinkMsg.id = thinkId;
  msgsContainer.appendChild(thinkMsg);
  msgsContainer.scrollTop = msgsContainer.scrollHeight;

  try {
    const context = getPanelContext(panelId);
    const systemPrompt = 'You are Aetheris assistant. ' + context + '\n\nIMPORTANT: Answer concisely. If the user asks for code, provide it in markdown code blocks. If information is missing, use the XXX_INPUT_NEEDED markers described above — never fabricate.';

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, mode: 'discuss', system: systemPrompt })
    });
    const data = await res.json();

    const thinking = document.getElementById(thinkId);
    if (thinking) thinking.remove();

    const replyMsg = document.createElement('div');
    replyMsg.className = 'panel-chat-msg assistant';
    if (data.reply) {
      let html = data.reply
        .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
        .replace(/\n/g, '<br>');
      replyMsg.innerHTML = html;
    } else {
      replyMsg.textContent = data.error || 'No response from LLM. Is a provider configured?';
    }
    msgsContainer.appendChild(replyMsg);
    msgsContainer.scrollTop = msgsContainer.scrollHeight;
  } catch (e) {
    const thinking = document.getElementById(thinkId);
    if (thinking) thinking.remove();
    const errMsg = document.createElement('div');
    errMsg.className = 'panel-chat-msg assistant';
    errMsg.textContent = 'Error: ' + e.message;
    msgsContainer.appendChild(errMsg);
  }
}

// ---------- Agent Lab (Dashboard) : skills / pipeline / training loop / channels / wiki ----------
function initAgentLab() {
  const status = document.getElementById('lab-status');
  const say = (msg) => { if (status) status.textContent = msg; };

  // 6-Agent pipeline
  document.getElementById('lab-pipeline-btn')?.addEventListener('click', async () => {
    const goal = document.getElementById('lab-pipeline-goal').value.trim();
    if (!goal) { say('请先输入研究目标'); return; }
    say('正在运行 6-Agent 管道（Plan→Research→Code→Debug→Analyze→Write）…');
    try {
      const res = await fetch('/api/subagents/pipeline', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ goal }) });
      const data = await res.json();
      say('管道完成: ' + (data.error ? '错误 ' + data.error : JSON.stringify(data).substring(0, 200)));
    } catch (e) { say('管道失败: ' + e.message); }
  });

  // Training loop (karpathy)
  document.getElementById('lab-ar-btn')?.addEventListener('click', async () => {
    const goal = document.getElementById('lab-ar-goal').value.trim();
    if (!goal) { say('请先输入训练目标'); return; }
    say('正在启动训练循环…');
    try {
      const res = await fetch('/api/autoresearch/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ goal }) });
      const data = await res.json();
      say(data.error ? '训练循环错误: ' + data.error : '训练循环已启动: ' + JSON.stringify(data).substring(0, 200));
    } catch (e) { say('启动失败: ' + e.message); }
  });
  document.getElementById('lab-ar-status-btn')?.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/autoresearch/state');
      const data = await res.json();
      say('循环状态: ' + JSON.stringify(data).substring(0, 200));
    } catch (e) { say('查询失败: ' + e.message); }
  });

  // Skill matching (80 skills)
  document.getElementById('lab-skill-btn')?.addEventListener('click', async () => {
    const q = document.getElementById('lab-skill-query').value.trim();
    const el = document.getElementById('lab-skill-results');
    if (!q) { if (el) el.innerHTML = ''; return; }
    try {
      const res = await fetch('/api/skills/search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: q }) });
      const data = await res.json();
      const skills = data.skills || data.matches || [];
      if (el) el.innerHTML = skills.length
        ? skills.slice(0, 8).map(s => '<div>· /' + escapeHtml(s.action || s.id || '') + ' — ' + escapeHtml(s.title || s.name || '') + '</div>').join('')
        : '<div style="color:var(--text-tertiary)">无匹配技能</div>';
    } catch (e) { if (el) el.innerHTML = '查询失败: ' + escapeHtml(e.message); }
  });

  // Channels (7)
  document.getElementById('lab-channel-btn')?.addEventListener('click', async () => {
    const channel = document.getElementById('lab-channel-type').value;
    const msg = document.getElementById('lab-channel-msg').value.trim();
    if (!msg) { say('请先输入消息内容'); return; }
    say('正在通过 ' + channel + ' 发送…');
    try {
      const res = await fetch('/api/channels/send', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ channel, text: msg }) });
      const data = await res.json();
      say(data.ok ? '已发送 ✓' : '发送失败: ' + (data.error || JSON.stringify(data)));
    } catch (e) { say('发送失败: ' + e.message); }
  });

  // Sandbox exec (EvoScientist sandbox)
  document.getElementById('lab-sandbox-btn')?.addEventListener('click', async () => {
    const cmd = document.getElementById('lab-sandbox-cmd').value.trim();
    const out = document.getElementById('lab-sandbox-out');
    if (!cmd) { say('请输入命令'); return; }
    out.textContent = '运行中…';
    try {
      const res = await fetch('/api/sandbox/exec', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ command: cmd }) });
      const d = await res.json();
      out.textContent = (d.stdout || d.output || '') + (d.error ? '\n[错误] ' + d.error : '') || JSON.stringify(d).substring(0, 300);
    } catch (e) { out.textContent = '失败: ' + e.message; }
  });

  // Browser fetch
  document.getElementById('lab-browser-btn')?.addEventListener('click', async () => {
    const url = document.getElementById('lab-browser-url').value.trim();
    const out = document.getElementById('lab-browser-out');
    if (!url) { say('请输入 URL'); return; }
    out.textContent = '抓取中…';
    try {
      const res = await fetch('/api/browser/fetch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }) });
      const d = await res.json();
      out.textContent = (d.title ? '标题: ' + d.title + '\n' : '') + (d.text || d.content || '').substring(0, 400) + (d.error ? '\n[错误] ' + d.error : '');
    } catch (e) { out.textContent = '失败: ' + e.message; }
  });

  // MCP servers (list + add)
  const loadMCP = async () => {
    const el = document.getElementById('lab-mcp-list');
    if (!el) return;
    try {
      const res = await fetch('/api/mcp/servers');
      const d = await res.json();
      const list = d.servers || [];
      el.innerHTML = list.length
        ? list.slice(-8).map(s => '<div style="display:flex;align-items:center;gap:6px">· ' + escapeHtml(s.name || s.id || '') + '<button class="btn-ghost btn-sm" onclick="removeMCP(' + JSON.stringify(String(s.name || s.id || '')) + ')" title="删除">✕</button></div>').join('')
        : '<div style="color:var(--text-tertiary)">无 MCP 服务器</div>';
    } catch (_) {}
  };
  window.removeMCP = async (name) => {
    try {
      const res = await fetch('/api/mcp/servers/remove', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
      const d = await res.json();
      say(d.ok ? 'MCP 服务器已删除' : '删除失败: ' + (d.error || ''));
      loadMCP();
    } catch (e) { say('删除失败: ' + e.message); }
  };
  document.getElementById('lab-mcp-add-btn')?.addEventListener('click', async () => {
    const name = document.getElementById('lab-mcp-name').value.trim();
    const cmd = document.getElementById('lab-mcp-cmd').value.trim();
    if (!name || !cmd) { say('MCP 需要名称+命令'); return; }
    try {
      const res = await fetch('/api/mcp/servers/add', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, command: cmd }) });
      const d = await res.json();
      say(d.ok ? 'MCP 服务器已添加: ' + name : '添加失败: ' + (d.error || JSON.stringify(d)));
      loadMCP();
    } catch (e) { say('添加失败: ' + e.message); }
  });
  loadMCP();

  // Wiki
  document.getElementById('lab-wiki-btn')?.addEventListener('click', async () => {
    const title = document.getElementById('lab-wiki-title').value.trim();
    const content = document.getElementById('lab-wiki-content').value.trim();
    if (!title || !content) { say('维基需要标题+内容'); return; }
    try {
      await fetch('/api/wiki', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: title, title, content }) });
      say('维基条目已保存: ' + title);
      loadWikiList();
    } catch (e) { say('维基保存失败: ' + e.message); }
  });

  window.loadWikiList = async () => {
    const el = document.getElementById('lab-wiki-list');
    if (!el) return;
    try {
      const res = await fetch('/api/wiki');
      const data = await res.json();
      const entries = Object.values(data.entries || {});
      el.innerHTML = entries.length
        ? entries.slice(-6).reverse().map(e => '<div>· ' + escapeHtml(e.title || '') + '</div>').join('')
        : '<div style="color:var(--text-tertiary)">维基为空</div>';
    } catch (_) {}
  };
  loadWikiList();
}

// ---------- Chat mode toggle (Discuss ↔ Agent) ----------
function initChatModeToggle() {
  const wrap = document.getElementById('chat-mode-toggle');
  if (!wrap) return;
  window._chatAgentMode = 'discuss';
  window._discussionHistory = [];

  wrap.querySelectorAll('.cm-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.dataset.cmode;
      window._chatAgentMode = mode;
      wrap.querySelectorAll('.cm-btn').forEach(b => b.classList.toggle('active', b.dataset.cmode === mode));
      const exportWrap = document.getElementById('cm-export-wrap');
      const checkpointWrap = document.getElementById('cm-checkpoint-wrap');
      const hint = document.getElementById('cm-hint');
      if (exportWrap) exportWrap.style.display = mode === 'agent' ? 'inline-flex' : 'none';
      if (checkpointWrap) checkpointWrap.style.display = mode === 'agent' ? 'inline-flex' : 'none';
      if (hint) hint.textContent = mode === 'agent' ? '执行中 — 使用全部能力（技能/数据库/子智能体/训练循环/渠道）' : '商讨中 — 只讨论不执行';
      if (mode === 'agent' && window._discussionHistory && window._discussionHistory.length) {
        showToast('将携带最近 ' + Math.min(window._discussionHistory.length, 8) + ' 条商讨记录执行', 'info');
      }
    });
  });
}

// ---------- Chat attachments (external files → project rag-uploads) ----------
function initChatAttachments() {
  const btn = document.getElementById('chat-attach-btn');
  const fileInput = document.getElementById('chat-file-input');
  const list = document.getElementById('chat-attach-list');
  if (!btn || !fileInput || !list) return;
  window._attachments = []; // { name, size, path, status }

  btn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const files = Array.from(fileInput.files || []);
    fileInput.value = '';
    for (const f of files) {
      if (f.size > 10 * 1024 * 1024) { showToast('附件超过 10MB: ' + f.name, 'error'); continue; }
      renderAttachment({ name: f.name, size: f.size, status: 'uploading' });
      try {
        const dataUrl = await new Promise((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => resolve(r.result);
          r.onerror = () => reject(new Error('read failed'));
          r.readAsDataURL(f);
        });
        const res = await fetch('/api/rag/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: f.name, data: dataUrl })
        });
        const r = await res.json();
        if (r.ok === false) throw new Error(r.error || 'upload failed');
        const entry = { name: f.name, size: f.size, path: r.path || ('paper/rag-uploads/' + f.name), status: 'ok', chunks: r.chunks || 0 };
        window._attachments.push(entry);
        renderAttachment(entry);
        showToast('附件已上传: ' + f.name + (r.chunks ? '（' + r.chunks + ' 分块已索引）' : ''), 'success');
      } catch (e) {
        renderAttachment({ name: f.name, size: f.size, status: 'error' });
        showToast('附件上传失败: ' + e.message, 'error');
      }
    }
  });

  function renderAttachment(a) {
    // remove existing chip for same name
    list.querySelectorAll('.attach-chip[data-name="' + a.name + '"]').forEach(el => el.remove());
    const chip = document.createElement('div');
    chip.className = 'attach-chip' + (a.status === 'error' ? ' attach-chip-error' : '');
    chip.dataset.name = a.name;
    const icon = a.status === 'ok' ? '📎' : (a.status === 'uploading' ? '⏳' : '⚠️');
    const sub = a.status === 'ok' ? (a.chunks ? a.chunks + ' 分块' : '') : (a.status === 'uploading' ? '上传中…' : '失败');
    chip.innerHTML = '<span class="attach-chip-icon">' + icon + '</span><span class="attach-chip-name">' + escapeHtml(a.name) + '</span>' +
      (sub ? '<span class="attach-chip-sub">' + escapeHtml(sub) + '</span>' : '') +
      '<span class="attach-chip-x" title="移除">×</span>';
    chip.querySelector('.attach-chip-x').addEventListener('click', () => {
      chip.remove();
      window._attachments = window._attachments.filter(x => x.name !== a.name);
    });
    list.appendChild(chip);
  }
}

// ---------- Notes panel (right sidebar: user notes + agent-read toggle) ----------
window._notesEnabled = false;
function initNotesPanel() {
  const editor = document.getElementById('notes-editor');
  const toggleBtn = document.getElementById('notes-toggle-btn');
  const toggleText = document.getElementById('notes-toggle-text');
  const statusEl = document.getElementById('notes-status');
  if (!editor) return;

  const renderToggle = () => {
    toggleBtn.classList.toggle('on', _notesEnabled);
    toggleText.textContent = _notesEnabled ? '🔓 已授权 — 智能体可读取' : '🔒 未授权 — 智能体不可读';
  };

  // Load notes + permission state from backend (project-scoped).
  (async () => {
    try {
      const res = await fetch('/api/notes');
      const d = await res.json();
      _notesEnabled = !!d.enabled;
      editor.value = d.content || '';
      renderToggle();
    } catch (_) {}
  })();

  // Save (manual + autosave on blur).
  const saveNotes = async (silent) => {
    try {
      const res = await fetch('/api/notes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: editor.value }) });
      if (res.ok && statusEl) { statusEl.textContent = '已保存 ' + new Date().toLocaleTimeString(); if (silent) setTimeout(() => { statusEl.textContent = '自动保存'; }, 2000); }
    } catch (_) {}
  };
  document.getElementById('notes-save-btn')?.addEventListener('click', () => saveNotes(false));
  editor.addEventListener('blur', () => saveNotes(true));

  // Permission toggle: ONLY when ON does the agent read the notes.
  toggleBtn?.addEventListener('click', async () => {
    _notesEnabled = !_notesEnabled;
    renderToggle();
    try {
      await fetch('/api/notes/enabled', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: _notesEnabled }) });
      showToast(_notesEnabled ? '已授权智能体读取备注' : '已取消授权（备注草稿不会被智能体读取）', _notesEnabled ? 'success' : 'info');
    } catch (_) {}
  });
}

// ---------- Settings & Providers ----------
async function loadProviders() {
  try {
    const res = await fetch('/api/providers');
    const data = await res.json();
    const el = document.getElementById('settings-providers');
    if (!el) return;
    if (!data.providers || !data.providers.length) {
      el.innerHTML = '<p style="color:var(--color-text-muted);font-size:13px">No providers configured. Add one below.</p>';
    } else {
      el.innerHTML = data.providers.map(p =>
        `<div class="provider-item" data-id="${escapeHtml(p.id)}">
          <div class="provider-item-info">
            <span class="provider-item-name">${escapeHtml(p.name)}</span>
            <span class="provider-item-detail">${escapeHtml(p.type)}${p.baseUrl ? ' · ' + escapeHtml(p.baseUrl) : ''} · ${escapeHtml(p.model || '')} · Key: ${escapeHtml(p.apiKeyMasked || '****')}${p.active ? ' · <span style="color:var(--success)">● active</span>' : ''}</span>
          </div>
          <div class="provider-item-actions">
            <button class="btn-ghost btn-sm" onclick="editProvider('${escapeHtml(p.id)}')" data-i18n="settings.provider_edit">Edit</button>
            <button class="btn-ghost btn-sm" onclick="removeProvider('${escapeHtml(p.id)}')" data-i18n="settings.provider_remove">Remove</button>
          </div>
        </div>`
      ).join('');
    }
    // Also update dropdowns
    populateProviderDropdowns(data.providers || []);
  } catch (_) {}
}

// Track the provider currently being edited ('' = adding new).
let editingProviderId = '';

async function editProvider(id) {
  try {
    const res = await fetch('/api/providers');
    const data = await res.json();
    const p = (data.providers || []).find(x => x.id === id);
    if (!p) return;
    editingProviderId = id;
    document.getElementById('provider-add-name').value = p.name || '';
    document.getElementById('provider-add-type').value = p.type || 'openai-compatible';
    document.getElementById('provider-add-url').value = p.baseUrl || '';
    document.getElementById('provider-add-model').value = p.model || '';
    document.getElementById('provider-add-key').value = '';
    document.getElementById('provider-add-key').placeholder = p.apiKeyMasked ? '(保留 ' + p.apiKeyMasked + '，留空不修改)' : 'sk-...';
    const statusEl = document.getElementById('provider-add-status');
    statusEl.textContent = '编辑中: ' + p.name + ' — 保存后更新，Key 留空则保留原 Key';
    statusEl.className = 'provider-status info';
    document.getElementById('provider-add-btn').textContent = '保存修改';
    document.getElementById('provider-edit-cancel')?.style.setProperty('display', 'inline-block');
    document.getElementById('provider-add-form')?.scrollIntoView({ behavior: 'smooth' });
  } catch (_) {}
}

function cancelProviderEdit() {
  editingProviderId = '';
  document.getElementById('provider-add-name').value = '';
  document.getElementById('provider-add-url').value = '';
  document.getElementById('provider-add-model').value = '';
  document.getElementById('provider-add-key').value = '';
  document.getElementById('provider-add-key').placeholder = 'sk-...';
  document.getElementById('provider-add-btn').textContent = '添加';
  document.getElementById('provider-edit-cancel')?.style.setProperty('display', 'none');
  const statusEl = document.getElementById('provider-add-status');
  if (statusEl) { statusEl.textContent = ''; statusEl.className = ''; }
}

async function addProvider() {
  const name = document.getElementById('provider-add-name').value.trim();
  const type = document.getElementById('provider-add-type').value;
  const url = document.getElementById('provider-add-url').value.trim();
  const model = document.getElementById('provider-add-model').value.trim();
  const key = document.getElementById('provider-add-key').value.trim();
  const statusEl = document.getElementById('provider-add-status');

  if (!name) {
    statusEl.textContent = 'Name is required.';
    statusEl.className = 'provider-status error';
    return;
  }
  if (!model) {
    statusEl.textContent = 'Model name is required (e.g. deepseek-chat / gpt-4o).';
    statusEl.className = 'provider-status error';
    return;
  }
  // Key is required when ADDING a new provider; optional when EDITING (blank = keep old).
  if (!editingProviderId && !key) {
    statusEl.textContent = 'API key is required for a new provider.';
    statusEl.className = 'provider-status error';
    return;
  }

  try {
    const payload = { name, type, model, baseUrl: url || undefined };
    if (editingProviderId) payload.id = editingProviderId;
    if (key) payload.apiKey = key;
    const res = await fetch('/api/provider', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok || res.ok) {
      statusEl.textContent = editingProviderId ? 'Provider updated.' : 'Provider added.';
      statusEl.className = 'provider-status success';
      cancelProviderEdit();
      loadProviders();
      showToast(editingProviderId ? 'Provider updated successfully' : 'Provider added successfully', 'success');
    } else {
      statusEl.textContent = 'Error: ' + (data.error || 'Failed');
      statusEl.className = 'provider-status error';
      showToast('Failed: ' + (data.error || 'Unknown error'), 'error');
    }
  } catch (e) {
    statusEl.textContent = 'Error: ' + e.message;
    statusEl.className = 'provider-status error';
    showToast('Error: ' + e.message, 'error');
  }
}

async function removeProvider(ref) {
  if (!confirm('Remove this provider?')) return;
  try {
    const res = await fetch('/api/provider/' + encodeURIComponent(ref), { method: 'DELETE' });
    const data = await res.json();
    if (data.ok || res.ok) {
      if (editingProviderId === ref) cancelProviderEdit();
      loadProviders();
      showToast('Provider removed', 'success');
    } else {
      showToast('Failed to remove provider', 'error');
    }
  } catch (_) {
    showToast('Failed to remove provider', 'error');
  }
}

function populateProviderDropdowns(providers) {
  const selects = ['chat-provider', 'paper-provider'];
  selects.forEach(sid => {
    const sel = document.getElementById(sid);
    if (!sel) return;
    const current = sel.value;
    sel.innerHTML = '<option value="">mock (default)</option>';
    providers.forEach(p => {
      sel.innerHTML += `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)} (${escapeHtml(p.type)})</option>`;
    });
    // Restore selection if still valid
    if ([...sel.options].some(o => o.value === current)) sel.value = current;
    else if (providers.length && !current) {
      // Default to the first configured real provider (with an API key) so the
      // user gets true generation instead of the mock fallback.
      const withKey = providers.find(p => p.apiKey);
      sel.value = (withKey || providers[0]).name;
    }
  });
}

// ---------- Harness ----------
function setupHarnessToggle() {
  const toggle = document.getElementById('agent-harness-toggle');
  const fields = document.getElementById('agent-harness-fields');
  if (toggle && fields) {
    toggle.addEventListener('change', () => {
      fields.style.display = toggle.checked ? 'block' : 'none';
    });
  }
}

// ---------- Preview Panel ----------
function closePreview() {
  document.querySelector('.app-layout').classList.remove('preview-open');
}

// ---------- Multi-tab Preview (auto-opening) ----------
// Replaces the old single-content openPreview with a tabbed system so agent
// output (plots, generated files) accumulates in switchable tabs and the
// preview panel auto-opens when something is produced.
const previewState = { tabs: [], activeId: null, seq: 0 };

function addPreviewTab(title, content, type) {
  const previewContent = document.getElementById('preview-content');
  if (!previewContent) return;

  const id = 'pt-' + (++previewState.seq);
  const existing = previewState.tabs.find(t => t.title === title);
  if (existing) {
    existing.content = content;
    existing.type = type;
    previewState.activeId = existing.id;
  } else {
    previewState.tabs.push({ id, title, content, type });
    previewState.activeId = id;
  }
  renderPreviewTabs();
  document.querySelector('.app-layout').classList.add('preview-open');
  if (!MOTION.reduce) {
    const bar = previewContent.querySelector('.preview-tabs');
    const activeTab = bar && bar.querySelector('.preview-tab.active');
    if (activeTab) gsap.from(activeTab, { y: -6, autoAlpha: 0, scale: 0.94, duration: 0.3, ease: 'back.out(1.6)' });
    const body = previewContent.querySelector('.preview-body');
    if (body) gsap.from(body, { autoAlpha: 0, y: 10, duration: 0.35, ease: 'power2.out' });
  }
}

// Backwards-compatible wrapper: generic untitled tab.
function openPreview(content, type) {
  addPreviewTab('Preview', content, type);
}

function renderPreviewTabs() {
  const previewContent = document.getElementById('preview-content');
  if (!previewContent) return;

  // Build tab bar (preserve empty-state element if no tabs)
  let bar = previewContent.querySelector('.preview-tabs');
  if (!bar) {
    bar = document.createElement('div');
    bar.className = 'preview-tabs';
    previewContent.insertBefore(bar, previewContent.firstChild);
  }
  bar.innerHTML = '';

  if (previewState.tabs.length === 0) {
    bar.style.display = 'none';
    previewContent.innerHTML = '<div class="preview-empty"><p>Select a file or result to preview</p></div>';
    return;
  }
  bar.style.display = 'flex';

  previewState.tabs.forEach(tab => {
    const el = document.createElement('div');
    el.className = 'preview-tab' + (tab.id === previewState.activeId ? ' active' : '');
    el.innerHTML = `<span class="preview-tab-title">${escapeHtml(tab.title)}</span><span class="pt-close" title="关闭">×</span>`;
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('pt-close')) {
        closePreviewTab(tab.id);
      } else {
        previewState.activeId = tab.id;
        renderPreviewTabs();
      }
    });
    bar.appendChild(el);
  });

  // Render body
  const active = previewState.tabs.find(t => t.id === previewState.activeId);
  let body = previewContent.querySelector('.preview-body');
  if (!body) {
    body = document.createElement('div');
    body.className = 'preview-body';
    previewContent.appendChild(body);
  }
  if (!active) { body.innerHTML = ''; return; }
  if (active.type === 'html') body.innerHTML = active.content;
  else if (active.type === 'image') body.innerHTML = `<img src="${active.content}" style="max-width:100%;height:auto" alt="${escapeHtml(active.title)}">`;
  else body.innerHTML = `<pre class="preview-file">${escapeHtml(active.content)}</pre>`;
}

function closePreviewTab(id) {
  previewState.tabs = previewState.tabs.filter(t => t.id !== id);
  if (previewState.activeId === id) {
    previewState.activeId = previewState.tabs.length ? previewState.tabs[previewState.tabs.length - 1].id : null;
  }
  if (previewState.tabs.length === 0) {
    const previewContent = document.getElementById('preview-content');
    if (previewContent) previewContent.innerHTML = '<div class="preview-empty"><p>Select a file or result to preview</p></div>';
    closePreview();
  } else {
    renderPreviewTabs();
  }
}

// ---------- Sidebar collapse / reopen ----------
function toggleSidebar() {
  const layout = document.querySelector('.app-layout');
  const reopen = document.getElementById('sidebar-reopen-btn');
  if (!layout) return;
  const collapsed = layout.classList.toggle('sidebar-collapsed');
  if (reopen) reopen.style.display = collapsed ? 'flex' : 'none';
  // On narrow screens treat it as an overlay drawer instead.
  if (window.innerWidth <= 900) {
    layout.classList.toggle('sidebar-open', !collapsed);
  }
}


// ---------- Utilities ----------
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Start SSE connection on load
setTimeout(connectSSE, 500);
