# /paper-poster
> Action: paper-poster
> Category: Paper Writing
> Triggers: "poster (redirect)"

## Overview
Redirect to /paper-poster-html. Use the HTML version.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-poster/SKILL.md` by the Aetheris skill loader.
