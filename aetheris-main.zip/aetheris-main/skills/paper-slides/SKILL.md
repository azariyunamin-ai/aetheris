# /paper-slides
> Action: paper-slides
> Category: Paper Writing
> Triggers: "make slides,presentation"

## Overview
Generate conference presentation slides (Beamer PDF + PPTX + speaker notes).

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-slides/SKILL.md` by the Aetheris skill loader.
