# /statistical-analysis
> Action: statistical-analysis
> Category: ML Data
> Triggers: "statistics,significance test"

## Overview
Statistical analysis framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/statistical-analysis/SKILL.md` by the Aetheris skill loader.
