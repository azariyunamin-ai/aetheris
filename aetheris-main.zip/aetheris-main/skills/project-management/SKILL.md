# /project-management
> Action: project-management
> Category: PM
> Triggers: "project plan,task breakdown"

## Overview
Research project management.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/project-management/SKILL.md` by the Aetheris skill loader.
