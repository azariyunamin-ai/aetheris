/**
 * Aetheris Desktop — Electron wrapper
 * Starts the Aetheris HTTP server then opens it in a native window.
 * Windows / macOS / Linux supported.
 */

const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');

let mainWindow = null;
let serverProcess = null;
const SERVER_PORT = 0; // random free port

function startServer() {
  return new Promise((resolve, reject) => {
    const serverJs = path.join(__dirname, '..', 'bin', 'cli.js');
    const proc = spawn(process.execPath, [serverJs, 'ui'], {
      cwd: path.join(__dirname, '..', '..', 'test-project-1'),
      env: { ...process.env, VIBEBASE_NO_OPEN: '1', ELECTRON: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let started = false;
    const timeout = setTimeout(() => {
      if (!started) reject(new Error('Server startup timed out'));
    }, 15000);

    proc.stdout.on('data', (data) => {
      const output = data.toString();
      // Parse the port from: "Aetheris Control Panel running at http://127.0.0.1:XXXXX"
      const match = output.match(/running at http:\/\/127\.0\.0\.1:(\d+)/);
      if (match && !started) {
        started = true;
        clearTimeout(timeout);
        serverProcess = proc;
        resolve(parseInt(match[1]));
      }
    });

    proc.stderr.on('data', (data) => {
      console.error('[Aetheris]', data.toString().trim());
    });

    proc.on('error', reject);
    proc.on('exit', (code) => {
      if (!started) {
        clearTimeout(timeout);
        reject(new Error(`Server exited with code ${code}`));
      }
    });
  });
}

function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    title: 'Aetheris 灵思',
    backgroundColor: '#010102',
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  mainWindow.loadURL(`http://127.0.0.1:${port}`);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Open external links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // macOS: app menu
  if (process.platform === 'darwin') {
    const template = [
      {
        label: 'Aetheris',
        submenu: [
          { role: 'about' },
          { type: 'separator' },
          { role: 'quit' },
        ],
      },
      {
        label: 'Edit',
        submenu: [
          { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
          { role: 'cut' }, { role: 'copy' }, { role: 'paste' },
        ],
      },
      {
        label: 'View',
        submenu: [
          { role: 'reload' }, { role: 'toggleDevTools' },
          { type: 'separator' },
          { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' },
        ],
      },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
  } else {
    // Windows/Linux: no menu bar (cleaner)
    Menu.setApplicationMenu(null);
  }
}

app.whenReady().then(async () => {
  try {
    const port = await startServer();
    createWindow(port);
  } catch (err) {
    console.error('Failed to start Aetheris:', err.message);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    app.relaunch();
    app.exit();
  }
});
