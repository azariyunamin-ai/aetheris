# /code-review
> Action: code-review
> Category: Code
> Triggers: "code review,review PR"

## Overview
Comprehensive code review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/code-review/SKILL.md` by the Aetheris skill loader.
