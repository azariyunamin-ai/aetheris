# /paper-writing — Paper Writing with Completeness Gate
> Action: paper-writing
> Category: Paper Writing
> Position: Experiment results → Draft paper
> Triggers: "draft paper", "write manuscript", "compile results"

## Sections (in order)
1. **Abstract** — 150-250 words, no citations
2. **Introduction** — problem → gap → contribution → structure
3. **Related Work** — organized by theme, not laundry list
4. **Method** — reproducible detail
5. **Experimental Setup** — datasets, baselines, hyperparameters, hardware
6. **Results** — data-driven, no interpretation
7. **Discussion** — interpret, acknowledge limitations
8. **Conclusion** — summary + future work
9. **References** — BibTeX, no fabricated entries

## Completeness Gates
- Every claim in Introduction has a citation OR empirical result
- Every number in Results comes from an experiment log
- Every reference exists (arXiv/DOI verified)
- Abstract contains: problem, method, key result, implication
- No "we believe" without evidence — "we show" only for verified claims

## Anti-Patterns (DO NOT)
- Fabricate citations
- Report results without running experiments
- Claim superiority without statistical significance test
- Generalize from single run / single dataset
