'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');

const uiHtml = fs.readFileSync(path.join(__dirname, '..', 'ui', 'index.html'), 'utf8');
const appJs = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app.js'), 'utf8');

test('paper-journal select offers a Chinese (CSSCI) option', () => {
  assert.ok(/<select[^>]*id="paper-journal"/.test(uiHtml), 'paper-journal select missing');
  assert.ok(/<option value="CSSCI">/.test(uiHtml), 'CSSCI option missing');
  // English journals still present.
  assert.ok(/<option value="Nature">/.test(uiHtml));
});

test('paper form has an explicit language selector', () => {
  assert.ok(/<select[^>]*id="paper-language"/.test(uiHtml), 'paper-language select missing');
  assert.ok(/<option value="en">/.test(uiHtml));
  assert.ok(/<option value="zh">/.test(uiHtml));
});

test('language label exists in UI (form-label)', () => {
  assert.ok(/form-label/.test(uiHtml), 'form labels present');
});

test('run payload sends journal/language via runPaperAgent', () => {
  // runPaperAgent reads document.getElementById directly and passes journal/language
  assert.ok(/journal\s*=\s*document\.getElementById\('paper-journal'\)/.test(appJs), 'journal read in run payload');
  assert.ok(/language\s*=\s*document\.getElementById\('paper-language'\)/.test(appJs), 'language read in run payload');
  assert.ok(/\/api\/agent\/run/.test(appJs), 'agent run API called');
});

test('journal change auto-syncs language (CSSCI -> zh, English -> en)', () => {
  assert.ok(/===\s*'CSSCI'/.test(appJs), 'CSSCI->zh sync rule missing');
  assert.ok(/langSel\.value\s*=\s*'zh'/.test(appJs), 'zh assignment missing');
  assert.ok(/langSel\.value\s*=\s*'en'/.test(appJs), 'en assignment missing');
});

test('quick actions route to correct panel and intent', () => {
  assert.ok(/switchPanel\('paper'\)/.test(appJs), 'quick paper action missing');
  assert.ok(/'autonomous_research'/.test(appJs), 'autonomous_research intent selectable');
  assert.ok(/'empirical_analysis'/.test(appJs), 'empirical_analysis intent selectable');
});
