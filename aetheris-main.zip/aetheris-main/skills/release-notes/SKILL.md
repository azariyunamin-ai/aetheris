# /release-notes
> Action: release-notes
> Category: Docs
> Triggers: "release notes,version"

## Overview
Release notes writer.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/release-notes/SKILL.md` by the Aetheris skill loader.
