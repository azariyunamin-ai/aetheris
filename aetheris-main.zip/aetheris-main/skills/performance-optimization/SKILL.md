# /performance-optimization
> Action: performance-optimization
> Category: Performance
> Triggers: "performance,optimize,profile"

## Overview
Performance profiling and optimization.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/performance-optimization/SKILL.md` by the Aetheris skill loader.
