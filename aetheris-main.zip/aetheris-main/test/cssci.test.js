'use strict';

// Tests for the built-in Chinese CSSCI empirical-paper template.
// Run with: node --test
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { academicTools } = require('../bin/lib/tools-academic');
const llm = require('../bin/lib/llm');

function tmpRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'aetheris-cssci-'));
}

// ---- writeOutline: empirical_cn / zh yields the Chinese CSSCI skeleton ----
test('writeOutline empirical_cn produces the CSSCI Chinese section list', () => {
  const root = tmpRoot();
  const r = academicTools.writeOutline(root, { paperType: 'empirical_cn', journal: 'CSSCI', language: 'zh' });
  assert.strictEqual(r.ok, true);
  const outline = fs.readFileSync(r.wrote, 'utf8');
  for (const s of ['摘要', '引言', '文献综述', '模型构建', '结果分析', '稳健性分析', '异质性分析', '敏感度分析', '结论', '参考文献']) {
    assert.ok(outline.includes(s), 'outline should contain section: ' + s);
  }
  assert.ok(outline.includes('empirical_cn'), 'outline header should record empirical_cn');
});

test('writeOutline falls back to empirical_cn when journal=CSSCI (no paperType)', () => {
  const root = tmpRoot();
  const r = academicTools.writeOutline(root, { journal: 'CSSCI', language: 'zh' });
  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.sections[0], '摘要');
  assert.strictEqual(r.sections.length, 10);
});

// ---- Chinese section filenames (CJK must be preserved, not stripped) ----
test('writeSection/readSection round-trips Chinese section names', () => {
  const root = tmpRoot();
  const names = ['引言', '文献综述', '模型构建（理论分析与研究假说）', '结果分析（仿真分析/回归分析）', '稳健性分析', '异质性分析', '敏感度分析', '结论（含政策建议）'];
  for (const n of names) {
    const w = academicTools.writeSection(root, { section: n, content: '# ' + n + '\n测试内容' });
    assert.strictEqual(w.ok, true, 'writeSection failed for: ' + n);
    // Filename must keep CJK characters (not collapse to "_" / ".md").
    const base = path.basename(w.wrote, '.md');
    assert.ok(/[一-鿿]/.test(base), 'filename should retain Chinese for: ' + n);
    const rd = academicTools.readSection(root, { section: n });
    assert.strictEqual(rd.ok, true);
    assert.ok(rd.content.includes('测试内容'));
  }
  const ls = academicTools.listSections(root);
  assert.strictEqual(ls.sections.length, names.length);
  assert.ok(ls.sections.includes('引言'));
});

// ---- genDataStatement: language=zh yields a Chinese data note ----
test('genDataStatement language=zh produces a Chinese data-source note', () => {
  const root = tmpRoot();
  const r = academicTools.genDataStatement(root, { journal: 'CSSCI', language: 'zh', datasets: [{ name: '上市公司数据', source: 'CSMAR' }] });
  assert.strictEqual(r.ok, true);
  assert.ok(r.content.includes('数据来源与样本说明'), 'should use Chinese data note title');
  assert.ok(r.content.includes('CSMAR'), 'dataset source should appear');
});

test('genDataStatement default (en) still produces Nature DAS', () => {
  const root = tmpRoot();
  const r = academicTools.genDataStatement(root, { journal: 'Nature' });
  assert.strictEqual(r.ok, true);
  assert.ok(r.content.includes('Data Availability Statement'));
});

// ---- Mock planner: CSSCI / zh produces a Chinese empirical task tree ----
test('mockPlan emits a Chinese CSSCI tree for journal=CSSCI', async () => {
  const { parsed } = await llm.plan(
    { system: '', messages: [{ role: 'user', content: 'Goal: 数字金融对碳排放的影响' }], domain: 'academic', goal: '数字金融对碳排放的影响', intent: 'new_paper', journal: 'CSSCI', language: 'zh' },
    'mock',
    { onToken: () => {} }
  );
  assert.ok(Array.isArray(parsed.plan));
  const titles = parsed.plan.map(n => n.title).join(' ');
  assert.ok(titles.includes('引言') || titles.includes('大纲'), 'plan should include Chinese sections');
  const outlineNode = parsed.plan.find(n => n.tool === 'writeOutline');
  assert.ok(outlineNode, 'plan should include a writeOutline node');
  assert.strictEqual(outlineNode.args.paperType, 'empirical_cn');
  assert.strictEqual(outlineNode.args.language, 'zh');
  // polish node must be Chinese
  const polishNode = parsed.plan.find(n => n.tool === 'polishSection');
  assert.strictEqual(polishNode.args.language, 'zh');
});
