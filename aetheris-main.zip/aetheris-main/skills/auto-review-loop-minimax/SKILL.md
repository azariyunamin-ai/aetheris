# /auto-review-loop-minimax
> Action: auto-review-loop-minimax
> Category: Review Audit
> Triggers: "MiniMax review"

## Overview
Auto review loop using MiniMax backend.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/auto-review-loop-minimax/SKILL.md` by the Aetheris skill loader.
