# /slides-polish
> Action: slides-polish
> Category: Paper Writing
> Triggers: "polish slides,improve presentation"

## Overview
Page-by-page layout review for presentation slides.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/slides-polish/SKILL.md` by the Aetheris skill loader.
