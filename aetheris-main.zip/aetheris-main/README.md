<div align="center">
  <h1>🌊 Aetheris 灵思 Agent</h1>
  <p><strong>全功能的学术研究智能体 —— 从商讨方案到发表级论文的一站式科研助手</strong></p>
  <p>基于 91 个通用技能 + 10 个 Nature 学术技能 + 60 个科学数据库 + 6 个子智能体 + 训练循环 + 7 个消息渠道</p>

  <p>
    <a href="https://github.com/shiqiaoshangxue/aetheris/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square" alt="License"></a>
    <img src="https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg?style=flat-square" alt="Platform">
    <img src="https://img.shields.io/badge/Vibe-Coding-purple.svg?style=flat-square" alt="Vibe Coding">
    <img src="https://img.shields.io/badge/LLM-DeepSeek%20%7C%20OpenAI%20%7C%20Claude-orange.svg?style=flat-square" alt="LLM">
  </p>
</div>

<h3>🏆 Web 控制面板 · 多场景</h3>

<table>
  <tr>
    <td align="center" valign="top" width="33%">
      <img src="https://raw.githubusercontent.com/shiqiaoshangxue/aetheris/main/.github/assets/chat.png" width="100%" alt="Chat"/>
      <br />
      <sub><b>💬 Chat</b><br>商讨/执行双模式 · 论文管线</sub>
    </td>
    <td align="center" valign="top" width="33%">
      <img src="https://raw.githubusercontent.com/shiqiaoshangxue/aetheris/main/.github/assets/data.png" width="100%" alt="Data"/>
      <br />
      <sub><b>📊 Data</b><br>数据分析 · 可视化</sub>
    </td>
    <td align="center" valign="top" width="34%">
      <img src="https://raw.githubusercontent.com/shiqiaoshangxue/aetheris/main/.github/assets/paper.png" width="100%" alt="Paper Agent"/>
      <br />
      <sub><b>📄 Paper Agent</b><br>论文生成/导出/审稿</sub>
    </td>
  </tr>
</table>

<h3>⚡ 实机操作演示</h3>

<table>
  <tr>
    <td align="center">
      <img src="https://raw.githubusercontent.com/shiqiaoshangxue/aetheris/main/.github/assets/demo.gif" width="100%" alt="Aetheris demo"/>
      <br />
      <sub><b>实机操作演示</b> · <a href="https://github.com/shiqiaoshangxue/aetheris/releases/download/v4.0.0/demo.mp4">下载高清视频 (mp4)</a></sub>
    </td>
  </tr>
</table>

---

## 🧭 什么是 Aetheris 灵思？

**Aetheris（灵思）** 是一个专注于**学术研究全流程**的智能体系统。它把研究者的工作流（选题 → 检索 → 讨论 → 写作 → 图表 → 引用 → 自查 → 润色）转化为可对话、可执行、可交付的智能体能力：

- **💬 商讨方案模式**：像学术顾问一样与你讨论、细化方向、主动提问，只读检索证据，绝不擅自执行
- **🤖 执行方案模式**：按功能输出真实产物（文献综述、数据分析报告、完整论文草稿……），实时推送到对话区与产物抽屉

## ✨ 核心能力

| 能力 | 说明 |
|---|---|
| **9 种研究工作流** | 完整论文 / 想法发现 / 论文写作 / 实验运行 / 文献综述 / 代码生成 / 数据分析 / 审稿回复 / 自主研究 |
| **101 个技能** | 91 个通用技能 + 10 个 Nature 学术技能（写作/检索/引用/图表/数据/润色/审稿/回复） |
| **60 个科学数据库** | 生物医学（PubMed/UniProt/PDB…）+ 综合学术（arXiv/Crossref/OpenAlex）+ 社科经济（SSRN/RePEc/NBER/JSTOR）真实 API 检索 |
| **论文管线方法论** | 写论文时自动加载 nature-writing 等 9 个技能的方法论，指导发表级创作 |
| **6 个子智能体** | plan / research / code / debug / analyze / write 专业分工 |
| **4 循环训练功能** | 自主研究（researchSetup → Train → Status → Decide 迭代） |
| **7 个消息渠道** | Telegram / 企业微信 / Slack / Discord / 飞书 / QQ / Email |
| **产物系统** | 执行产物实时卡片 + 📦 产物抽屉 + 对话框直接输出可复制成果 |
| **分段执行** | 每阶段完成后暂停，可继续 / 修改 / 跳过；90 秒无操作自动继续 |
| **模式范围约束** | 每个模式只讨论/输出该模式相关内容 |

## 🚀 快速开始

### 前置要求

- **Node.js ≥ 18**
- （可选）一个 LLM API Key（DeepSeek / OpenAI / Claude），不配置则使用 mock 演示模式

### 安装与运行

```bash
# 1. 克隆仓库
git clone https://github.com/agonxl/aetheris.git
cd aetheris/source

# 2. 安装依赖
npm install

# 3. 启动 Web 控制面板
npm run dev
# 或：node bin/cli.js ui
```

浏览器打开 `http://127.0.0.1:xxxxx`（终端会显示实际端口）。

### 桌面应用（可选）

```bash
npm run dist:win    # Windows 安装包（NSIS）
npm run dist:mac    # macOS
npm run dist:all    # 全平台
```

## ⚙️ 配置真实模型

> 不配置时使用 **mock 演示模式**（提供结构化草稿与真实文献检索，但非深度创作）。要获得发表级论文，请配置真实模型。

1. 打开 Web 面板 → **⚙️ 设置** → **Provider**
2. 添加 Provider：
   - **Provider**: `deepseek`（或 openai / claude）
   - **API Key**: 你的 Key（DeepSeek: platform.deepseek.com）
   - **Base URL**: `https://api.deepseek.com`（DeepSeek 示例）
3. 回到对话区，Provider 下拉会自动默认选中已配置的模型

## 📖 使用指南

### 商讨 → 执行 双模式

```
1. 选择工作流（如"文献综述"）
2. 💬 商讨方案：与 agent 讨论主题范围、检索策略、综述结构（agent 会主动提问细化）
3. 满意后点 🤖 执行方案（自动携带商讨记录）
4. ☑ 勾选"输出结果文件"或"分段执行"
5. 发送 → agent 按论文管线技能执行
6. 📋 执行成果区显示完整产物（可直接复制）+ 📦 产物抽屉查看文件
```

### 9 种工作流

| 工作流 | 执行产物 |
|---|---|
| 完整流程 | 完整论文草稿（摘要/引言/文献综述/方法/结果/讨论/结论） |
| 想法发现 | 研究现状 + 缺口 + 3-5 个研究方向建议 |
| 论文写作 | 完整论文（按 nature-writing 方法论逐章创作） |
| 实验运行 | 实验脚本 + 运行结果 + 分析报告 |
| 文献综述 | 基于真实检索文献的综述正文（正文引用具体文献） |
| 代码生成 | 可运行代码 + 测试 + 使用说明 |
| 数据分析 | 数据概览 + 分析结果 + 可视化 + 报告 |
| 审稿回复 | 意见解析 + 逐条回复策略 + 回复信 |
| 自主研究 | 训练循环 + 最佳配置 + 研究小结 |

## 🏗️ 架构

```
source/
├── bin/
│   ├── cli.js                  # CLI 入口（ui / init / paper / plot …）
│   └── lib/
│       ├── server.js           # Web 服务器 + 69 个 API 端点 + 模式编排
│       ├── agent.js            # Agent 核心（planner + ReAct 循环 + 检查点）
│       ├── llm.js              # LLM 路由（mock/DeepSeek/OpenAI/Claude）
│       ├── skill-loader.js     # 技能加载/匹配/方法论注入
│       ├── tools-academic.js   # 学术工具（litSearch/writeSection/…）
│       ├── science-fetch.js    # 60 科学数据库检索
│       ├── channels.js         # 7 消息渠道 + 沙箱
│       ├── subagents.js        # 6 子智能体
│       ├── autoresearch.js     # 训练循环
│       ├── harness.js          # 规格约束/验证/追踪
│       └── …
├── ui/                         # 前端（Web 控制面板，Linear 风格）
├── skills/                     # 91 个通用技能
├── skills-academic/            # 10 个 Nature 学术技能
├── electron/                   # 桌面应用壳
└── test/                       # 单元测试
```

## 🧪 测试

```bash
npm test
```

## 🤝 参与贡献

欢迎通过 [Issue](https://github.com/agonxl/aetheris/issues) 与 [Pull Request](https://github.com/agonxl/aetheris/pulls) 参与贡献。请阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 与 [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)。

## 📄 License

[MIT](LICENSE)
