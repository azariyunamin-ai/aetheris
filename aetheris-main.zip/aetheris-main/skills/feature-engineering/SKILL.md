# /feature-engineering
> Action: feature-engineering
> Category: ML Data
> Triggers: "feature engineering,feature selection"

## Overview
Feature engineering and selection.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/feature-engineering/SKILL.md` by the Aetheris skill loader.
