# Skills Catalog — Academic Domain

This is the browsable catalog of all academic skills available to the Aetheris
Paper and Research agents. Skills follow the [TEMPLATE.md](TEMPLATE.md) standard.

## How to use this catalog

- **Browse by category** below to find the right skill for your task.
- **Each skill** links to its `SKILL.md` router file, which detects your request
  axes (paper_type, section, language, journal) and loads only the needed fragments.
- **The planner** (DAG engine in `agent.js`) can chain multiple skills into an
  end-to-end workflow — you don't need to manually orchestrate them.

---

## Category: Writing & Composition

Skills that produce manuscript text.

| Skill | Type | Best for | Version |
|---|---|---|---|
| [nature-writing](nature-writing/SKILL.md) | component | Drafting manuscript sections from author notes, building IMRaD skeletons, planning paper structure | 1.0.0 |
| [nature-polishing](nature-polishing/SKILL.md) | component | Pre-submission language editing, converting Chinese drafts to publication English, LaTeX layout fixes | 6.1.0 |

## Category: Review & Quality Assurance

Skills that evaluate, critique, and improve manuscript quality.

| Skill | Type | Best for | Version |
|---|---|---|---|
| [nature-reviewer](nature-reviewer/SKILL.md) | component | Pre-submission mock peer review, identifying blind spots, getting 3 independent reviewer perspectives | 0.1.0 |
| [nature-response](nature-response/SKILL.md) | component | Drafting point-by-point reviewer response letters for major/minor revisions | 1.0.0 |

## Category: Literature & Reading

Skills for finding, reading, and understanding academic papers.

| Skill | Type | Best for | Version |
|---|---|---|---|
| [nature-academic-search](nature-academic-search/SKILL.md) | component | Multi-source literature search (arXiv, Crossref, PubMed), MeSH strategy, citation verification | 2.0.0 |
| [nature-reader](nature-reader/SKILL.md) | component | Building bilingual (CN/EN) paper readers from PDF, DOI, or pasted text — figure-aware and source-grounded | 2.0.0 |

## Category: References & Data

Skills for managing citations, data statements, and research data.

| Skill | Type | Best for | Version |
|---|---|---|---|
| [nature-citation](nature-citation/SKILL.md) | component | Auto-generating CNS-tier citations from manuscript text, BibTeX management | 2.0.0 |
| [nature-data](nature-data/SKILL.md) | component | Preparing Nature-ready Data Availability Statements, data repository planning, audit | 2.0.0 |

## Category: Figures & Presentation

Skills for creating publication-quality figures and presentation slides.

| Skill | Type | Best for | Version |
|---|---|---|---|
| [nature-figure](nature-figure/SKILL.md) | component | Creating/auditing submission-grade figures (Python/R), applying journal-specific design rules | 2.0.0 |
| [scipilot-figure-skill](scipilot-figure-skill/SKILL.md) | component | SciPilot visualization-advisor: profile data → recommend chart → generate matplotlib script | 2.0.0 |
| [nature-paper2ppt](nature-paper2ppt/SKILL.md) | component | Building Nature/CSSCI-style PPTX slides from papers, preprints, or abstracts | 2.0.0 |

## Category: Shared Resources

Cross-cutting fragments used by multiple skills.

| Resource | Description |
|---|---|
| [_shared/core/ethics.md](_shared/core/ethics.md) | Authorship, data integrity, conflict of interest, plagiarism principles |
| [_shared/core/paper-type-taxonomy.md](_shared/core/paper-type-taxonomy.md) | 5 paper types (Research Article, Review, Brief Communication, Methods, CSSCI Empirical) with structure/goal/signals |
| [_shared/core/reader-workflow.md](_shared/core/reader-workflow.md) | 5-step reader question sequence (claim → measurement → evidence → boundaries → advancement) |
| [_shared/core/terminology-ledger.md](_shared/core/terminology-ledger.md) | Cross-skill terminology tracking format and rules |
| [_shared/journal-formats/cssci.md](_shared/journal-formats/cssci.md) | CSSCI Chinese empirical paper format requirements |
| [_shared/journal-formats/nat-comms.md](_shared/journal-formats/nat-comms.md) | Nature Communications format requirements |

---

## Skill quality status

Skills are tracked against the [TEMPLATE.md](TEMPLATE.md) standard. Each column
represents a required section.

| Skill | Purpose | Input | Key Concepts | Application | Pitfalls | Examples | References |
|---|---|---|---|---|---|---|---|
| nature-reviewer | DONE | DONE | DONE | DONE | DONE (Red lines) | DONE | DONE |
| nature-writing | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-polishing | DONE | MISSING | DONE | DONE | PARTIAL | MISSING | PARTIAL |
| nature-reader | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-response | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-figure | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-data | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-citation | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-academic-search | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| nature-paper2ppt | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |
| scipilot-figure-skill | DONE | MISSING | DONE | DONE | MISSING | MISSING | PARTIAL |

**Target:** All skills reach nature-reviewer completeness level by next iteration.
Priority: nature-writing and nature-polishing first (highest usage).

---

## How skills connect to the agent

Skills are loaded by two mechanisms:

1. **Tool layer** (`tools-academic.js`): Each skill has a corresponding tool
   function (e.g. `polishSection`, `reviewDraft`) that the ReAct agent calls.
   Tool return values now include a `reasoning` field explaining the "why"
   behind each step (ABC coaching principle).

2. **Prompt layer** (`prompts.js`): The system prompt instructs the LLM to use
   `readSkillFragment()` to load skill knowledge fragments from disk before
   executing complex tasks.

3. **Planner layer** (`agent.js`): The DAG planner decomposes high-level goals
   (e.g. "write a Nature paper") into a task tree, chaining skills together
   with dependency edges and parallel execution where safe.
