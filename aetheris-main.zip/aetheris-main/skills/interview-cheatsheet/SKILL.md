# /interview-cheatsheet
> Action: interview-cheatsheet
> Category: Rendering
> Triggers: "interview prep,cheatsheet"

## Overview
Interview preparation cheatsheet.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/interview-cheatsheet/SKILL.md` by the Aetheris skill loader.
