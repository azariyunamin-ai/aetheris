# /research-review
> Action: research-review
> Category: Review Audit
> Triggers: "review paper,peer review"

## Overview
General research review with structured feedback.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/research-review/SKILL.md` by the Aetheris skill loader.
