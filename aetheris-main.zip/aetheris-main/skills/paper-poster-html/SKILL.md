# /paper-poster-html
> Action: paper-poster-html
> Category: Paper Writing
> Triggers: "make poster,conference poster"

## Overview
Generate academic HTML/CSS poster for conferences.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-poster-html/SKILL.md` by the Aetheris skill loader.
