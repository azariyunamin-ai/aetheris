'use strict';

// Tests for the direct-LLM chat dialog (prompts, mock chat, path safety).
// Run with: node --test
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const prompts = require('../bin/lib/prompts');
const llm = require('../bin/lib/llm');
const server = require('../bin/lib/server');

function tmpRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'aetheris-chat-test-'));
}

// ---- chatSystemPrompt ----
test('chatSystemPrompt: discuss mode blocks edit blocks', () => {
  const sys = prompts.chatSystemPrompt({ projectRoot: '/p', mode: 'discuss' });
  assert.ok(/DIRECT CHAT MODE/.test(sys));
  assert.ok(/DISCUSS MODE/.test(sys));
  assert.ok(!/EDIT MODE/.test(sys));
});

test('chatSystemPrompt: edit mode instructs ```path blocks', () => {
  const sys = prompts.chatSystemPrompt({ projectRoot: '/p', mode: 'edit', contextFile: 'src/a.js' });
  assert.ok(/EDIT MODE/.test(sys));
  assert.ok(/```src\/a\.js/.test(sys));
  assert.ok(/src\/a\.js/.test(sys));
});

test('chatSystemPrompt: includes VIBE.md and file tree when provided', () => {
  const sys = prompts.chatSystemPrompt({ projectRoot: '/p', vibeMd: '# Hi', fileTree: ['a.js', 'b.ts'] });
  assert.ok(/# Hi/.test(sys));
  assert.ok(/a\.js/.test(sys));
  assert.ok(/b\.ts/.test(sys));
});

// ---- mock chat (complete with chat flag) ----
test('complete(chat) returns prose, not agent JSON, in mock mode', async () => {
  const { content } = await llm.complete(
    { system: '', messages: [{ role: 'user', content: '你好' }], chat: true },
    'mock'
  );
  assert.ok(typeof content === 'string' && content.length > 0);
  assert.ok(!/^\{/.test(content.trim()), 'chat reply should not be JSON');
});

test('complete(chat,edit) emits a fenced edit block for the context file', async () => {
  const { content } = await llm.complete(
    { system: '', messages: [{ role: 'user', content: '改一下' }], chat: true, contextFile: 'README.md', mode: 'edit' },
    'mock'
  );
  assert.ok(/```README\.md/.test(content), 'expected a ```README.md edit block');
});

// ---- path safety helpers (same logic used by /api/agent/chat/apply) ----
test('safeJoin: stays inside root, rejects traversal', () => {
  const root = tmpRoot();
  const ok = server.safeJoin(root, 'a/b.txt');
  assert.ok(ok && ok.startsWith(path.resolve(root)));
  assert.strictEqual(server.safeJoin(root, '../../etc/passwd'), null);
  assert.strictEqual(server.safeJoin(root, '/abs/escape'), null);
});

test('listProjectFiles: skips node_modules and binaries', () => {
  const root = tmpRoot();
  fs.mkdirSync(path.join(root, 'src'));
  fs.mkdirSync(path.join(root, 'node_modules', 'x'), { recursive: true });
  fs.writeFileSync(path.join(root, 'src', 'a.js'), 'x');
  fs.writeFileSync(path.join(root, 'node_modules', 'x', 'y.js'), 'x');
  fs.writeFileSync(path.join(root, 'icon.png'), 'x');
  const files = server.listProjectFiles(root, '.', 4, 600);
  assert.ok(files.includes('src/a.js'));
  assert.ok(!files.some(f => f.includes('node_modules')));
  assert.ok(!files.includes('icon.png'));
});
