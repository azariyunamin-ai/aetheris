# /gemini-search
> Action: gemini-search
> Category: Search
> Triggers: "Gemini search,literature"

## Overview
Gemini literature search.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/gemini-search/SKILL.md` by the Aetheris skill loader.
