# /wiki-enrich
> Action: wiki-enrich
> Category: Knowledge
> Triggers: "enrich wiki,fill gaps"

## Overview
Fill paper TODOs in wiki.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/wiki-enrich/SKILL.md` by the Aetheris skill loader.
