# Nature Communications Formatting Reference

Authoritative formatting facts for submissions to *Nature Communications* (Nat. Comms.).

## Word limits
- **Main text** (intro through discussion, excluding methods, references, and figure legends): ~5,000 words recommended; 7,000 words hard maximum.
- **Abstract**: 150 words maximum, unstructured (no subheadings).
- **Title**: ~15 words; no acronyms unless universally recognised (DNA, RNA, PCR).

## Display items
- **Figures**: 8-10 display items typically permitted (figures + tables combined).
- **Figure resolution**: 300 dpi for halftones, 600 dpi for line art.
- **Figure legends**: 350 words maximum per legend; start with a brief title sentence in bold.

## Reference style
- Vancouver (numbered) style. References cited in order of appearance.
- Journal abbreviations per Index Medicus / NLM.
- DOI required for all references where available.

## Mandatory statements
- **Data availability**: required in every research article. Classify datasets as: publicly available (with accession codes), available upon reasonable request, or included in supplementary information.
- **Code availability**: if custom code was used, state where it is deposited (GitHub, Zenodo) with a DOI.
- **Competing interests**: declare for all authors.

## Supplementary information
- No arbitrary page limit; each supplementary figure/table must be cited in the main text.
- Supplementary methods and figures are peer-reviewed.

## Common desk-rejection patterns
1. **Claim not supported by data**: the central finding is overclaimed relative to the evidence.
2. **Missing data/code availability statement**: automated check fails.
3. **Abstract over 150 words or with subheadings**: format violation.
4. **Figures unreadable at 100% zoom**: font too small, resolution too low.
5. **References incomplete**: missing DOIs, incorrect numbering, or non-Vancouver formatting.

## When this file is loaded
- **nature-writing**: before drafting any section, check the journal constraints. Adjust structure, word count, and figure limits accordingly.
- **nature-polishing**: verify the final draft against every constraint listed here. Flag violations.
- **nature-paper2ppt**: use journal name and formatting facts in the title slide and design language.
