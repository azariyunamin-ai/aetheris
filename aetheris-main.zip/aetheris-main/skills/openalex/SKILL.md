# /openalex
> Action: openalex
> Category: Search
> Triggers: "OpenAlex,open access"

## Overview
OpenAlex literature source.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/openalex/SKILL.md` by the Aetheris skill loader.
