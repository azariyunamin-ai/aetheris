# /database-design
> Action: database-design
> Category: Code
> Triggers: "database schema,SQL design"

## Overview
Database schema design.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/database-design/SKILL.md` by the Aetheris skill loader.
