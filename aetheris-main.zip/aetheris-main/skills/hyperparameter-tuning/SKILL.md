# /hyperparameter-tuning
> Action: hyperparameter-tuning
> Category: ML Data
> Triggers: "tune hyperparameters,grid search"

## Overview
Hyperparameter optimization.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/hyperparameter-tuning/SKILL.md` by the Aetheris skill loader.
