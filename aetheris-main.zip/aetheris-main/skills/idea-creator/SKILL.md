# /idea-creator
> Action: idea-creator
> Category: Core Pipeline
> Triggers: "generate ideas,brainstorm"

## Overview
Research idea generator. Takes a topic and proposes novel directions.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/idea-creator/SKILL.md` by the Aetheris skill loader.
