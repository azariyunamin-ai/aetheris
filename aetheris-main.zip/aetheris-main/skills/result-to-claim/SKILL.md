# /result-to-claim
> Action: result-to-claim
> Category: Core Pipeline
> Triggers: "extract claims,results to paper"

## Overview
Convert experimental results to falsifiable claims with evidence mapping.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/result-to-claim/SKILL.md` by the Aetheris skill loader.
