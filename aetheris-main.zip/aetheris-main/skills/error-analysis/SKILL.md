# /error-analysis
> Action: error-analysis
> Category: ML Data
> Triggers: "error analysis,mistakes"

## Overview
Error analysis framework.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/error-analysis/SKILL.md` by the Aetheris skill loader.
