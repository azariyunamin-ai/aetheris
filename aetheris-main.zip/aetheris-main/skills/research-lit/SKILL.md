# /research-lit
> Action: research-lit
> Category: Core Pipeline
> Triggers: "literature survey,find papers,related work"

## Overview
Literature survey: search 5+ databases, extract claims, build citation graph, identify gaps.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/research-lit/SKILL.md` by the Aetheris skill loader.
