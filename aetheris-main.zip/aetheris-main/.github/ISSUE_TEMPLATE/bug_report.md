---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: agonxl
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Run command '...'
2. Answer prompt '....'
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment (please complete the following information):**
 - OS: [e.g. macOS]
 - Node Version [e.g. 20.x]
 - Vibe Agent: [e.g. Cursor, Claude]

**Additional context**
Add any other context about the problem here.
