# /web-debug-search
> Action: web-debug-search
> Category: Search
> Triggers: "debug search,github issues"

## Overview
Debug search across GitHub Issues, Discussions, forums.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/web-debug-search/SKILL.md` by the Aetheris skill loader.
