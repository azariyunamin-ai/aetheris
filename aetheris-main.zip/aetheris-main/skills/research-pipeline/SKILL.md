# /research-pipeline — Main Research Pipeline
> Action: research-pipeline
> Category: Core Pipeline
> Position: Entry point — direction → paper end-to-end
> Triggers: "write a paper", "publish research", "full pipeline"

## Overview
End-to-end research pipeline: from a research direction all the way to a polished paper.

## Pipeline Stages
1. **Literature Survey** → `/research-lit` — find 10-20 relevant papers, extract claims, identify gaps
2. **Idea Generation** → `/idea-discovery` — propose novel directions with novelty check
3. **Experiment Design** → `/run-experiment` + `/experiment-bridge` — design and execute experiments
4. **Result Analysis** → `/result-to-claim` — extract empirical claims from results
5. **Paper Writing** → `/paper-writing` — draft paper with all sections
6. **Claim Audit** → `/paper-claim-audit` — verify every claim against evidence
7. **Citation Audit** → `/citation-audit` — verify all references
8. **Review** → `/auto-review-loop` — adversarial review + revision
9. **Polish** → `/paper-slides` + `/rebuttal` — prepare for submission

## Safety Gates
- Each stage must complete before the next begins
- If novelty-check fails (< 5/10), return to Stage 2
- If claim audit fails (< 3 claims validated), return to Stage 4
- Final paper must pass citation audit (no fabricated refs)

## Agent Prompt
You are executing the full research pipeline. Follow the stages in order. At each stage completion, report: (1) what was done, (2) pass/fail criteria, (3) next stage instructions.
