'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const llm = require('../bin/lib/llm');
const { createApproval } = require('../bin/lib/approve');
const research = require('../bin/lib/tools-research');
const { researchRegistry, launchUI } = require('../bin/lib/server');

// ---- Intent routing + planner ----
test('mockRoute classifies autonomous-research goals', () => {
  assert.strictEqual(llm.mockRoute('我想跑一个自主训练循环改进语言模型'), 'autonomous_research');
  assert.strictEqual(llm.mockRoute('run autoresearch GPU training loop'), 'autonomous_research');
  assert.strictEqual(llm.mockRoute('自主研究：提升 val_bpb'), 'autonomous_research');
});

test('autonomous_research is a known intent', () => {
  assert.ok(llm.INTENTS.includes('autonomous_research'));
});

test('mockPlan for autonomous_research yields the research loop', async () => {
  const { parsed } = await llm.mockPlan({ domain: 'academic', intent: 'autonomous_research', language: 'zh' });
  const tools = parsed.plan.map(n => n.tool);
  for (const t of ['researchSetup', 'researchTrain', 'researchStatus', 'researchDecide']) {
    assert.ok(tools.includes(t), 'missing ' + t);
  }
  // The loop must train, read the metric, then decide keep/discard.
  const trainIdx = tools.indexOf('researchTrain');
  const statusIdx = tools.indexOf('researchStatus');
  const decideIdx = tools.indexOf('researchDecide');
  assert.ok(trainIdx >= 0 && statusIdx > trainIdx && decideIdx > statusIdx, 'train -> status -> decide order');
  // zh branch should produce Chinese-titled nodes
  assert.ok(parsed.plan.some(n => /中文|训练|研究/.test(n.title)), 'expected Chinese-titled nodes');
});

// ---- askUser mechanism (used at research decision points) ----
test('askUser server mode pauses and resolves via _resolveQuestion', async () => {
  const session = { pendingQuestion: null, _resolveQuestion: null };
  const a = createApproval({ mode: 'server', session });
  const p = a.ask('是否采纳本轮改动？', ['keep', 'discard', 'stop loop']);
  assert.ok(session.pendingQuestion && session.pendingQuestion.question.includes('采纳'));
  assert.strictEqual(session.pendingQuestion.options.length, 3);
  session._resolveQuestion('keep');
  const ans = await p;
  assert.strictEqual(ans, 'keep');
  assert.strictEqual(session.pendingQuestion, null);
});

// ---- Engine env detection (no real training needed) ----
test('research tools report a helpful error when no numpy python exists (cpu-tiny)', async () => {
  const prev = process.env.VIBEBASE_PYTHON;
  const prevEngine = process.env.VIBEBASE_RESEARCH_ENGINE;
  process.env.VIBEBASE_PYTHON = path.join(os.tmpdir(), 'no-such-python-xyz.exe');
  process.env.VIBEBASE_RESEARCH_ENGINE = 'cpu-tiny';
  try {
    const env = research.findResearchEnv({});
    assert.strictEqual(env.ok, false);
    assert.ok(env.hint && /numpy|pip install/i.test(env.hint), 'expected numpy/pip hint, got ' + JSON.stringify(env));
    const r = await research.researchSetup(process.cwd(), {});
    assert.strictEqual(r.ok, false);
    assert.ok(r.hint && /numpy/i.test(r.hint), 'expected numpy hint, got ' + JSON.stringify(r));
  } finally {
    if (prev === undefined) delete process.env.VIBEBASE_PYTHON; else process.env.VIBEBASE_PYTHON = prev;
    if (prevEngine === undefined) delete process.env.VIBEBASE_RESEARCH_ENGINE; else process.env.VIBEBASE_RESEARCH_ENGINE = prevEngine;
  }
});

test('gpu engine requires uv (or is available when uv present)', () => {
  const env = research.findResearchEnv({ engine: 'gpu' });
  if (env.ok) {
    assert.strictEqual(env.engine, 'gpu');
    assert.ok(env.exe && env.exe.length > 0);
  } else {
    // uv not installed on this machine -> clear, actionable hint.
    assert.ok(/uv/.test(env.hint || env.error), 'expected uv hint, got ' + JSON.stringify(env));
  }
});

// ---- Registry merge ----
test('research registry exposes research tools + data tools with correct risk', () => {
  const reg = researchRegistry();
  for (const t of ['researchSetup', 'researchTrain', 'researchStatus', 'researchDecide']) {
    assert.ok(reg.tools[t], 'registry missing ' + t);
  }
  // research integrates the data tools too (analyzing results.tsv).
  assert.ok(reg.tools.dataExport, 'registry should expose data tools');
  // read-only status is low risk; the rest are high risk.
  assert.strictEqual(reg.riskLevel('researchStatus'), 'low');
  assert.strictEqual(reg.riskLevel('researchSetup'), 'high');
  assert.strictEqual(reg.riskLevel('dataExport'), 'high');
});

// ---- Full wiring e2e: autonomous_research intent flows to the run state ----
test('POST /api/agent/run autonomous_research surfaces intent + research registry', async () => {
  process.env.VIBEBASE_NO_OPEN = '1';
  process.env.VIBEBASE_PROVIDER = 'mock';
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vb-research-'));
  fs.mkdirSync(path.join(tmp, '.vibe'), { recursive: true });
  const server = launchUI(tmp, { noOpen: true });
  await new Promise(r => server.listening ? r() : server.once('listening', r));
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;
  const post = (url, body) => new Promise((res, rej) => {
    const data = JSON.stringify(body);
    const req = http.request(base + url, { method: 'POST', agent: false, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), 'Connection': 'close' } }, r => {
      let o = ''; r.on('data', c => o += c); r.on('end', () => { try { r.destroy(); } catch (e) {} res({ status: r.statusCode, body: o }); });
    });
    req.on('error', rej); req.write(data); req.end();
  });
  const get = (url) => new Promise((res, rej) => {
    http.get(base + url, { agent: false, headers: { 'Connection': 'close' } }, r => { let o = ''; r.on('data', c => o += c); r.on('end', () => { try { r.destroy(); } catch (e) {} res(JSON.parse(o)); }); }).on('error', rej);
  });
  try {
    await post('/api/agent/run', { goal: '自主改进一个小型 transformer 的训练', domain: 'academic', intent: 'autonomous_research', language: 'zh' });
    const st = await get('/api/agent/status');
    assert.strictEqual(st.intent, 'autonomous_research');
    assert.strictEqual(st.domain, 'academic');
  } finally {
    try { if (server.closeAllConnections) server.closeAllConnections(); } catch (e) { /* ignore */ }
    await new Promise(r => server.close(r));
  }
});
