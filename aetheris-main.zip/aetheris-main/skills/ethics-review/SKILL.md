# /ethics-review
> Action: ethics-review
> Category: Research
> Triggers: "ethics review,IRB"

## Overview
Research ethics review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/ethics-review/SKILL.md` by the Aetheris skill loader.
