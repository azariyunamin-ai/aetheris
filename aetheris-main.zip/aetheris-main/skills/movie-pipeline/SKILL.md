# /movie-pipeline
> Action: movie-pipeline
> Category: Rendering
> Triggers: "movie pipeline,animation"

## Overview
Movie pipeline for animated presentations.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/movie-pipeline/SKILL.md` by the Aetheris skill loader.
