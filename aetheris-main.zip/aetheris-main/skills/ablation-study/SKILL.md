# /ablation-study
> Action: ablation-study
> Category: ML Data
> Triggers: "ablation study,remove components"

## Overview
Systematic ablation study.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/ablation-study/SKILL.md` by the Aetheris skill loader.
