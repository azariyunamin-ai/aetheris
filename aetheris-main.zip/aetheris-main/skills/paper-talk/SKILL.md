# /paper-talk
> Action: paper-talk
> Category: Paper Writing
> Triggers: "conference talk,presentation"

## Overview
End-to-end conference talk pipeline: slides + script + practice.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/paper-talk/SKILL.md` by the Aetheris skill loader.
