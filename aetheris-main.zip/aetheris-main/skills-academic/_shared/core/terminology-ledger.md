# Terminology Ledger

A cross-skill asset shared by `nature-writing`, `nature-polishing`, `nature-reader`, and `nature-paper2ppt`.

## Purpose
On first contact with the draft or source material, extract recurring terms, abbreviations, notation, and proper names into this ledger. Lock the **canonical form** and reuse it across every section, every skill, and every output.

## Ledger Format
Maintain a markdown table under `paper.md`'s "Terminology" section or as a standalone `paper/terminology.md`:

```markdown
| Term | Canonical form | Abbreviation | Notes |
|------|---------------|--------------|-------|
| IL-6 | Interleukin-6 | IL-6 | Do not use "interleukin 6" |
| AUC   | Area Under the Curve | AUC | ROC-AUC for classifiers |
| GNN   | Graph Neural Network | GNN | First use: "Graph Neural Network (GNN)" |
```

## Rules
1. **First contact**: build the ledger before drafting any prose.
2. **One canonical form**: never use synonyms to vary the prose. "IL-6" stays "IL-6" everywhere.
3. **Abbreviations**: expand on first use in each major section (abstract, intro, results, discussion).
4. **Gene/protein names**: follow HGNC / UniProt conventions.
5. **Units**: SI with consistent spacing (`10 mg/L`, not `10mg/l`).
6. **Model/dataset names**: exact names as in the original publication, with version/date if applicable.

## Cross-skill usage
- **nature-writing**: build ledger during outline phase; enforce during section drafting.
- **nature-reader**: build ledger during bilingual translation; becomes `paper.md` term table and `source_map.json` glossary.
- **nature-polishing**: check every occurrence against the ledger; flag unregistered variants.
- **nature-paper2ppt**: ensure every slide and speaker note uses ledger terms.
