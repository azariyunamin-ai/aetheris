# Acceptance Gate — "The loop can drive, but it can't absolve"

## Purpose
Every automated research output must pass a human-defined acceptance gate before being considered complete. The gate prevents the agent from getting stuck in an infinite self-improvement loop without producing valid output.

## Gate Conditions (ALL must pass)
1. **Novelty**: At least 1 claim is scored ≥7/10 by the reviewer
2. **Evidence**: Every empirical claim maps to a specific experiment log entry
3. **Reproducibility**: Methods section contains all hyperparameters, seeds, and hardware specs
4. **Citation Integrity**: 0 fabricated references (verified by /citation-audit)
5. **Anti-Cheating**: Passes /integrity-forensics (46 cheat patterns checked)

## Gate Failure Protocol
- Gate fails → abort run, log reason, notify user
- Gate passes → output marked as "accepted", ready for human review

## Override
Human can override gate pass/fail via `accepted: true/false` in the approval system.
