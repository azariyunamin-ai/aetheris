# /manual-review
> Action: manual-review
> Category: Tools
> Triggers: "manual review,human review"

## Overview
Manual review MCP for cross-model review.

## Workflow
1. Parse user intent and extract parameters
2. Execute the skill-specific protocol
3. Apply safety gates before returning
4. Output structured results with evidence

## Integration
Loaded from `skills/manual-review/SKILL.md` by the Aetheris skill loader.
